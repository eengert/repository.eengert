from __future__ import unicode_literals
import time
import json
import xbmc
import xbmcgui
import xbmcaddon
import xbmcvfs
import os.path
import shutil
import uuid
from . import utils as utils
from datetime import datetime
from . vfs import XBMCFileSystem, DropboxFileSystem, ZipFileSystem
from . progressbar import BackupProgressBar
from resources.lib.guisettings import GuiSettingsManager
from resources.lib.extractor import ZipExtractor
from resources.lib.archive import (
    MANIFEST_NAME,
    ArchiveValidationError,
    build_manifest,
    collapse_identical_case_collisions,
    load_manifest,
    sha256_reader,
    verify_manifest_files,
    verify_zip_archive,
)
from resources.lib.tvos_settings_guard import MARKER_NAME
from resources.lib.planning import (
    FilePlanner,
    TMDB_HELPER_ID,
    describe_backup_plan,
    summarize_file_groups,
    tmdb_helper_cache_exclusions,
)
from resources.lib.restore_ui import (
    restore_preparation_message,
    restore_set_labels,
    selected_restore_set_ids,
)
from resources.lib.status import describe_status
from resources.lib.skin_adapter import (
    AF3_ID,
    APPEARANCE_SETTINGS,
    MAX_FILE_BYTES,
    SKIN_VARIABLES_ID,
    SkinAdapterError,
    capture_af3_snapshot,
    managed_source_paths,
)
from resources.lib.skin_coordinator import (
    SkinCoordinatorError,
    discard_prepared_skin_restore,
    finish_skin_restore,
    inspect_pending_restore,
    resume_skin_restore_staging,
    rollback_skin_restore,
    stage_skin_restore,
)
from resources.lib.skin_kodi_host import KodiSkinHost
from resources.lib.skin_recovery import describe_recovery_action
from resources.lib.skin_restore import (
    load_skin_snapshot,
    skin_restore_preview,
)


def folderSort(aKey):
    result = aKey[0]

    if(len(result) < 8):
        result = result + "0000"

    return result


class XbmcBackup:
    # constants for initiating a back or restore
    Backup = 0
    Restore = 1

    # local-only marker recording the most recent successful backup's
    # identity, for Status to read without ever listing the remote
    # destination (see _recordLastBackup()/_lastBackupLabel())
    LAST_BACKUP_FILE = 'last-backup.json'

    ZIP_TEMP_PATH = None

    # list of dirs for the "simple" file selection
    simple_directory_list = ['addons', 'addon_data', 'database', 'game_saves', 'playlists', 'profiles', 'thumbnails', 'config']

    # file systems
    xbmc_vfs = None
    remote_vfs = None
    saved_remote_vfs = None

    restoreFile = None
    remote_base_path = None
    _remote_raw_path = None

    # for the progress bar
    progressBar = None
    transferSize = 0
    transferLeft = 0

    restore_point = None
    skip_advanced = False   # if we should check for the existance of advancedsettings in the restore

    def __init__(self, settings_guard=None):
        # Program and scheduler pass their shared tvOS guard here. It remains
        # optional so restore/status and non-tvOS callers retain their current
        # behavior.
        self.settings_guard = settings_guard
        self.xbmc_vfs = XBMCFileSystem(xbmcvfs.translatePath('special://home'))
        self.ZIP_TEMP_PATH = xbmcvfs.translatePath(utils.getSetting('zip_temp_path'))
        self.transferSize = 0
        self.transferLeft = 0
        self.backup_plan = None
        self.backup_manifest = None
        self.backup_manifest_file_hash = None
        self._automatic_exclusion_rules = None
        self._active_artifact = None
        self._active_artifact_compressed = False
        self._vfs_closed = True
        self._skin_stage_path = None
        self._skin_snapshot_metadata = None
        self._skin_managed_exclusions = []
        self._skin_monitor = xbmc.Monitor()
        self._copy_failures = []
        self._failure_reason = None

        self.configureRemote()
        utils.log(utils.getString(30046))

    def configureRemote(self):
        # the raw, unnormalized setting value backing the current
        # remote_vfs, if the destination is path-based - Vfs.clean_path()
        # always appends a trailing slash (turning "" into "/"), so
        # remote_vfs.root_path can never be used to detect an empty
        # setting; remoteConfigured() checks this instead.
        self._remote_raw_path = None

        if(utils.getSetting('remote_selection') == '1'):
            self._remote_raw_path = utils.getSetting('remote_path_2')
            self.remote_vfs = XBMCFileSystem(self._remote_raw_path)
            # Do not clear remote_path here. Constructing Backup Pro must be
            # read-only with respect to settings: on tvOS a normal settings
            # write can make fresh wrappers expose default values mid-session.
        elif(utils.getSetting('remote_selection') == '0'):
            self._remote_raw_path = utils.getSetting("remote_path")
            self.remote_vfs = XBMCFileSystem(self._remote_raw_path)
        elif(utils.getSetting('remote_selection') == '2'):
            self.remote_vfs = DropboxFileSystem("/")

        self.remote_base_path = self.remote_vfs.root_path

    def remoteConfigured(self):
        result = True

        if(self._remote_raw_path is not None and not self._remote_raw_path.strip()):
            result = False
        elif(not xbmcvfs.exists(self.ZIP_TEMP_PATH)):
            result = False

        return result

    # reverse - should reverse the resulting, default is true - newest to oldest
    def listBackups(self, reverse=True):
        result = []

        # get all the folders in the current root path
        dirs, files = self.remote_vfs.listdir(self.remote_base_path)

        for aDir in dirs:
            if(self.remote_vfs.exists(
                    self.remote_base_path + aDir + "/" + MANIFEST_NAME)):

                # format the name according to regional settings
                folderName = self._dateFormat(aDir)

                result.append((aDir, folderName))

        for aFile in files:
            file_ext = aFile.split('.')[-1]
            folderName = aFile.split('.')[0]

            if(file_ext == 'zip' and len(folderName) >= 12 and folderName[0:12].isdigit()):

                # format the name according to regional settings and display the file size
                folderName = "%s - %s" % (self._dateFormat(folderName), utils.diskString(self.remote_vfs.fileSize(self.remote_base_path + aFile)))

                result.append((aFile, folderName))

        result.sort(key=folderSort, reverse=reverse)

        return result

    def selectRestore(self, restore_point):
        self.restore_point = restore_point

    def skipAdvanced(self):
        self.skip_advanced = True

    def backup(self, progressOverride=False):
        try:
            return self._runBackup(progressOverride)
        except Exception as error:
            utils.log('Backup failed: %s' % error, xbmc.LOGWARNING)
            self._discardActiveArtifact()
            self._reportBackupFailure(str(error))
            return False
        finally:
            self._cleanupSkinStage()
            if not self._vfs_closed:
                self._closeVFS()

    def _runBackup(self, progressOverride=False):
        self._copy_failures = []
        self._failure_reason = None
        shouldContinue = self._setupVFS(self.Backup, progressOverride)

        if(shouldContinue):
            utils.log(utils.getString(30023) + " - " + utils.getString(30016))
            # Folder backups must never reuse a prior timestamp root. ZIP
            # archives create their logical root inside the local ZIP instead.
            if not isinstance(self.remote_vfs, ZipFileSystem):
                if self.remote_vfs.exists(self.remote_vfs.root_path):
                    utils.log('Backup target already exists: ' +
                              self.remote_vfs.root_path, xbmc.LOGWARNING)
                    self._reportBackupFailure(
                        'the backup destination already exists: '
                        + self.remote_vfs.root_path)
                    self._closeVFS()
                    return False
                if not self.remote_vfs.mkdir(self.remote_vfs.root_path):
                    utils.log('Unable to create backup target: ' +
                              self.remote_vfs.root_path, xbmc.LOGWARNING)
                    self._reportBackupFailure(
                        'could not create the backup destination: '
                        + self.remote_vfs.root_path)
                    self._closeVFS()
                    return False
                self._active_artifact = self.remote_vfs.root_path
                self._active_artifact_compressed = False

            # VFS setup can take long enough for the separate tvOS service to
            # discover an unsafe/default settings view after Program's earlier
            # gate. This outer check protects VFS setup; _collectBackupFiles()
            # performs the final check at its actual selection boundary.
            if not self._allowBackupSelection('backup_selection_boundary'):
                self._closeVFS()
                return False

            utils.log(utils.getString(30051))
            utils.log('File Selection Type: ' + str(utils.getSetting('backup_selection_type')))
            allFiles = self._collectBackupFiles()
            if allFiles is None:
                return False

            try:
                writeCheck = self._createValidationFile(allFiles)
            except Exception as error:
                utils.log('Unable to create Backup Pro manifest: %s' % error,
                          xbmc.LOGWARNING)
                writeCheck = False
                self._failure_reason = (
                    'could not create the backup manifest: %s' % error)

            if(not writeCheck):
                if isinstance(self.remote_vfs, ZipFileSystem):
                    self._reportBackupFailure()
                else:
                    self._finalizeBackup(
                        False, self.remote_vfs.root_path, compressed=False)
                self._closeVFS()
                return False

            orig_base_path = self.remote_vfs.root_path
            backup_success = True
            compressing = utils.getSettingBool("compress_backups")
            remote_artifact = None if compressing else orig_base_path

            # backup all the files
            self.transferLeft = self.transferSize
            for fileGroup in allFiles:
                self.xbmc_vfs.set_root(xbmcvfs.translatePath(fileGroup['source']))
                self.remote_vfs.set_root(fileGroup['dest'] + fileGroup['name'])
                filesCopied = self._copyFiles(fileGroup['files'], self.xbmc_vfs, self.remote_vfs)

                if(not filesCopied):
                    utils.log(utils.getString(30092))
                    backup_success = False

            # reset remote and xbmc vfs
            self.xbmc_vfs.set_root("special://home/")
            self.remote_vfs.set_root(orig_base_path)

            if(compressing):
                fileManager = FileManager(self.xbmc_vfs)

                # from here on (finalizing the ZIP and copying it to the
                # real destination) there is no reliable, cheap way to
                # report incremental byte progress - the prior per-file
                # "X remaining" wording either went stale (during verify)
                # or was pinned at the full archive size for the entire,
                # single blocking copy that follows. Show one clear,
                # honest message instead of a frozen or misleading meter.
                compressing_message = '%s\n%s' % (
                    utils.getString(30229), utils.getString(30230))
                self.progressBar.updateProgress(
                    self._INDETERMINATE_PERCENT, compressing_message)

                # send the zip file to the real remote vfs
                zip_name = os.path.join(self.ZIP_TEMP_PATH, self.remote_vfs.root_path[:-1] + ".zip")
                self.remote_vfs.cleanup()
                renamed = self.xbmc_vfs.rename(
                    os.path.join(self.ZIP_TEMP_PATH, "xbmc_backup_temp.zip"),
                    zip_name)
                if not renamed:
                    backup_success = False
                else:
                    try:
                        verify_zip_archive(
                            zip_name, check_cancel=self.progressBar.checkCancel)
                    except ArchiveValidationError as error:
                        utils.log('Local ZIP verification failed: %s' % error,
                                  xbmc.LOGWARNING)
                        backup_success = False
                        self._failure_reason = (
                            'local archive verification failed: %s' % error)
                    fileManager.addFile(zip_name)

                # set root to data dir home and reset remote
                self.xbmc_vfs.set_root(self.ZIP_TEMP_PATH)
                self.remote_vfs = self.saved_remote_vfs

                # update the amount to transfer
                if backup_success:
                    remote_zip = (self.remote_vfs.root_path +
                                  os.path.basename(zip_name))
                    if self.remote_vfs.exists(remote_zip):
                        utils.log('Backup ZIP already exists: ' + remote_zip,
                                  xbmc.LOGWARNING)
                        backup_success = False
                    else:
                        remote_artifact = remote_zip
                        self._active_artifact = remote_zip
                        self._active_artifact_compressed = True
                if backup_success:
                    self.transferSize = fileManager.fileSize()
                    self.transferLeft = self.transferSize
                    fileCopied = self._copyFiles(
                        fileManager.getFiles(), self.xbmc_vfs,
                        self.remote_vfs, progress_message=compressing_message)
                    backup_success = bool(fileCopied)
                if backup_success:
                    try:
                        self._verifyCompressedUpload(zip_name, remote_zip)
                    except ArchiveValidationError as error:
                        utils.log('Uploaded ZIP verification failed: %s' % error,
                                  xbmc.LOGWARNING)
                        backup_success = False
                        self._failure_reason = (
                            'uploaded archive verification failed: %s'
                            % error)

                # delete the temp zip file
                if renamed:
                    self.xbmc_vfs.rmfile(zip_name)
            elif backup_success:
                try:
                    self._verifyFolderBackup(orig_base_path)
                except ArchiveValidationError as error:
                    utils.log('Folder backup verification failed: %s' % error,
                              xbmc.LOGWARNING)
                    backup_success = False
                    self._failure_reason = (
                        'backup verification failed: %s' % error)

            backup_success = self._finalizeBackup(
                backup_success, remote_artifact, compressing)

            self._closeVFS()
            return backup_success

        return False

    def restore(self, progressOverride=False, selectedSets=None):
        try:
            return self._runRestore(progressOverride, selectedSets)
        finally:
            self._closeVFS()

    def _runRestore(self, progressOverride=False, selectedSets=None):
        shouldContinue = self._setupVFS(self.Restore, progressOverride)

        if(shouldContinue):
            utils.log(utils.getString(30023) + " - " + utils.getString(30017))

            # catch for if the restore point is actually a zip file
            if(self.restore_point.split('.')[-1] == 'zip'):
                utils.log("copying zip file: " + self.restore_point)

                # set root to data dir home
                self.xbmc_vfs.set_root(self.ZIP_TEMP_PATH)
                restore_path = os.path.join(self.ZIP_TEMP_PATH, self.restore_point)
                if(not self.xbmc_vfs.exists(restore_path)):
                    copy_message = restore_preparation_message(
                        utils.getString, 'copy_archive')
                    self.progressBar.updateProgress(2, copy_message)
                    # copy just this file from the remote vfs
                    self.transferSize = self.remote_vfs.fileSize(self.remote_base_path + self.restore_point)
                    zipFile = []
                    zipFile.append({'file': self.remote_base_path + self.restore_point, 'size': self.transferSize, 'is_dir': False})

                    # set transfer size
                    self.transferLeft = self.transferSize
                    if isinstance(self.remote_vfs, XBMCFileSystem):
                        copied = self._copyFiles(
                            zipFile, self.remote_vfs, self.xbmc_vfs,
                            progress_prefix=copy_message,
                            incremental_copy=self.xbmc_vfs.put_with_progress)
                    else:
                        unknown_progress_message = '%s\n%s: %s\n%s' % (
                            copy_message,
                            utils.getString(30236),
                            utils.diskString(self.transferSize),
                            utils.getString(30235))
                        copied = self._copyFiles(
                            zipFile, self.remote_vfs, self.xbmc_vfs,
                            progress_message=unknown_progress_message,
                            progress_percent=0)
                    if not copied:
                        return False
                else:
                    utils.log("zip file exists already")

                # extract the zip file
                zip_vfs = ZipFileSystem(restore_path, 'r')
                extractor = ZipExtractor()

                if(not extractor.extract(zip_vfs, self.ZIP_TEMP_PATH, self.progressBar)):
                    # we had a problem extracting the archive, delete everything
                    zip_vfs.cleanup()
                    self.xbmc_vfs.rmfile(restore_path)

                    xbmcgui.Dialog().ok(utils.getString(30010), utils.getString(30101))
                    return

                zip_vfs.cleanup()

                self.progressBar.updateProgress(0, utils.getString(30049) + "......")
                # set the new remote vfs and fix xbmc path
                self.remote_vfs = XBMCFileSystem(os.path.join(self.ZIP_TEMP_PATH, self.restore_point.split(".")[0]))
                self.xbmc_vfs.set_root(xbmcvfs.translatePath("special://home/"))

            # for restores remote path must exist
            if(not self.remote_vfs.exists(self.remote_vfs.root_path)):
                xbmcgui.Dialog().ok(utils.getString(30010), '%s\n%s' % (utils.getString(30045), self.remote_vfs.root_path))
                return

            valFile = self._checkValidationFile(self.remote_vfs.root_path)
            if(valFile is None):
                # don't continue
                return

            utils.log(utils.getString(30051))
            allFiles = []
            fileManager = FileManager(self.remote_vfs)

            # use a multiselect dialog to select sets to restore
            restoreSets = [n['name'] for n in valFile['directories']]
            restoreLabels = restore_set_labels(restoreSets, utils.getString)

            # if passed in list, skip selection
            if(selectedSets is None):
                selectedSets = xbmcgui.Dialog().multiselect(
                    utils.getString(30131), restoreLabels)
            else:
                selectedSets = [restoreSets.index(n) for n in selectedSets if n in restoreSets]  # if set name not found just skip it

            restoreSettings = False
            if(selectedSets is not None):
                selectedRestoreSets = selected_restore_set_ids(
                    restoreSets, selectedSets)
                skin_indexes = [
                    index for index in selectedSets
                    if restoreSets[index].casefold() == 'skin_config'
                ]
                if skin_indexes:
                    if len(selectedSets) != 1 or len(skin_indexes) != 1:
                        xbmcgui.Dialog().ok(
                            utils.getString(30010),
                            'Restore Arctic Fuse 3 configuration by itself. '
                            'Other groups can be restored in a separate run.')
                        return False
                    result = self._restoreSkinConfig(valFile)
                    self._cleanupRestoreArchive()
                    return result

                selected_names = {
                    name.casefold() for name in selectedRestoreSets
                }

                # advancedsettings.xml requires a restart, but only when the
                # user actually selected the Config group.
                advanced = (self.remote_vfs.root_path
                            + 'config/advancedsettings.xml')
                if ('config' in selected_names
                        and self.remote_vfs.exists(advanced)
                        and not self.skip_advanced):
                    restartXbmc = xbmcgui.Dialog().yesno(
                        utils.getString(30038), '%s\n%s\n%s' % (
                            utils.getString(30039), utils.getString(30040),
                            utils.getString(30041)))
                    if restartXbmc:
                        self.transferSize = 1
                        self.transferLeft = 1
                        fileManager.addFile(advanced)
                        self._copyFiles(
                            fileManager.getFiles(), self.remote_vfs,
                            self.xbmc_vfs)
                        self._createResumeBackupFile()
                        if xbmcgui.Dialog().yesno(
                                utils.getString(30077),
                                utils.getString(30078), autoclose=15000):
                            xbmc.executebuiltin('Quit')
                        return

                restoreSettings = not utils.getSettingBool(
                    'always_prompt_restore_settings')
                if (not restoreSettings and 'system_settings' in valFile):
                    restoreSettings = xbmcgui.Dialog().yesno(
                        utils.getString(30149), utils.getString(30150))

                # go through each of the directories in the backup and write them to the correct location
                for index in selectedSets:

                    # add this directory
                    aDir = valFile['directories'][index]

                    self.xbmc_vfs.set_root(xbmcvfs.translatePath(aDir['path']))
                    if(self.remote_vfs.exists(self.remote_vfs.root_path + aDir['name'] + '/')):
                        # walk the directory
                        self.progressBar.updateProgress(0, f"{utils.getString(30049)}....{utils.getString(30162)}\n{utils.getString(30163)}: {aDir['name']}")
                        fileManager.walkTree(self.remote_vfs.root_path + aDir['name'] + '/')
                        self.transferSize = self.transferSize + fileManager.fileSize()

                        allFiles.append({"source": self.remote_vfs.root_path + aDir['name'], "dest": self.xbmc_vfs.root_path, "files": fileManager.getFiles()})
                    else:
                        utils.log("error path not found: " + self.remote_vfs.root_path + aDir['name'])
                        xbmcgui.Dialog().ok(utils.getString(30010), '%s\n%s' % (utils.getString(30045), self.remote_vfs.root_path + aDir['name']))

                # restore all the files
                self.transferLeft = self.transferSize
                for fileGroup in allFiles:
                    self.remote_vfs.set_root(fileGroup['source'])
                    self.xbmc_vfs.set_root(fileGroup['dest'])
                    self._copyFiles(fileGroup['files'], self.remote_vfs, self.xbmc_vfs)

            # update the Kodi settings - if we can
            if('system_settings' in valFile and restoreSettings):
                self.progressBar.updateProgress(98, "Restoring Kodi settings")
                gui_settings = GuiSettingsManager()
                gui_settings.restore(valFile['system_settings'])

            self.progressBar.updateProgress(99, "Clean up operations .....")

            self._cleanupRestoreArchive()

            # call update addons to refresh everything
            xbmc.executebuiltin('UpdateLocalAddons')

            # notify user that restart is recommended
            if(xbmcgui.Dialog().yesno(utils.getString(30077), utils.getString(30078), autoclose=15000)):
                xbmc.executebuiltin('Quit')

    def _cleanupRestoreArchive(self):
        if self.restore_point.split('.')[-1] != 'zip':
            return
        self.xbmc_vfs.rmfile(os.path.join(
            self.ZIP_TEMP_PATH, self.restore_point))
        xbmc.sleep(1000)
        self.xbmc_vfs.rmdir(self.remote_vfs.clean_path(os.path.join(
            self.ZIP_TEMP_PATH, self.restore_point.split('.')[0])))
        xbmc.sleep(1000)

    def _skinWait(self, seconds):
        if self._skin_monitor.waitForAbort(seconds):
            raise RuntimeError('Kodi is closing; the restore remains pending')
        if (hasattr(self, '_skin_profile')
                and os.path.abspath(xbmcvfs.translatePath(
                    'special://profile/')) != self._skin_profile):
            raise RuntimeError(
                'Kodi profile changed; the restore remains pending')

    @staticmethod
    def _skinConfirmationActive():
        for condition in ('Window.IsActive(yesnodialog)',
                          'Window.IsActive(10100)'):
            try:
                if xbmc.getCondVisibility(condition):
                    return True
            except RuntimeError:
                continue
        return False

    @staticmethod
    def _skinLabel(skin):
        try:
            name = xbmcaddon.Addon(skin).getAddonInfo('name')
            return name if name else skin
        except Exception:
            return skin

    @staticmethod
    def _confirmSkinChange():
        """Answer Kodi's own 'keep this skin?' safety dialog with Yes.

        This dialog auto-reverts if nobody responds within its own
        short countdown - too brief for a human to reliably react to
        (reported 2026-09-10: it appeared and reverted before the user
        got a usable chance to click Yes). Backup Pro itself requested
        this exact skin change as part of a restore it is already
        performing, so the answer is never actually in doubt.

        An earlier version of this method navigated focus with
        Action(Up) before selecting - that assumed a specific button
        layout proven only for AF3's own custom yesno dialog. Live
        testing 2026-09-10 found the flaw directly: this dialog renders
        using whichever skin is *currently* active at the moment it
        appears, which for the ensure_inactive() (AF3 -> Estuary) leg
        is Estuary, not AF3 - a completely different button layout, so
        Action(Up) did nothing there and the dialog was left on its
        default "No" (confirmed via System.CurrentControl staying "No"
        across the whole dialog lifetime, then reverting exactly like a
        declined change). SendClick(11) is the deterministic,
        skin-agnostic fix: 11 is Kodi's own standard "Yes" control id
        for this dialog window, which every skin's yesno template binds
        its visual Yes button to (confirmed against AF3's own
        Dialog_DialogConfirm.xml: its custom Yes button's <onclick> is
        itself SendClick(11)) - clicking it directly needs no knowledge
        of the active skin's focus/navigation topology at all.
        """
        xbmc.executebuiltin('SendClick(11)')

    def _switchSkin(self, skin):
        if xbmc.getSkinDir() == skin:
            return
        try:
            self.progressBar.close()
        except Exception:
            pass
        try:
            xbmcgui.Dialog().notification(
                utils.getString(30010),
                'Kodi is switching to {} to safely apply the restore; '
                'it will switch back automatically.'.format(
                    self._skinLabel(skin)),
                xbmcgui.NOTIFICATION_INFO, 8000)
        except Exception:
            pass
        xbmc.executebuiltin('ActivateWindow(home)')
        self._skinWait(0.5)
        if self._skinRpc(
                'Settings.SetSettingValue', setting='lookandfeel.skin',
                value=skin) is not True:
            raise RuntimeError('Kodi refused to change skins')
        confirmation_seen = False
        confirmation_answered = False
        confirmed_reads = 0
        active_reads = 0
        for _attempt in range(96):
            self._skinWait(0.25)
            if xbmc.getSkinDir() != skin:
                active_reads = 0
                confirmed_reads = 0
                confirmation_seen = False
                confirmation_answered = False
                continue
            active_reads += 1
            if self._skinConfirmationActive():
                confirmation_seen = True
                confirmed_reads = 0
                if not confirmation_answered:
                    self._confirmSkinChange()
                    confirmation_answered = True
            elif confirmation_seen:
                confirmed_reads += 1
                if confirmed_reads >= 4:
                    break
            elif active_reads >= 44:
                break
        else:
            raise RuntimeError(
                'Skin change was not kept; accept Kodi\'s confirmation and retry')
        self.progressBar = BackupProgressBar(False)
        self.progressBar.create(
            utils.getString(30010) + ' - ' + utils.getString(30017),
            'Continuing verified skin restore')

    def _makeSkinHost(self):
        return KodiSkinHost(
            xbmc, xbmcvfs, xbmcaddon,
            self._switchSkin, self._skinWait,
            progress=lambda percent, message:
                self.progressBar.updateProgress(percent, message),
            xbmcgui_module=xbmcgui)

    def _readRestoreBytes(self, relative):
        source = self.remote_vfs.root_path + relative
        temporary = None
        try:
            if isinstance(self.remote_vfs, DropboxFileSystem):
                if (self.remote_vfs.fileSize(source) * 1024
                        > MAX_FILE_BYTES):
                    raise OSError('remote AF3 payload exceeds its safe limit')
                temporary = xbmcvfs.translatePath(
                    utils.data_dir() + 'skin-restore-read.tmp')
                if xbmcvfs.exists(temporary):
                    xbmcvfs.delete(temporary)
                if not self.remote_vfs.get_file(source, temporary):
                    raise OSError('remote AF3 payload download failed')
                if os.path.getsize(temporary) > MAX_FILE_BYTES:
                    raise OSError('downloaded AF3 payload exceeds its safe limit')
                source = temporary
            with xbmcvfs.File(source, 'r') as handle:
                return bytes(handle.readBytes(MAX_FILE_BYTES + 1))
        finally:
            if temporary is not None and xbmcvfs.exists(temporary):
                xbmcvfs.delete(temporary)

    def _restoreSkinConfig(self, manifest):
        try:
            preview = skin_restore_preview(manifest)
            label = (
                'Skin: {skin_id}\nBackup: {created_utc}\n'
                'Source: {source_device} / {source_profile}\n'
                'Contains: {setting_count} settings, '
                '{appearance_count} appearance values and '
                '{helper_file_count} helper files\n\n'
                'Current AF3 files will be saved locally for recovery.\n\n'
                'Kodi will briefly switch to its default skin, restore '
                'the backed-up skin configuration, then reactivate the '
                'backed-up skin.'
            ).format(**preview)
            if not xbmcgui.Dialog().yesno(
                    'Restore Arctic Fuse 3 configuration', label):
                return False
            files = load_skin_snapshot(
                manifest, self._readRestoreBytes,
                check_cancel=self.progressBar.checkCancel)
            profile = os.path.abspath(xbmcvfs.translatePath(
                'special://profile/'))
            self._skin_profile = profile
            data = os.path.abspath(xbmcvfs.translatePath(utils.data_dir()))
            os.makedirs(data, exist_ok=True)
            rollback_root = os.path.join(data, 'skin-rollback')
            pending_path = os.path.join(data, 'pending-skin-restore.json')
            host = self._makeSkinHost()
            stage_skin_restore(
                manifest, files, self.restore_point, profile,
                rollback_root, pending_path, host)
            if xbmcgui.Dialog().ok(
                    utils.getString(30010),
                    'AF3 files are staged safely. Kodi will activate '
                    'Arctic Fuse 3; verification will continue '
                    'afterward.') is False:
                return False
            # AF3's rebuild mechanism activates windows through Kodi's
            # skin-variables add-on; a modal progress dialog left open
            # here blocks that activation and hangs the rebuild.
            self.progressBar.close()
            summary = finish_skin_restore(
                profile, rollback_root, pending_path, host)
            xbmcgui.Dialog().ok(
                utils.getString(30010),
                'Restored and verified {} settings and {} helper files.'
                .format(summary['setting_count'],
                        summary['helper_file_count']))
            return True
        except (RuntimeError, OSError, ValueError) as error:
            utils.log('AF3 restore stopped safely: %s' % error,
                      xbmc.LOGWARNING)
            try:
                self.progressBar.close()
            except Exception:
                pass
            xbmcgui.Dialog().ok(
                utils.getString(30010),
                'Arctic Fuse 3 restore did not complete. Recovery data was '
                'preserved.\n\n{}'.format(error))
            return False
        finally:
            self._skin_profile = None

    def _skinRecoveryPaths(self):
        profile = os.path.abspath(xbmcvfs.translatePath('special://profile/'))
        data = os.path.abspath(xbmcvfs.translatePath(utils.data_dir()))
        rollback_root = os.path.join(data, 'skin-rollback')
        pending_path = os.path.join(data, 'pending-skin-restore.json')
        return profile, rollback_root, pending_path

    def inspectSkinRecovery(self):
        """Classify pending AF3 restore state without mutating anything."""
        profile, rollback_root, pending_path = self._skinRecoveryPaths()
        try:
            inspection = inspect_pending_restore(
                profile, rollback_root, pending_path)
        except SkinCoordinatorError as error:
            utils.log('AF3 recovery inspection failed: %s' % error,
                      xbmc.LOGWARNING)
            return {'kind': 'diagnostic', 'action': None, 'reason': str(error)}
        return describe_recovery_action(inspection)

    def resolvePendingSkinRestore(self):
        """Interactively resolve a pending AF3 restore before anything else.

        Returns True if a pending restore still blocks unrelated actions
        (nothing was resolved, the user deferred, or recovery failed
        safely), or False if there is nothing pending / it was resolved.
        """
        description = self.inspectSkinRecovery()
        if description['kind'] == 'none':
            return False
        if description['kind'] == 'diagnostic':
            xbmcgui.Dialog().ok(
                utils.getString(30010),
                'Arctic Fuse 3 restore recovery needs attention. No files '
                'or settings were changed.\n\n{}'.format(
                    description['reason']))
            return True
        if description['kind'] == 'discard':
            return self._discardPendingSkinRestore()

        options = []
        if description['continue_available']:
            options.append(
                'Continue the imported Arctic Fuse 3 configuration')
        if description['rollback_available']:
            options.append(
                'Restore the previous Arctic Fuse 3 configuration')
        options.append('Not now')
        choice = xbmcgui.Dialog().select(
            'A pending Arctic Fuse 3 restore needs your attention', options)
        if choice == -1 or options[choice] == 'Not now':
            return True

        continuing = options[choice].startswith('Continue')
        profile, rollback_root, pending_path = self._skinRecoveryPaths()
        host = self._makeSkinHost()
        self.progressBar = BackupProgressBar(False)
        self.progressBar.create(
            utils.getString(30010) + ' - Arctic Fuse 3 recovery',
            'Resuming Arctic Fuse 3 restore recovery')
        try:
            if continuing:
                inspection = inspect_pending_restore(
                    profile, rollback_root, pending_path)
                if inspection['action'] in (
                        'resume_staging', 'restage_settings'):
                    resume_skin_restore_staging(
                        profile, rollback_root, pending_path, host)
                # See the matching comment in _restoreSkinConfig(): AF3's
                # rebuild mechanism needs to activate windows, which a
                # modal progress dialog would block.
                self.progressBar.close()
                finish_skin_restore(profile, rollback_root, pending_path, host)
                xbmcgui.Dialog().notification(
                    utils.getString(30010),
                    'The imported Arctic Fuse 3 configuration was restored '
                    'and verified.')
            else:
                self.progressBar.close()
                rollback_skin_restore(
                    profile, rollback_root, pending_path, host)
                xbmcgui.Dialog().notification(
                    utils.getString(30010),
                    'Arctic Fuse 3 was restored to its previous, verified '
                    'configuration.')
        except (RuntimeError, OSError, ValueError) as error:
            utils.log('AF3 recovery action stopped safely: %s' % error,
                      xbmc.LOGWARNING)
            xbmcgui.Dialog().ok(
                utils.getString(30010),
                'Arctic Fuse 3 recovery did not complete. Recovery data was '
                'preserved.\n\n{}'.format(error))
        finally:
            try:
                self.progressBar.close()
            except Exception:
                pass

        return self.inspectSkinRecovery()['kind'] != 'none'

    def _discardPendingSkinRestore(self):
        """Discard a 'prepared'-phase restore that never touched a file.

        Returns True if recovery still blocks unrelated actions (the user
        declined, or discarding failed safely), or False once discarded.
        """
        if not xbmcgui.Dialog().yesno(
                'Arctic Fuse 3 restore recovery',
                'The imported Arctic Fuse 3 configuration was never '
                'applied to any file. It can be safely discarded so you '
                'can restart the restore.\n\nDiscard the incomplete '
                'restore attempt?'):
            return True

        profile, rollback_root, pending_path = self._skinRecoveryPaths()
        try:
            discard_prepared_skin_restore(profile, rollback_root, pending_path)
            xbmcgui.Dialog().notification(
                utils.getString(30010),
                'The incomplete Arctic Fuse 3 restore attempt was '
                'discarded. Nothing was changed.')
        except (RuntimeError, OSError, ValueError) as error:
            utils.log('AF3 recovery discard stopped safely: %s' % error,
                      xbmc.LOGWARNING)
            xbmcgui.Dialog().ok(
                utils.getString(30010),
                'Arctic Fuse 3 recovery did not complete. Recovery data was '
                'preserved.\n\n{}'.format(error))

        return self.inspectSkinRecovery()['kind'] != 'none'

    def checkPendingSkinRestoreBackground(self):
        """Non-interactive: log pending recovery, never prompt or mutate it."""
        description = self.inspectSkinRecovery()
        if description['kind'] == 'none':
            return False
        utils.log(
            'Arctic Fuse 3 restore recovery is pending; interactive '
            'recovery through the Backup Pro program add-on is required. '
            'Background/scheduled execution will not open a recovery '
            'dialog or switch skins.', xbmc.LOGWARNING)
        return True

    def buildStatusReport(self):
        """Gather a read-only status snapshot from local, already-known
        state only - no network access and no mutation. Never lists the
        remote destination's contents; that would risk a slow or blocking
        call to open a status screen. Returns describe_status()'s
        (label_key, detail) pairs for a caller to localize and display.
        """
        last_backup = {'known': False}
        last_backup_label = self._lastBackupLabel()
        if last_backup_label:
            last_backup = {'known': True, 'label': last_backup_label}

        remote_configured = self.remoteConfigured()
        remote = {'configured': remote_configured}
        if remote_configured:
            if utils.getSetting('remote_selection') == '2':
                remote['label'] = utils.getString(30027)
            else:
                remote['label'] = self.remote_base_path

        recovery_pending = self.inspectSkinRecovery()['kind'] != 'none'

        scheduler = {'enabled': utils.getSettingBool('enable_scheduler')}
        if scheduler['enabled']:
            next_run_path = xbmcvfs.translatePath(
                utils.data_dir()) + 'next_run.txt'
            if xbmcvfs.exists(next_run_path):
                with xbmcvfs.File(next_run_path) as fh:
                    try:
                        next_run = float(fh.read())
                    except ValueError:
                        next_run = 0
                if next_run > 0:
                    scheduler['next_run_label'] = utils.getRegionalTimestamp(
                        datetime.fromtimestamp(next_run),
                        ['dateshort', 'time'])

        return describe_status({
            'last_backup': last_backup,
            'remote': remote,
            'recovery_pending': recovery_pending,
            'scheduler': scheduler,
        })

    def _setupVFS(self, mode=-1, progressOverride=False):
        # set windows setting to true
        window = xbmcgui.Window(10000)
        window.setProperty(utils.__addon_id__ + ".running", "true")

        # append backup folder name
        progressBarTitle = utils.getString(30010) + " - "
        if(mode == self.Backup and self.remote_vfs.root_path != ''):
            if(utils.getSettingBool("compress_backups")):
                # delete old temp file
                zip_path = os.path.join(self.ZIP_TEMP_PATH, 'xbmc_backup_temp.zip')
                if(self.xbmc_vfs.exists(zip_path)):
                    if(not self.xbmc_vfs.rmfile(zip_path)):
                        # we had some kind of error deleting the old file
                        xbmcgui.Dialog().ok(utils.getString(30010), '%s\n%s' % (utils.getString(30096), utils.getString(30097)))
                        return False

                # save the remote file system and use the zip vfs
                self.saved_remote_vfs = self.remote_vfs
                self.remote_vfs = ZipFileSystem(zip_path, "w")

            self.remote_vfs.set_root(self.remote_vfs.root_path + time.strftime("%Y%m%d%H%M%S") + utils.getSetting('backup_suffix').strip() + "/")
            progressBarTitle = progressBarTitle + utils.getString(30023) + ": " + utils.getString(30016)
        elif(mode == self.Restore and self.restore_point is not None and self.remote_vfs.root_path != ''):
            if(self.restore_point.split('.')[-1] != 'zip'):
                self.remote_vfs.set_root(self.remote_vfs.root_path + self.restore_point + "/")
            progressBarTitle = progressBarTitle + utils.getString(30023) + ": " + utils.getString(30017)
        else:
            # kill the program here
            self.remote_vfs = None
            return False

        utils.log(utils.getString(30047) + ": " + self.xbmc_vfs.root_path)
        utils.log(utils.getString(30048) + ": " + self.remote_vfs.root_path)
        utils.log(utils.getString(30152) + ": " + utils.getSetting('zip_temp_path'))

        # setup the progress bar
        self.progressBar = BackupProgressBar(progressOverride)
        initial_message = utils.getString(30049) + "......"
        if mode == self.Restore:
            initial_message = restore_preparation_message(utils.getString)
        self.progressBar.create(progressBarTitle, initial_message)
        self._vfs_closed = False

        # if we made it this far we're good
        return True

    def _closeVFS(self):
        if self._vfs_closed:
            return
        self._vfs_closed = True
        for cleanup in (
                self.xbmc_vfs.cleanup,
                self.remote_vfs.cleanup,
                self.progressBar.close):
            try:
                cleanup()
            except Exception as error:
                utils.log('Backup cleanup failed: %s' % error,
                          xbmc.LOGWARNING)
        try:
            window = xbmcgui.Window(10000)
            window.setProperty(utils.__addon_id__ + ".running", "")
        except Exception as error:
            utils.log('Unable to clear backup running state: %s' % error,
                      xbmc.LOGWARNING)

    # Percent pinned during a copy step whose true progress cannot be
    # tracked incrementally (see _copyFiles()'s progress_message param) -
    # deliberately not 100, since the step is not yet done; the bar stays
    # static instead of jumping back to a misleading, non-advancing byte
    # countdown.
    _INDETERMINATE_PERCENT = 99

    def _copyFiles(self, fileList, source, dest, progress_message=None,
                   progress_prefix=None, progress_percent=None,
                   incremental_copy=None):
        result = True

        utils.log("Source: " + source.root_path)
        utils.log("Destination: " + dest.root_path)

        # make sure the dest folder exists - can cause write errors if the full path doesn't exist
        if(not dest.exists(dest.root_path)):
            dest.mkdir(dest.root_path)

        for aFile in fileList:
            if(self.progressBar.checkCancel()):
                result = False
                break
            else:
                if(utils.getSettingBool('verbose_logging')):
                    utils.log('Writing file: ' + aFile['file'])

                if(aFile['is_dir']):
                    if progress_message is not None:
                        self.progressBar.updateProgress(
                            self._INDETERMINATE_PERCENT if progress_percent is None
                            else progress_percent, progress_message)
                    else:
                        message = '%s remaining\nwriting %s' % (
                            utils.diskString(self.transferLeft),
                            os.path.basename(
                                aFile['file'][len(source.root_path):]) + "/")
                        if progress_prefix:
                            message = progress_prefix + '\n' + message
                        self._updateProgress(message)
                    dest.mkdir(dest.root_path + aFile['file'][len(source.root_path):])
                else:
                    if progress_message is not None:
                        self.progressBar.updateProgress(
                            self._INDETERMINATE_PERCENT if progress_percent is None
                            else progress_percent, progress_message)
                    else:
                        message = '%s remaining\nwriting %s' % (
                            utils.diskString(self.transferLeft),
                            os.path.basename(aFile['file'][len(source.root_path):]))
                        if progress_prefix:
                            message = progress_prefix + '\n' + message
                        self._updateProgress(message)
                    dest_file = (dest.root_path +
                                 aFile['file'][len(source.root_path):])
                    if incremental_copy is not None:
                        initial_left = self.transferLeft

                        def report_bytes(copied_bytes):
                            self.transferLeft = max(
                                0, initial_left - (copied_bytes / 1024.0))
                            message = '%s remaining\nwriting %s' % (
                                utils.diskString(self.transferLeft),
                                os.path.basename(
                                    aFile['file'][len(source.root_path):]))
                            if progress_prefix:
                                message = progress_prefix + '\n' + message
                            self._updateProgress(message)
                            return not self.progressBar.checkCancel()

                        wroteFile = incremental_copy(
                            aFile['file'], dest_file, report_bytes)
                        self.transferLeft = max(
                            0, initial_left - aFile['size'])
                    else:
                        self.transferLeft = self.transferLeft - aFile['size']
                        wroteFile = self._copyFile(
                            source, dest, aFile['file'], dest_file)

                    # record every failure, not just the first, so a
                    # failed backup can report exactly what went wrong
                    if(not wroteFile):
                        utils.log("Failed to write " + aFile['file'])
                        failures = getattr(self, '_copy_failures', None)
                        if failures is None:
                            failures = []
                            self._copy_failures = failures
                        failures.append(aFile['file'])
                        result = False

        return result

    def _copyFile(self, source, dest, sourceFile, destFile):
        result = True

        if(isinstance(source, DropboxFileSystem)):
            # if copying from cloud storage we need the file handle, use get_file
            result = source.get_file(sourceFile, destFile)
        else:
            # copy using normal method
            result = dest.put(sourceFile, destFile)

        return result

    def _addBackupDir(self, folder_name, root_path, dirList):
        utils.log('Backup set: ' + folder_name)
        fileManager = FileManager(self.xbmc_vfs)

        self.xbmc_vfs.set_root(xbmcvfs.translatePath(root_path))
        for aDir in dirList:
            fileManager.addDir(aDir)
        for exclusion in self._automaticExclusions():
            fileManager.addDir(exclusion)

        # walk all the root trees
        fileManager.walk()

        summary = fileManager.summary()
        self.transferSize = self.transferSize + fileManager.fileSize()
        files = fileManager.getFiles()

        return {
            "name": folder_name,
            "source": root_path,
            "plan_root": xbmcvfs.translatePath(root_path),
            "dest": self.remote_vfs.root_path,
            "files": files,
            "summary": summary,
        }

    def _collectBackupFiles(self):
        allFiles = []
        self.transferSize = 0
        self._skin_snapshot_metadata = None
        self._skin_managed_exclusions = []
        self._automatic_exclusion_rules = None
        skin_group = None
        if utils.getSettingBool('backup_skin_config'):
            skin_group = self._captureSkinConfigGroup()

        # AF3 capture can take long enough for the separate tvOS service to
        # detect an unsafe/default settings view. Recheck at the actual
        # simple-selection consumption boundary, after that capture and before
        # reading backup_selection_type or any simple backup_<set> selector.
        if not self._allowBackupSelection(
                'backup_selection_consumption_boundary'):
            self._closeVFS()
            return None

        selection_type = utils.getSettingInt('backup_selection_type')
        if(selection_type == 0):
            selectedDirs = self._readBackupConfig(
                utils.addon_dir() + "/resources/data/default_files.json")
            selected_set_ids = []
            for name in self.simple_directory_list:
                if(utils.getSettingBool('backup_' + name)):
                    selected_set_ids.append(name)
                    selected = selectedDirs[name]
                    allFiles.append(self._addBackupDir(
                        name, selected['root'], selected['dirs']))
            utils.log('Backup simple selection: ' +
                      ','.join(selected_set_ids), xbmc.LOGWARNING)
        else:
            selectedDirs = self._readBackupConfig(
                utils.data_dir() + "/custom_paths.json")
            for name in sorted(selectedDirs):
                selected = selectedDirs[name]
                allFiles.append(self._addBackupDir(
                    name, selected['root'], selected['dirs']))

        if skin_group is not None:
            allFiles.append(skin_group)

        utils.log('Backup planned set IDs: ' + ','.join(
            group['name'] for group in allFiles), xbmc.LOGWARNING)

        allFiles, alias_exclusions = collapse_identical_case_collisions(
            allFiles,
            lambda path: self._hashFile(path, cancellable=True),
            diagnostic_log=lambda message: utils.log(
                'Case-collision diagnostic: ' + message,
                xbmc.LOGWARNING))
        if alias_exclusions:
            self.transferSize = max(
                1.0,
                self.transferSize - sum(
                    item['size_kib'] for item in alias_exclusions))
            for exclusion in alias_exclusions:
                utils.log(
                    'Excluded byte-identical case-only source alias: '
                    '%s -> %s; kept %s -> %s' % (
                        exclusion['path'], exclusion['archive_path'],
                        exclusion['kept_path'],
                        exclusion['kept_archive_path']))

        self.backup_plan = summarize_file_groups(allFiles)
        utils.log('Backup plan: %s' % json.dumps(
            self.backup_plan, sort_keys=True))
        return allFiles

    def _allowBackupSelection(self, action):
        """Fail closed when tvOS settings become unsafe before selection."""
        guard = getattr(self, 'settings_guard', None)
        if guard is None:
            return True
        if not guard.allow_operation(action):
            utils.log('backup selection blocked: Kodi restart required',
                      xbmc.LOGWARNING)
            utils.showNotification(utils.getString(30237))
            return False
        guard.log_operation_boundary(action)
        return True

    def _skinRpc(self, method, **params):
        request = json.dumps({
            'jsonrpc': '2.0', 'method': method, 'params': params, 'id': 1,
        })
        response = json.loads(xbmc.executeJSONRPC(request))
        if not isinstance(response, dict) or 'error' in response:
            raise SkinAdapterError('Kodi could not complete ' + method)
        return response.get('result')

    def _skinAppearance(self):
        values = {}
        for setting in APPEARANCE_SETTINGS:
            try:
                result = self._skinRpc(
                    'Settings.GetSettingValue', setting=setting)
            except SkinAdapterError:
                # Kodi platforms may omit an individual appearance setting.
                # Preserve every value Kodi does expose without inventing one.
                continue
            if isinstance(result, dict) and result.get('value') is not None:
                values[setting] = result['value']
        return values

    def _captureSkinConfigGroup(self):
        if xbmc.getSkinDir() != AF3_ID:
            raise SkinAdapterError(
                'Arctic Fuse 3 must be active to capture its live settings')
        profile = xbmcvfs.translatePath('special://profile/')
        snapshot = capture_af3_snapshot(
            profile,
            self._skinRpc,
            source_device=xbmc.getInfoLabel('System.FriendlyName'),
            source_profile=xbmc.getInfoLabel('System.ProfileName'),
            skin_version=xbmcaddon.Addon(AF3_ID).getAddonInfo('version'),
            helper_version=xbmcaddon.Addon(
                SKIN_VARIABLES_ID).getAddonInfo('version'),
            settle=lambda: xbmc.sleep(2000),
            appearance_call=self._skinAppearance,
        )
        owned_paths = managed_source_paths(snapshot['files'])
        # A unique, per-invocation directory name - not a fixed
        # 'skin-staging' - matters here specifically: this path is read
        # twice more after this write (once to hash it for the
        # manifest, once later to copy its bytes into the archive), and
        # a fixed name meant a second, overlapping Backup Pro
        # invocation (confirmed reproducible this session: rapid
        # repeated triggers, or one invocation still finishing while
        # another starts) could rmtree()-and-rewrite the very files an
        # earlier invocation's own hash/copy reads were about to see,
        # producing an archived file whose bytes silently didn't match
        # the manifest hash recorded for it - the exact "AF3 snapshot
        # payload failed verification" restore failure reported
        # 2026-09-10. A unique path removes the possibility of two
        # invocations ever sharing one staging directory at all.
        stage_root = os.path.abspath(os.path.join(
            xbmcvfs.translatePath(utils.data_dir()),
            'skin-staging-' + uuid.uuid4().hex))
        data_root = os.path.abspath(xbmcvfs.translatePath(utils.data_dir()))
        if os.path.dirname(stage_root) != data_root:
            raise SkinAdapterError('invalid skin staging path')
        if os.path.lexists(stage_root):
            raise SkinAdapterError('skin staging path already exists')
        os.makedirs(stage_root)
        self._skin_stage_path = stage_root

        for relative, data in snapshot['files'].items():
            destination = os.path.abspath(os.path.join(stage_root, relative))
            if os.path.commonpath((stage_root, destination)) != stage_root:
                raise SkinAdapterError('skin staging path escaped its root')
            os.makedirs(os.path.dirname(destination), exist_ok=True)
            with open(destination, 'wb') as handle:
                handle.write(data)
                handle.flush()
                os.fsync(handle.fileno())

        self._skin_snapshot_metadata = snapshot['metadata']
        self._skin_managed_exclusions = [{
            'type': 'exclude',
            'path': xbmcvfs.translatePath('special://profile/' + relative),
            'adapter': AF3_ID,
            'reason': 'Captured by the authoritative AF3 configuration adapter',
        } for relative in owned_paths]
        group = self._addBackupDir('skin_config', stage_root, [{
            'type': 'include', 'path': stage_root, 'recurse': True,
        }])
        group['restore_path'] = 'special://profile/'
        return group

    def _cleanupSkinStage(self):
        stage_root = getattr(self, '_skin_stage_path', None)
        if not stage_root:
            return
        try:
            data_root = os.path.abspath(xbmcvfs.translatePath(utils.data_dir()))
            stage_root = os.path.abspath(stage_root)
            name = os.path.basename(stage_root)
            if (os.path.dirname(stage_root) != data_root
                    or not name.startswith('skin-staging-')
                    or os.path.islink(stage_root)):
                utils.log('Refusing unsafe skin-stage cleanup', xbmc.LOGWARNING)
                return
            if os.path.isdir(stage_root):
                shutil.rmtree(stage_root)
        finally:
            self._skin_stage_path = None

    def _automaticExclusions(self):
        if self._automatic_exclusion_rules is not None:
            return self._automatic_exclusion_rules

        self._automatic_exclusion_rules = []
        self._automatic_exclusion_rules.extend(
            getattr(self, '_skin_managed_exclusions', []))
        # This process/session marker is device-local safety state. Restoring
        # another process's PID/version marker could defeat restart detection,
        # so it must never enter an archive.
        self._automatic_exclusion_rules.append({
            'type': 'exclude',
            'path': xbmcvfs.translatePath(
                utils.data_dir() + MARKER_NAME),
            'adapter': 'script.backup.pro.settings-safety',
            'reason': 'Device-local tvOS settings-safety session marker',
        })
        if not utils.getSettingBool('exclude_tmdbh_image_cache'):
            return self._automatic_exclusion_rules

        try:
            addon = xbmcaddon.Addon(TMDB_HELPER_ID)
            try:
                configured = addon.getSettingString('image_location').strip()
            except AttributeError:
                configured = addon.getSetting('image_location').strip()
        except Exception as error:
            utils.log('TMDb Helper cache adapter unavailable: %s' % error,
                      xbmc.LOGWARNING)
            return self._automatic_exclusion_rules

        location = configured or (
            'special://profile/addon_data/%s' % TMDB_HELPER_ID)
        translated = xbmcvfs.translatePath(location)
        self._automatic_exclusion_rules.extend(
            tmdb_helper_cache_exclusions(translated))
        return self._automatic_exclusion_rules

    def _dateFormat(self, dirName):
        # create date_time object from foldername YYYYMMDDHHmm
        date_time = datetime(int(dirName[0:4]), int(dirName[4:6]), int(dirName[6:8]), int(dirName[8:10]), int(dirName[10:12]))

        # format the string based on region settings
        result = utils.getRegionalTimestamp(date_time, ['dateshort', 'time'])

        return result

    def _updateProgress(self, message=None):
        self.progressBar.updateProgress(int((float(self.transferSize - self.transferLeft) / float(self.transferSize)) * 100), message)

    def _rotateBackups(self):
        total_backups = utils.getSettingInt('backup_rotation')

        if(total_backups > 0):
            # get a list of valid backup folders
            dirs = self.listBackups(reverse=False)

            if(len(dirs) > total_backups):
                # remove backups to equal total wanted
                remove_num = 0

                # update the progress bar if it is available
                while(remove_num < (len(dirs) - total_backups)):
                    if self.progressBar.checkCancel():
                        utils.log('Backup retention cancelled', xbmc.LOGWARNING)
                        return False
                    self._updateProgress(utils.getString(30054) + " " + dirs[remove_num][1])
                    utils.log("Removing backup " + dirs[remove_num][0])

                    if(dirs[remove_num][0].split('.')[-1] == 'zip'):
                        # this is a file, remove it that way
                        removed = self.remote_vfs.rmfile(self.remote_vfs.clean_path(self.remote_base_path) + dirs[remove_num][0])
                    else:
                        removed = self.remote_vfs.rmdir(self.remote_vfs.clean_path(self.remote_base_path) + dirs[remove_num][0] + "/")

                    if not removed:
                        utils.log('Backup retention deletion failed',
                                  xbmc.LOGWARNING)
                        return False

                    remove_num = remove_num + 1
        return True

    def _finalizeBackup(self, success, artifact_path, compressed):
        if success:
            self._active_artifact = None
            if self._rotateBackups() is False:
                self._reportBackupFailure(
                    'an old backup could not be removed during retention')
                return False
            self._recordLastBackup(artifact_path)
            # the progress dialog must be fully closed before the success
            # dialog is shown, or a modal progress dialog stays open
            # underneath it and reappears, stale, the instant the user
            # dismisses success (_closeVFS() closes it again later, but
            # that is too late for what the user already saw on screen).
            self.progressBar.close()
            xbmcgui.Dialog().ok(
                utils.getString(30010), self._backupCompletionMessage())
            return True
        if artifact_path:
            if compressed:
                self.remote_vfs.rmfile(artifact_path)
            else:
                self.remote_vfs.rmdir(artifact_path)
        self._active_artifact = None
        self._reportBackupFailure()
        return False

    def _recordLastBackup(self, artifact_path):
        """Record a small local marker for buildStatusReport() to read.

        Status must stay local-only and never list the remote
        destination's contents (a Dropbox listing in particular would
        risk a slow or blocking network call just to open the Status
        screen) - so a successful backup's identity is recorded here,
        once, at completion time, instead of being discovered later by
        asking the remote what exists. Best-effort: a failure to write
        this marker must never fail an otherwise-successful backup.
        """
        try:
            name = os.path.basename(artifact_path.rstrip('/'))
            if not name:
                return
            data_root = xbmcvfs.translatePath(utils.data_dir())
            os.makedirs(data_root, exist_ok=True)
            with open(os.path.join(data_root, self.LAST_BACKUP_FILE), 'w',
                      encoding='utf-8') as handle:
                json.dump({'name': name}, handle)
        except Exception as error:
            utils.log('Unable to record last backup marker: %s' % error,
                      xbmc.LOGWARNING)

    def _lastBackupLabel(self):
        """Read back the marker _recordLastBackup() writes. Local-file
        read only - safe to call from buildStatusReport()."""
        try:
            path = os.path.join(
                xbmcvfs.translatePath(utils.data_dir()),
                self.LAST_BACKUP_FILE)
            if not os.path.isfile(path):
                return None
            with open(path, 'r', encoding='utf-8') as handle:
                recorded = json.load(handle)
            name = recorded.get('name', '')
            if not name:
                return None
            base = name.split('.')[0]
            return self._dateFormat(base)
        except Exception as error:
            utils.log('Unable to read last backup marker: %s' % error,
                      xbmc.LOGWARNING)
            return None

    def _reportBackupFailure(self, reason=None):
        """Show a persistent, actively-dismissed failure dialog instead
        of a transient notification, so a failed backup can never be
        mistaken for a partial success that was still saved. `reason`
        overrides any reason already recorded (e.g. from an exception
        caught higher up); per-file copy failures collected during this
        run (see _copyFiles()) are always included regardless."""
        if reason:
            self._failure_reason = reason
        # same rationale as _finalizeBackup's success path: the progress
        # dialog must be closed before this dialog shows, not left to be
        # closed later by _closeVFS().
        self.progressBar.close()
        xbmcgui.Dialog().ok(utils.getString(30010), self._backupFailureMessage())

    def _backupFailureMessage(self):
        parts = [utils.getString(30192)]
        reason = getattr(self, '_failure_reason', None)
        if reason:
            parts.append(str(reason))
        failures = getattr(self, '_copy_failures', None) or []
        if failures:
            parts.append('%d %s:' % (len(failures), utils.getString(30193)))
            for path in failures[:5]:
                parts.append(' - ' + path)
            remaining = len(failures) - 5
            if remaining > 0:
                parts.append('%d %s' % (remaining, utils.getString(30194)))
        return '\n'.join(parts)

    def _backupCompletionMessage(self):
        """Clear included/excluded counts, sizes, cache-regeneration
        explanation, and recovery availability for a completed backup.
        Only reached after verification already passed (see
        _runBackup()), so completion implies verified.
        """
        description = describe_backup_plan(
            getattr(self, 'backup_plan', None) or {})
        parts = [utils.getString(30168), utils.getString(30195)]
        parts.append('%d %s (%s)' % (
            description['included_files'], utils.getString(30169),
            utils.diskString(description['included_kib'] * 1024)))
        if description['excluded_files']:
            parts.append('%d %s (%s)' % (
                description['excluded_files'], utils.getString(30170),
                utils.diskString(description['excluded_kib'] * 1024)))
        if description['tmdb_cache_excluded_files']:
            parts.append(utils.getString(30171))
        if getattr(self, '_skin_snapshot_metadata', None) is not None:
            parts.append(utils.getString(30172))
        return '\n'.join(parts)

    def _discardActiveArtifact(self):
        artifact = getattr(self, '_active_artifact', None)
        if not artifact or getattr(self, 'remote_vfs', None) is None:
            return
        try:
            if getattr(self, '_active_artifact_compressed', False):
                self.remote_vfs.rmfile(artifact)
            else:
                self.remote_vfs.rmdir(artifact)
        except Exception as error:
            utils.log('Unable to remove failed backup artifact: %s' % error,
                      xbmc.LOGWARNING)
        finally:
            self._active_artifact = None

    def _createValidationFile(self, dirList):
        gui_settings = GuiSettingsManager()
        metadata = {
            "name": "Backup Pro Manifest",
            "created_utc": datetime.utcnow().strftime('%Y-%m-%dT%H:%M:%SZ'),
            "addon_id": utils.__addon_id__,
            "addon_version": xbmcaddon.Addon(
                utils.__addon_id__).getAddonInfo('version'),
            "kodi_version": xbmc.getInfoLabel('System.BuildVersion'),
            "type": 0,
            "system_settings": gui_settings.backup(),
            "addons": gui_settings.list_addons(),
            "plan": self.backup_plan,
        }
        if self._skin_snapshot_metadata is not None:
            metadata['skin_config'] = self._skin_snapshot_metadata
        valInfo = build_manifest(dirList, lambda path: self._hashFile(
            path, cancellable=True), metadata,
            check_cancel=self.progressBar.checkCancel)
        self.backup_manifest = valInfo

        local_manifest = xbmcvfs.translatePath(
            utils.data_dir() + MANIFEST_NAME)
        vFile = xbmcvfs.File(local_manifest, 'w')
        vFile.write(json.dumps(valInfo, sort_keys=True, separators=(',', ':')))
        vFile.write("")
        vFile.close()
        self.backup_manifest_file_hash = self._hashFile(local_manifest)

        success = self._copyFile(
            self.xbmc_vfs, self.remote_vfs, local_manifest,
            self.remote_vfs.root_path + MANIFEST_NAME)

        # remove the validation file
        xbmcvfs.delete(local_manifest)

        if(success):
            # android requires a .nomedia file to not index the directory as media
            if(not xbmcvfs.exists(xbmcvfs.translatePath(utils.data_dir() + ".nomedia"))):
                nmFile = xbmcvfs.File(xbmcvfs.translatePath(utils.data_dir() + ".nomedia"), 'w')
                nmFile.close()

            success = self._copyFile(self.xbmc_vfs, self.remote_vfs, xbmcvfs.translatePath(utils.data_dir() + ".nomedia"), self.remote_vfs.root_path + ".nomedia")

        return success

    def _checkValidationFile(self, path):
        result = None
        restore_manifest = xbmcvfs.translatePath(
            utils.data_dir() + "backup-pro.restore-manifest.json")

        try:
            copied = self._copyFile(
                self.remote_vfs, self.xbmc_vfs, path + MANIFEST_NAME,
                restore_manifest)
            if not copied:
                utils.log('Backup Pro manifest could not be read',
                          xbmc.LOGWARNING)
                return None
            with xbmcvfs.File(restore_manifest, 'r') as vFile:
                jsonString = vFile.read()
        except Exception as error:
            utils.log('Backup Pro manifest read failed: %s' % error,
                      xbmc.LOGWARNING)
            return None
        finally:
            if xbmcvfs.exists(restore_manifest):
                xbmcvfs.delete(restore_manifest)

        try:
            result = load_manifest(jsonString)

            if(xbmc.getInfoLabel('System.BuildVersion') != result['kodi_version']):
                shouldContinue = xbmcgui.Dialog().yesno(utils.getString(30085), "%s\n%s" % (utils.getString(30086), utils.getString(30044)))

                if(not shouldContinue):
                    result = None

        except (ArchiveValidationError, KeyError) as error:
            utils.log('Backup Pro manifest rejected: %s' % error,
                      xbmc.LOGWARNING)
            result = None

        return result

    def _hashFile(self, path, cancellable=False):
        with xbmcvfs.File(xbmcvfs.translatePath(path), 'r') as source:
            check_cancel = (self.progressBar.checkCancel
                            if cancellable else None)
            return sha256_reader(
                source.readBytes, check_cancel=check_cancel)

    def _hashVfsFile(self, vfs, path, cancellable=False):
        if not isinstance(vfs, DropboxFileSystem):
            return self._hashFile(path, cancellable=cancellable)

        local_copy = xbmcvfs.translatePath(
            utils.data_dir() + 'backup-pro.readback.tmp')
        try:
            if xbmcvfs.exists(local_copy):
                xbmcvfs.delete(local_copy)
            if not vfs.get_file(path, local_copy):
                raise IOError('remote download failed')
            if cancellable and self.progressBar.checkCancel():
                raise ArchiveValidationError('remote read-back cancelled')
            return self._hashFile(local_copy, cancellable=cancellable)
        finally:
            if xbmcvfs.exists(local_copy):
                xbmcvfs.delete(local_copy)

    def _verifyFolderBackup(self, backup_root):
        root = self.remote_vfs.clean_path(backup_root)
        try:
            manifest_hash = self._hashVfsFile(
                self.remote_vfs, root + MANIFEST_NAME, cancellable=True)
        except Exception as error:
            raise ArchiveValidationError(
                'unable to read back published manifest: %s' % error)
        if manifest_hash != self.backup_manifest_file_hash:
            raise ArchiveValidationError(
                'published manifest does not match the local manifest')
        result = verify_manifest_files(
            self.backup_manifest,
            lambda relative: self._hashVfsFile(
                self.remote_vfs, root + relative, cancellable=True),
            check_cancel=self.progressBar.checkCancel)
        utils.log('Verified folder backup: %s' % json.dumps(result))
        return result

    def _verifyCompressedUpload(self, local_zip, remote_zip):
        try:
            local_checksum, local_size = self._hashFile(
                local_zip, cancellable=True)
            remote_checksum, remote_size = self._hashVfsFile(
                self.remote_vfs, remote_zip, cancellable=True)
        except Exception as error:
            raise ArchiveValidationError(
                'unable to read back uploaded ZIP: %s' % error)
        if remote_size != local_size or remote_checksum != local_checksum:
            raise ArchiveValidationError(
                'uploaded ZIP does not match the verified local archive')
        result = {'file_count': 1, 'total_bytes': local_size}
        utils.log('Verified compressed backup upload: %s' % json.dumps(
            result, sort_keys=True))
        return result

    def _createResumeBackupFile(self):
        with xbmcvfs.File(xbmcvfs.translatePath(utils.data_dir() + "resume.txt"), 'w') as f:
            f.write(self.restore_point)

    def _readBackupConfig(self, aFile):
        with xbmcvfs.File(xbmcvfs.translatePath(aFile), 'r') as f:
            jsonString = f.read()
        return json.loads(jsonString)


class FileManager(FilePlanner):
    def __init__(self, vfs):
        FilePlanner.__init__(
            self,
            vfs,
            translate=xbmcvfs.translatePath,
            validate=xbmcvfs.validatePath,
            logger=utils.log,
            verbose=utils.getSettingBool('verbose_logging'),
        )

    def fileSize(self):
        # Preserve upstream's non-zero progress denominator for empty sets.
        return max(1.0, FilePlanner.fileSize(self))
