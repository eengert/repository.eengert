"""Consistent staging of live SQLite databases for backup.

A byte-for-byte read of a database that another process is writing can see
torn or resized content (and, in WAL mode, silently omits committed data that
lives only in the ``-wal`` sidecar). This module detects SQLite files by their
header and copies each one into a private staging file with SQLite's online
backup API, which yields a transactionally consistent, self-contained
database. Callers then use the staged copy as the *only* source for manifest
hashing and archive creation.

Everything here is fail-closed: a detected SQLite database that cannot be
snapshotted raises ``SqliteSnapshotError``; there is never a fallback to the
live file. The module imports ``sqlite3`` lazily and has no Kodi dependency.
"""
from __future__ import unicode_literals

import os
import shutil
import time
import uuid

SQLITE_MAGIC = b'SQLite format 3\x00'
# SQLite's smallest possible database is one 512-byte page.
MIN_SQLITE_BYTES = 512

BUSY_TIMEOUT_SECONDS = 10.0
MAX_ATTEMPTS = 3
RETRY_DELAY_SECONDS = 1.0
# Cumulative time the stage may spend *waiting* (failed attempts and retry
# delays) across all databases. Healthy copy time is never counted, so many
# large, valid databases cannot exhaust it.
TOTAL_WAIT_BUDGET_SECONDS = 120.0
FREE_SPACE_MARGIN_BYTES = 16 * 1024 * 1024
_SQLITE_BUSY = 5
_SQLITE_LOCKED = 6


class SqliteSnapshotError(Exception):
    pass


def is_sqlite_file(path):
    """True when the file starts with the SQLite 3 header (any extension)."""
    try:
        if os.path.getsize(path) < MIN_SQLITE_BYTES:
            return False
        with open(path, 'rb') as handle:
            return handle.read(len(SQLITE_MAGIC)) == SQLITE_MAGIC
    except OSError:
        return False


def _load_sqlite3():
    try:
        import sqlite3
    except ImportError as error:
        raise SqliteSnapshotError(
            'the sqlite3 module is not available: %s' % error)
    if not hasattr(sqlite3.Connection, 'backup'):
        raise SqliteSnapshotError(
            'the sqlite3 backup API is not available in this Python')
    return sqlite3


def _source_uri(path, mode='ro'):
    from urllib.parse import quote
    return 'file:' + quote(os.path.abspath(path)) + '?mode=' + mode


def _remove_quietly(path):
    try:
        os.remove(path)
    except OSError:
        pass


def _open_source(sqlite3, source, busy_timeout):
    """Open the live database for reading without issuing any write.

    Read-only is preferred (it never touches the live file). A WAL-mode
    database with no -wal/-shm sidecars (the normal idle state once every
    connection has closed) cannot be opened ``mode=ro`` because the shared
    memory file cannot be created, so fall back to an ordinary connection:
    SQLite then creates the sidecars as any reader would, and this module
    still only reads through the backup API.
    """
    try:
        connection = sqlite3.connect(
            _source_uri(source), uri=True, timeout=busy_timeout)
        # Opening is lazy; force the first read so open failures surface here.
        connection.execute('PRAGMA schema_version').fetchone()
        return connection
    except sqlite3.OperationalError as error:
        try:
            connection.close()
        except Exception:
            pass
        # Only an open failure justifies the fallback. A busy/locked
        # database already waited out the busy timeout once; retrying the
        # open would double the wait for no benefit.
        if 'unable to open' not in str(error).lower():
            raise
    return sqlite3.connect(
        _source_uri(source, 'rw'), uri=True, timeout=busy_timeout)


def _snapshot_once(sqlite3, source, destination, busy_timeout, clock,
                   check_cancel):
    """One bounded attempt; raises sqlite3.Error/SqliteSnapshotError."""
    deadline = clock() + busy_timeout

    def progress(status, _remaining, _total):
        # Called after every backup step, including BUSY/LOCKED ones that
        # the C loop would otherwise retry forever. Only those two statuses
        # are waiting; a long but healthy copy (OK/DONE) is never a timeout.
        if check_cancel is not None and check_cancel():
            raise SqliteSnapshotError('snapshot cancelled')
        if status in (_SQLITE_BUSY, _SQLITE_LOCKED) and clock() > deadline:
            raise SqliteSnapshotError('database stayed busy or locked')

    source_connection = _open_source(sqlite3, source, busy_timeout)
    try:
        target = sqlite3.connect(destination, timeout=busy_timeout)
        try:
            # One step: the whole database is copied under a single read
            # transaction, so the result is one consistent state.
            source_connection.backup(
                target, pages=-1, progress=progress, sleep=0.1)
            # Fold any WAL activity of the staged file into the main file so
            # it is self-contained, then prove it is structurally sound.
            target.execute('PRAGMA wal_checkpoint(TRUNCATE)').fetchall()
            checked = target.execute('PRAGMA quick_check').fetchall()
            if checked != [('ok',)]:
                raise SqliteSnapshotError('staged copy failed quick_check')
        finally:
            target.close()
    finally:
        source_connection.close()

    for suffix in ('-wal', '-shm', '-journal'):
        sidecar = destination + suffix
        if os.path.exists(sidecar):
            if suffix == '-wal' and os.path.getsize(sidecar) != 0:
                raise SqliteSnapshotError(
                    'staged copy left uncheckpointed WAL data')
            _remove_quietly(sidecar)


def snapshot_database(source, destination, busy_timeout=BUSY_TIMEOUT_SECONDS,
                      attempts=MAX_ATTEMPTS, retry_delay=RETRY_DELAY_SECONDS,
                      clock=time.monotonic, sleep=time.sleep,
                      check_cancel=None, log=None, on_wait=None):
    """Copy a live SQLite database to ``destination`` consistently.

    Returns the staged size in bytes. Raises SqliteSnapshotError once the
    bounded retries are exhausted; the partial destination is removed.
    ``on_wait(seconds)`` is told how long each failed attempt plus retry
    delay waited; it may raise SqliteSnapshotError to stop retrying.
    """
    sqlite3 = _load_sqlite3()
    last = None
    for attempt in range(1, attempts + 1):
        _remove_quietly(destination)
        attempt_started = clock()
        try:
            _snapshot_once(
                sqlite3, source, destination, busy_timeout, clock,
                check_cancel)
            return os.path.getsize(destination)
        except SqliteSnapshotError as error:
            last = error
        except sqlite3.Error as error:
            last = SqliteSnapshotError(
                '%s: %s' % (type(error).__name__, error))
        except OSError as error:
            last = SqliteSnapshotError('%s: %s' % (
                type(error).__name__, error))
        for suffix in ('', '-wal', '-shm', '-journal'):
            _remove_quietly(destination + suffix)
        if log is not None:
            log('SQLite snapshot attempt %d/%d failed: %s' % (
                attempt, attempts, last))
        if 'cancelled' in str(last):
            break
        waited = clock() - attempt_started
        if attempt < attempts:
            sleep(retry_delay)
            waited += retry_delay
        if on_wait is not None:
            on_wait(waited)
    raise last


class SqliteStager:
    """Stage every SQLite database found in a planned set of file groups."""

    def __init__(self, stage_parent, log=None, warn=None, check_cancel=None,
                 busy_timeout=BUSY_TIMEOUT_SECONDS, attempts=MAX_ATTEMPTS,
                 retry_delay=RETRY_DELAY_SECONDS,
                 total_wait_budget=TOTAL_WAIT_BUDGET_SECONDS, clock=time.monotonic,
                 sleep=time.sleep, free_space=None):
        self.stage_parent = os.path.abspath(stage_parent)
        self.log = log or (lambda message: None)
        self.warn = warn or self.log
        self.check_cancel = check_cancel
        self.busy_timeout = busy_timeout
        self.attempts = attempts
        self.retry_delay = retry_delay
        self.total_wait_budget = total_wait_budget
        self.waited = 0.0
        self.clock = clock
        self.sleep = sleep
        self.free_space = free_space or (
            lambda path: shutil.disk_usage(path).free)
        self.stage_root = None

    def _record_wait(self, seconds):
        self.waited += seconds
        if self.waited > self.total_wait_budget:
            raise SqliteSnapshotError(
                'SQLite snapshots waited too long on busy databases')

    def _logical(self, group, item):
        root = group.get('plan_root', group['source'])
        path = item['file']
        normalized_root = root.replace('\\', '/').rstrip('/')
        normalized = path.replace('\\', '/')
        if normalized.startswith(normalized_root + '/'):
            normalized = normalized[len(normalized_root) + 1:]
        return '%s/%s' % (group['name'], normalized)

    def stage(self, groups):
        """Replace each SQLite file's read source with a staged snapshot.

        Mutates matching items: ``read_path`` (staged file) is added and
        ``size`` (KiB) is updated. Returns the number of databases staged
        and the change in total size, in KiB.
        """
        candidates = []
        for group in groups:
            for item in group.get('files', []):
                if item.get('is_dir') or '://' in item['file']:
                    continue
                if is_sqlite_file(item['file']):
                    candidates.append((group, item))
        if not candidates:
            return 0, 0.0

        for group, item in candidates:
            self.log('SQLite database detected: %s' %
                     self._logical(group, item))

        # A staged copy folds the committed WAL into the main file, so it can
        # be larger than the main file alone: budget main + WAL per database.
        needed = 0
        for _group, item in candidates:
            needed += int(item['size'] * 1024)
            try:
                needed += os.path.getsize(item['file'] + '-wal')
            except OSError:
                pass
        os.makedirs(self.stage_parent, exist_ok=True)
        if self.free_space(self.stage_parent) < needed + FREE_SPACE_MARGIN_BYTES:
            raise SqliteSnapshotError(
                'not enough free space to stage SQLite snapshots '
                '(about %d KiB needed)' % (needed // 1024 + 1))

        self.stage_root = os.path.join(
            self.stage_parent, 'sqlite-staging-' + uuid.uuid4().hex)
        os.makedirs(self.stage_root)
        delta = 0.0
        for index, (group, item) in enumerate(candidates):
            logical = self._logical(group, item)
            if self.check_cancel is not None and self.check_cancel():
                raise SqliteSnapshotError('SQLite snapshot cancelled')
            staged = os.path.join(self.stage_root, '%d.sqlite' % index)
            try:
                source_wal = os.path.getsize(item['file'] + '-wal')
            except OSError:
                source_wal = 0
            self.log('SQLite snapshot starting: %s (source %d bytes, '
                     'wal %d bytes)' % (
                         logical, int(item['size'] * 1024), source_wal))
            began = self.clock()
            try:
                size = snapshot_database(
                    item['file'], staged, busy_timeout=self.busy_timeout,
                    attempts=self.attempts, retry_delay=self.retry_delay,
                    clock=self.clock, sleep=self.sleep,
                    check_cancel=self.check_cancel, log=self.warn,
                    on_wait=self._record_wait)
            except SqliteSnapshotError as error:
                self.warn('SQLite snapshot failed: %s: %s' % (logical, error))
                raise SqliteSnapshotError(
                    'SQLite snapshot failed for %s: %s' % (logical, error))
            self.log('SQLite snapshot complete: %s (%d bytes staged, '
                     '%.1f s)' % (logical, size, self.clock() - began))
            new_kib = size / 1024.0
            change = new_kib - item['size']
            delta += change
            item['read_path'] = staged
            item['size'] = new_kib
            summary = group.get('summary')
            if summary is not None:
                summary['included_kib'] = (
                    float(summary.get('included_kib', 0.0)) + change)
        return len(candidates), delta

    def cleanup(self):
        stage_root = self.stage_root
        self.stage_root = None
        if not stage_root:
            return
        name = os.path.basename(stage_root)
        if (os.path.dirname(stage_root) != self.stage_parent
                or not name.startswith('sqlite-staging-')
                or os.path.islink(stage_root)):
            self.log('Refusing unsafe SQLite staging cleanup')
            return
        try:
            shutil.rmtree(stage_root)
            self.log('SQLite staging removed')
        except OSError as error:
            self.log('SQLite staging cleanup failed: %s' % error)
