# Arctic Fuse 3 Patch Service v1.3.12

This Kodi service preserves a personal Arctic Fuse 3 modification after skin updates:

1. A third horizontal Top-menu display option, `Icon + Text`, using a regular, slightly smaller uppercase label beside each icon.

## v1.3.12 AF3 3.4.20 settings layout and retry correction

AF3 3.4.20 moved the Home style setting from `1080i/Includes_SkinSettings.xml` into `shortcuts/skinvariables-skinsettings.json`. The service now patches that JSON source while retaining support for older AF3 XML settings files. Patch revision 3 forces the service to retry AF3 3.4.20.

The service now leaves an AF3 version pending when an Icon + Text anchor is missing or patching raises an error. It retries instead of recording an incomplete patch as applied; repeated warnings are limited to one per Kodi session.

## v1.3.11 AF3 3.4.17 compatibility and reload detection

The Icon + Text patch now follows AF3's current hub-label variables and applies cleanly to AF3 3.4.17. The Top-menu Up patch has been retired because that feature is now native to AF3. A patch revision is recorded with the AF3 version, so this service update retries the current skin version even if an older service recorded it after an anchor mismatch.

The service also places a private marker on Kodi's Home window. `ReloadSkin()` recreates that window and clears the marker, which triggers an immediate, idempotent patch check. If that check changes files, the service performs one follow-up reload when Home is active so Kodi loads the patched XML. The normal background check now runs every 5 seconds; the 30-second write-settling guard remains in place during an active AF3 update.

## v1.3.10 reload only from Home

A patch that changes the skin no longer reloads it straight away. The reload waits until Home is the active window, checked every 5 seconds. Reloading from another window, such as a Hub with live widgets, was seen to freeze Kodi. A pending reload is kept only in memory, so a restart loads the patched files without one.

## v1.3.9 retry on failure

If a patch raises an error, such as a file being locked during an update, the version is not recorded and the patches are retried on the next check. The service stops after 5 failed attempts for a version, records it, and logs that it has given up until the next AF3 version. Each error is logged once per Kodi session. An anchor that no longer matches still skips that patch without retrying. Known limitation: if a patch writes one file and then raises before another, the changed file may not trigger a skin reload until Kodi restarts.

## v1.3.8 version-gated reapply

The service records the AF3 version its patches were last applied to, in `special://profile/addon_data/service.af3.topupaction/applied-state.json`. Each check compares that with the installed `addon.xml` version. The patches run only when the version is new, and only after the skin's `addon.xml` and `1080i` files have been unchanged for 30 seconds. An AF3 update therefore gets one reapply and one skin reload, instead of a check and reload pass on every minute.

## v1.3.7 use upstream Information Summary

The service no longer patches Information > Summary because the Kodi version row was merged upstream in Arctic Fuse 3 PR #370. It also safely restores AF3's original footer, retiring the longer Kodi + AF3 footer from version 1.3.6.

## v1.3.6 Kodi version display

The settings footer now uses Kodi's current short-version and build-code labels before the AF3 version. Information > Summary also includes a dedicated Kodi Version row.

## v1.3.5 remove obsolete focus workaround

The Home startup/reload focus workaround has been retired after identifying the actual cause as the default Spotlight path returning an empty set. Existing installations safely restore AF3's original startup action and remove only the unchanged helper JSON previously created by this service.

## v1.3 Icon + Text style

The Home menu appearance setting now cycles through Text, Icon, and Icon + Text. The additional style affects only the horizontal/Top menu and leaves both existing styles and the vertical menu unchanged.

### v1.3.1 layout correction

The selected Icon + Text item now uses one auto-width highlight pill around both the icon and label. The active item's unfocused base layer is hidden so a duplicate icon cannot appear after the text.

### v1.3.2 compact focused expansion

Unfocused Icon + Text menu items now collapse to icon-only width. The active item expands over one auto-sized pill background, with a 10px icon gap and approximately equal 20px padding at both ends. Combined-mode item gaps and collapsed widths are reduced, and the focused item's reserved width is trimmed so neighboring icons remain equally close on either side.

### v1.3.3 padding adjustment

The active pill is extended by 7px to add a little more breathing room after the label without moving its visible icon or text.

### v1.3.4 extensible Top-menu Up setting

The Top-menu Up action now uses the string setting `HomeSwitcher.OnUp`, matching the upstream review change. An empty value keeps Submenu as the default, while `options` opens Options. Existing installations using the previous boolean setting are migrated automatically without losing an Options selection.

The service checks the AF3 version periodically and reapplies known-safe patches once for each new AF3 version. If expected anchors change, the affected patch is skipped rather than guessing.
