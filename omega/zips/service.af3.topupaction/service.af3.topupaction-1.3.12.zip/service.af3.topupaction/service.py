# -*- coding: utf-8 -*-
import hashlib
import json
import os
import time
import xml.etree.ElementTree as ElementTree

import xbmc
import xbmcgui
import xbmcvfs

ADDON_ID = "service.af3.topupaction"
SKIN_ID = "skin.arctic.fuse.3"
CHECK_SECONDS = 5
RELOAD_POLL_SECONDS = 1
SETTLE_SECONDS = 30
FAILURE_LIMIT = 5
STATE_FILE = "applied-state.json"
PATCH_REVISION = 3
RELOAD_WATCH_PROPERTY = "AF3Patch.ReloadWatch"
TOP_UP_MARKER = "HomeSwitcher.OnUp"
OLD_TOP_UP_SETTING = "HomeSwitcher.TopUpOpensOptions"
ICON_TEXT_MARKER = "HomeSwitcher.EnableIconText"
ICON_TEXT_LAYOUT_MARKER = (
    '<visible>$PARAM[use_icon_text] + !Window.IsVisible($PARAM[window])</visible>'
)
ICON_TEXT_COLLAPSE_MARKER = "<left>70</left>"
ICON_TEXT_SPACING_MARKER = "<left>-520</left>"
ICON_TEXT_PADDING_MARKER = "<textoffsetx>48.5</textoffsetx>"
OBSOLETE_HOME_FOCUS_FILE = "skinvariables-homefocus.json"
OBSOLETE_HOME_FOCUS_CALL = (
    "RunScript(script.skinvariables,run_executebuiltin="
    "special://skin/shortcuts/skinvariables-homefocus.json,use_rules=True)"
)
OBSOLETE_HOME_FOCUS_SHA256 = (
    "03b792dc28b0ce43691df9ff0451808faaca89894813b5b87a155dec25ed8ad2"
)


_LOGGED = set()
_failed_attempts = {}
_reload_pending = False
_reload_watch_token = "{}-{}".format(os.getpid(), time.time())


def log(message, level=xbmc.LOGINFO):
    xbmc.log("[{}] {}".format(ADDON_ID, message), level)


def log_once(message, level=xbmc.LOGINFO):
    """Log a message once per Kodi session, so a retried failure does not repeat every minute."""
    if message in _LOGGED:
        return
    _LOGGED.add(message)
    log(message, level)


def read_text(path):
    with open(path, "r", encoding="utf-8") as handle:
        return handle.read()


def write_text(path, content):
    tmp = path + ".af3patch.tmp"
    with open(tmp, "w", encoding="utf-8", newline="") as handle:
        handle.write(content)
    os.replace(tmp, path)


def replace_once(content, old, new, label):
    count = content.count(old)
    if count == 0:
        if new in content:
            return content, False, None
        return content, False, "Expected anchor not found for {}".format(label)
    if count != 1:
        return content, False, "Expected exactly one anchor for {}, found {}".format(label, count)
    return content.replace(old, new, 1), True, None


def replace_count(content, old, new, label, expected):
    count = content.count(old)
    if count != expected:
        return content, False, "Expected {} anchors for {}, found {}".format(
            expected, label, count
        )
    return content.replace(old, new), True, None


def patch_top_up(skin_root):
    """Apply the current two-file Top-menu Up action patch."""
    home_path = os.path.join(skin_root, "1080i", "Includes_Home.xml")
    settings_path = os.path.join(skin_root, "1080i", "SkinSettings.xml")
    if not os.path.isfile(home_path) or not os.path.isfile(settings_path):
        log("Top-menu patch: expected AF3 files are missing; skipped.", xbmc.LOGWARNING)
        return False

    home = read_text(home_path)
    settings = read_text(settings_path)

    home_new = home
    settings_new = settings

    old_label = (
        '    <variable name="Label_Setting_TopMenuUpAction">\n'
        '        <value condition="Skin.HasSetting(HomeSwitcher.TopUpOpensOptions)">$LOCALIZE[33063]</value>\n'
        '        <value>$LOCALIZE[1034]</value>\n'
        '    </variable>'
    )
    new_label = (
        '    <variable name="Label_Setting_TopMenuUpAction">\n'
        '        <value condition="Skin.String(HomeSwitcher.OnUp,options)">$LOCALIZE[33063]</value>\n'
        '        <value condition="String.IsEmpty(Skin.String(HomeSwitcher.OnUp))">$LOCALIZE[1034]</value>\n'
        '    </variable>'
    )
    home_new = home_new.replace(old_label, new_label, 1)

    old_actions = (
        '        <onup condition="Skin.HasSetting(HomeSwitcher.TopUpOpensOptions)">ActivateWindow(1170)</onup>\n'
        '        <onup condition="!Skin.HasSetting(HomeSwitcher.TopUpOpensOptions)">ActivateWindow(1181)</onup>'
    )
    new_actions = (
        '        <onup condition="Skin.String(HomeSwitcher.OnUp,options)">ActivateWindow(1170)</onup>\n'
        '        <onup condition="String.IsEmpty(Skin.String(HomeSwitcher.OnUp))">ActivateWindow(1181)</onup>'
    )
    home_new = home_new.replace(old_actions, new_actions, 1)

    old_setting_action = (
        '                            <onclick>Skin.ToggleSetting(HomeSwitcher.TopUpOpensOptions)</onclick>'
    )
    new_setting_actions = (
        '                            <onclick condition="String.IsEmpty(Skin.String(HomeSwitcher.OnUp))">Skin.SetString(HomeSwitcher.OnUp,options)</onclick>\n'
        '                            <onclick condition="Skin.String(HomeSwitcher.OnUp,options)">Skin.Reset(HomeSwitcher.OnUp)</onclick>'
    )
    settings_new = settings_new.replace(old_setting_action, new_setting_actions, 1)

    if 'variable name="Label_Setting_TopMenuUpAction"' not in home_new:
        home_new, _, error = replace_once(
            home_new,
            '    <variable name="Home_Icon_home">\n',
            '    <variable name="Label_Setting_TopMenuUpAction">\n'
            '        <value condition="Skin.String(HomeSwitcher.OnUp,options)">$LOCALIZE[33063]</value>\n'
            '        <value condition="String.IsEmpty(Skin.String(HomeSwitcher.OnUp))">$LOCALIZE[1034]</value>\n'
            '    </variable>\n\n'
            '    <variable name="Home_Icon_home">\n',
            "Top-menu label variable",
        )
        if error:
            log(error + "; Top-menu patch skipped.", xbmc.LOGWARNING)
            return False

    if TOP_UP_MARKER not in home_new[home_new.find('<include name="Home_Horz_Movement">'):]:
        home_new, _, error = replace_once(
            home_new,
            '        <onup>ActivateWindow(1181)</onup>\n        <oninfo>ActivateWindow(1181)</oninfo>',
            '        <onup condition="Skin.String(HomeSwitcher.OnUp,options)">ActivateWindow(1170)</onup>\n'
            '        <onup condition="String.IsEmpty(Skin.String(HomeSwitcher.OnUp))">ActivateWindow(1181)</onup>\n'
            '        <oninfo>ActivateWindow(1181)</oninfo>',
            "Top-menu Up action",
        )
        if error:
            log(error + "; Top-menu patch skipped.", xbmc.LOGWARNING)
            return False

    if 'description="Top Menu Up Action"' not in settings_new:
        anchor = (
            '                        <include content="SkinSettings_Items_Menus">\n'
            '                            <param name="baseid">0</param>\n'
            '                        </include>\n'
        )
        replacement = anchor + (
            '                        <include content="Settings_Button" description="Top Menu Up Action">\n'
            '                            <param name="dialog">false</param>\n'
            '                            <param name="window">skinsettings</param>\n'
            '                            <param name="baseid">0</param>\n'
            '                            <param name="id">090</param>\n'
            '                            <param name="control">button</param>\n'
            '                            <label>$LOCALIZE[31349]</label>\n'
            '                            <label2>$VAR[Label_Setting_TopMenuUpAction]</label2>\n'
            '                            <onclick condition="String.IsEmpty(Skin.String(HomeSwitcher.OnUp))">Skin.SetString(HomeSwitcher.OnUp,options)</onclick>\n'
            '                            <onclick condition="Skin.String(HomeSwitcher.OnUp,options)">Skin.Reset(HomeSwitcher.OnUp)</onclick>\n'
            '                            <visible>!Skin.HasSetting(HomeSwitcher.Vertical)</visible>\n'
            '                        </include>\n'
        )
        settings_new, _, error = replace_once(
            settings_new, anchor, replacement, "Top-menu Skin Settings button"
        )
        if error:
            log(error + "; Top-menu patch skipped.", xbmc.LOGWARNING)
            return False

    changed = False
    if home_new != home:
        write_text(home_path, home_new)
        changed = True
    if settings_new != settings:
        write_text(settings_path, settings_new)
        changed = True

    if changed:
        log("Reapplied configurable Top-menu Up action patch.")
    return changed


def migrate_top_up_setting():
    """Preserve the old boolean Options choice in the new string setting."""
    if xbmc.getSkinDir() != SKIN_ID:
        return False
    if not xbmc.getCondVisibility("Skin.HasSetting({})".format(OLD_TOP_UP_SETTING)):
        return False

    xbmc.executebuiltin("Skin.SetString(HomeSwitcher.OnUp,options)")
    xbmc.executebuiltin("Skin.Reset({})".format(OLD_TOP_UP_SETTING))
    log("Migrated Top-menu Up action setting to HomeSwitcher.OnUp.")
    return True


def icon_text_settings_path(skin_root):
    """Return the AF3 settings source used by this skin version."""
    candidates = (
        os.path.join(skin_root, "1080i", "Includes_SkinSettings.xml"),
        os.path.join(skin_root, "shortcuts", "skinvariables-skinsettings.json"),
    )
    return next((candidate for candidate in candidates if os.path.isfile(candidate)), None)


def patch_icon_text(skin_root):
    """Add Icon + Text, returning None if an expected AF3 anchor is missing."""
    home_path = os.path.join(skin_root, "1080i", "Includes_Home.xml")
    labels_path = os.path.join(skin_root, "1080i", "Includes_Labels.xml")
    settings_path = icon_text_settings_path(skin_root)
    if not settings_path or not os.path.isfile(home_path) or not os.path.isfile(labels_path):
        log_once("Icon + Text patch: expected AF3 files are missing; skipped.", xbmc.LOGWARNING)
        return None

    home = read_text(home_path)
    labels = read_text(labels_path)
    settings = read_text(settings_path)
    home_new = home
    labels_new = labels
    settings_new = settings

    if ICON_TEXT_MARKER not in labels_new:
        labels_new, _, error = replace_once(
            labels_new,
            '    <variable name="Label_Setting_HomeIcons">\n'
            '        <value condition="Skin.HasSetting(HomeSwitcher.EnableIcons)">$LOCALIZE[536]</value>\n'
            '        <value>$LOCALIZE[31329]</value>\n'
            '    </variable>',
            '    <variable name="Label_Setting_HomeIcons">\n'
            '        <value condition="Skin.HasSetting(HomeSwitcher.EnableIconText)">Icon + Text</value>\n'
            '        <value condition="Skin.HasSetting(HomeSwitcher.EnableIcons)">$LOCALIZE[536]</value>\n'
            '        <value>$LOCALIZE[31329]</value>\n'
            '    </variable>',
            "Icon + Text setting label",
        )
        if error:
            log_once(error + "; Icon + Text patch skipped.", xbmc.LOGWARNING)
            return None

    if ICON_TEXT_MARKER not in settings_new:
        if settings_path.endswith(".json"):
            settings_new, _, error = replace_once(
                settings_new,
                '            "onclick": [\n'
                '                {\n'
                '                    "action": "Skin.ToggleSetting(HomeSwitcher.EnableIcons)"\n'
                '                }\n'
                '            ]',
                '            "onclick": [\n'
                '                {\n'
                '                    "action": "Skin.Reset(HomeSwitcher.EnableIconText)",\n'
                '                    "condition": "Skin.HasSetting(HomeSwitcher.EnableIconText)"\n'
                '                },\n'
                '                {\n'
                '                    "action": "Skin.Reset(HomeSwitcher.EnableIcons)",\n'
                '                    "condition": "Skin.HasSetting(HomeSwitcher.EnableIcons)"\n'
                '                },\n'
                '                {\n'
                '                    "action": "Skin.SetBool(HomeSwitcher.EnableIconText)",\n'
                '                    "condition": "Skin.HasSetting(HomeSwitcher.EnableIcons)"\n'
                '                },\n'
                '                {\n'
                '                    "action": "Skin.SetBool(HomeSwitcher.EnableIcons)",\n'
                '                    "condition": "![Skin.HasSetting(HomeSwitcher.EnableIcons) | Skin.HasSetting(HomeSwitcher.EnableIconText)]"\n'
                '                }\n'
                '            ]',
                "three-state Top-menu setting in SkinVariables JSON",
            )
        else:
            settings_new, _, error = replace_once(
                settings_new,
                '            <onclick>Skin.ToggleSetting(HomeSwitcher.EnableIcons)</onclick>',
                '            <onclick condition="Skin.HasSetting(HomeSwitcher.EnableIconText)">Skin.Reset(HomeSwitcher.EnableIconText)</onclick>\n'
                '            <onclick condition="Skin.HasSetting(HomeSwitcher.EnableIcons)">Skin.Reset(HomeSwitcher.EnableIcons)</onclick>\n'
                '            <onclick condition="Skin.HasSetting(HomeSwitcher.EnableIcons)">Skin.SetBool(HomeSwitcher.EnableIconText)</onclick>\n'
                '            <onclick condition="![Skin.HasSetting(HomeSwitcher.EnableIcons) | Skin.HasSetting(HomeSwitcher.EnableIconText)]">Skin.SetBool(HomeSwitcher.EnableIcons)</onclick>',
                "three-state Top-menu setting",
            )
        if error:
            log_once(error + "; Icon + Text patch skipped.", xbmc.LOGWARNING)
            return None

    if ICON_TEXT_MARKER not in home_new:
        replacements = (
            (
                '                    <include content="Object_Left" condition="Skin.HasSetting(HomeSwitcher.EnableIcons)">',
                '                    <include content="Object_Left" condition="Skin.HasSetting(HomeSwitcher.EnableIcons) | Skin.HasSetting(HomeSwitcher.EnableIconText)">',
                "Top-menu horizontal offsets",
                2,
            ),
            (
                '        <param name="use_icons">Skin.HasSetting(HomeSwitcher.EnableIcons)</param>',
                '        <param name="use_icons">Skin.HasSetting(HomeSwitcher.EnableIcons) + !Skin.HasSetting(HomeSwitcher.EnableIconText)</param>\n'
                '        <param name="use_icon_text">Skin.HasSetting(HomeSwitcher.EnableIconText)</param>',
                "Top-menu display parameters",
                3,
            ),
            (
                '                        <visible>![$PARAM[use_icons]]</visible>',
                '                        <visible>![$PARAM[use_icons] | $PARAM[use_icon_text]]</visible>',
                "text-only visibility",
                3,
            ),
            (
                '        <include content="Object_ItemGap" condition="Skin.HasSetting(HomeSwitcher.EnableIcons)">',
                '        <include content="Object_ItemGap" condition="Skin.HasSetting(HomeSwitcher.EnableIcons) | Skin.HasSetting(HomeSwitcher.EnableIconText)">',
                "Top-menu item gap",
                1,
            ),
        )
        for old, new, label, expected in replacements:
            home_new, _, error = replace_count(
                home_new, old, new, label, expected
            )
            if error:
                log_once(error + "; Icon + Text patch skipped.", xbmc.LOGWARNING)
                return None

        object_icon = '''                    <control type="group">
                        <left>10</left>
                        <width>80</width>
                        <visible>$PARAM[use_icons]</visible>
                        <control type="image">
                            <include>Home_Grouplist_Icon_Definition</include>
                            <texture background="true" colordiffuse="main_fg_30">$VAR[Home_Icon_$PARAM[window]]</texture>
                        </control>
                    </control>'''
        object_combined = object_icon + '''
                    <control type="group">
                        <left>10</left>
                        <visible>$PARAM[use_icon_text] + !Window.IsVisible($PARAM[window])</visible>
                        <control type="button">
                            <font>font_mini</font>
                            <textcolor>main_fg_30</textcolor>
                            <focusedcolor>main_fg_30</focusedcolor>
                            <label>[UPPERCASE]$VAR[Hub_Label_$PARAM[window]][/UPPERCASE]</label>
                            <textoffsetx>80</textoffsetx>
                            <height>80</height>
                            <width>auto</width>
                            <texturenofocus />
                            <texturefocus />
                        </control>
                        <control type="image">
                            <left>20</left>
                            <centertop>50%</centertop>
                            <width>40</width>
                            <height>40</height>
                            <bordersize>icon_home_bordersize</bordersize>
                            <texture background="true" colordiffuse="main_fg_30">$VAR[Home_Icon_$PARAM[window]]</texture>
                        </control>
                    </control>'''
        home_new, _, error = replace_once(
            home_new, object_icon, object_combined, "unfocused Icon + Text layout"
        )
        if error:
            log_once(error + "; Icon + Text patch skipped.", xbmc.LOGWARNING)
            return None

        focus_icon = '''                    <control type="group">
                        <left>10</left>
                        <width>80</width>
                        <visible>$PARAM[use_icons]</visible>
                        <control type="image">
                            <include>Texture_Menu_Highlight_H</include>
                        </control>
                        <control type="image">
                            <include>Home_Grouplist_Icon_Definition</include>
                            <texture background="true" colordiffuse="$VAR[ColorSelected]">$VAR[Home_Icon_$PARAM[window]]</texture>
                        </control>
                    </control>'''
        focus_combined = focus_icon + '''
                    <control type="group">
                        <left>10</left>
                        <visible>$PARAM[use_icon_text]</visible>
                        <control type="button">
                            <font>font_mini</font>
                            <textcolor>$VAR[ColorSelected]</textcolor>
                            <focusedcolor>$VAR[ColorSelected]</focusedcolor>
                            <label>[UPPERCASE]$VAR[Hub_Label_$PARAM[window]][/UPPERCASE]</label>
                            <textoffsetx>80</textoffsetx>
                            <height>80</height>
                            <width>auto</width>
                            <include>Texture_Highlight_Button_FakeFocus_H</include>
                        </control>
                        <control type="image">
                            <left>20</left>
                            <centertop>50%</centertop>
                            <width>40</width>
                            <height>40</height>
                            <bordersize>icon_home_bordersize</bordersize>
                            <texture background="true" colordiffuse="$VAR[ColorSelected]">$VAR[Home_Icon_$PARAM[window]]</texture>
                        </control>
                    </control>'''
        home_new, _, error = replace_once(
            home_new, focus_icon, focus_combined, "focused Icon + Text layout"
        )
        if error:
            log_once(error + "; Icon + Text patch skipped.", xbmc.LOGWARNING)
            return None

        spacer_old = '''                <visible>$PARAM[visible]</visible>
            </control>
        </definition>
    </include>


    <include name="Home_Grouplist_Icon_Definition">'''
        spacer_new = '''                <visible>$PARAM[visible] + ![$PARAM[use_icon_text]]</visible>
            </control>
            <control type="button">
                <left>-460</left>
                <font>font_mini</font>
                <textcolor>00ffffff</textcolor>
                <focusedcolor>00ffffff</focusedcolor>
                <label>[UPPERCASE]$PARAM[name][/UPPERCASE]</label>
                <height>80</height>
                <width>auto</width>
                <centertop>50%</centertop>
                <texturenofocus />
                <texturefocus />
                <visible>$PARAM[visible] + $PARAM[use_icon_text]</visible>
            </control>
        </definition>
    </include>


    <include name="Home_Grouplist_Icon_Definition">'''
        home_new, _, error = replace_once(
            home_new, spacer_old, spacer_new, "Icon + Text dynamic spacer"
        )
        if error:
            log_once(error + "; Icon + Text patch skipped.", xbmc.LOGWARNING)
            return None

    elif ICON_TEXT_LAYOUT_MARKER not in home_new:
        old_object_combined = '''                    <control type="group">
                        <left>10</left>
                        <visible>$PARAM[use_icon_text]</visible>
                        <control type="image">
                            <include>Home_Grouplist_Icon_Definition</include>
                            <texture background="true" colordiffuse="main_fg_30">$VAR[Home_Icon_$PARAM[window]]</texture>
                        </control>
                        <control type="label">
                            <left>80</left>
                            <font>font_mini</font>
                            <textcolor>main_fg_30</textcolor>
                            <label>[UPPERCASE]$VAR[Hub_Label_$PARAM[window]][/UPPERCASE]</label>
                        </control>
                    </control>'''
        new_object_combined = '''                    <control type="group">
                        <left>10</left>
                        <visible>$PARAM[use_icon_text] + !Window.IsVisible($PARAM[window])</visible>
                        <control type="button">
                            <font>font_mini</font>
                            <textcolor>main_fg_30</textcolor>
                            <focusedcolor>main_fg_30</focusedcolor>
                            <label>[UPPERCASE]$VAR[Hub_Label_$PARAM[window]][/UPPERCASE]</label>
                            <textoffsetx>80</textoffsetx>
                            <height>80</height>
                            <width>auto</width>
                            <texturenofocus />
                            <texturefocus />
                        </control>
                        <control type="image">
                            <left>20</left>
                            <centertop>50%</centertop>
                            <width>40</width>
                            <height>40</height>
                            <bordersize>icon_home_bordersize</bordersize>
                            <texture background="true" colordiffuse="main_fg_30">$VAR[Home_Icon_$PARAM[window]]</texture>
                        </control>
                    </control>'''
        home_new, _, error = replace_once(
            home_new,
            old_object_combined,
            new_object_combined,
            "upgraded unfocused Icon + Text layout",
        )
        if error:
            log_once(error + "; Icon + Text upgrade skipped.", xbmc.LOGWARNING)
            return None

        old_focus_combined = '''                    <control type="group">
                        <left>10</left>
                        <visible>$PARAM[use_icon_text]</visible>
                        <control type="group">
                            <width>80</width>
                            <control type="image">
                                <include>Texture_Menu_Highlight_H</include>
                            </control>
                            <control type="image">
                                <include>Home_Grouplist_Icon_Definition</include>
                                <texture background="true" colordiffuse="$VAR[ColorSelected]">$VAR[Home_Icon_$PARAM[window]]</texture>
                            </control>
                        </control>
                        <control type="label">
                            <left>80</left>
                            <font>font_mini</font>
                            <textcolor>$VAR[ColorSelected]</textcolor>
                            <label>[UPPERCASE]$VAR[Hub_Label_$PARAM[window]][/UPPERCASE]</label>
                        </control>
                    </control>'''
        new_focus_combined = '''                    <control type="group">
                        <left>10</left>
                        <visible>$PARAM[use_icon_text]</visible>
                        <control type="button">
                            <font>font_mini</font>
                            <textcolor>$VAR[ColorSelected]</textcolor>
                            <focusedcolor>$VAR[ColorSelected]</focusedcolor>
                            <label>[UPPERCASE]$VAR[Hub_Label_$PARAM[window]][/UPPERCASE]</label>
                            <textoffsetx>80</textoffsetx>
                            <height>80</height>
                            <width>auto</width>
                            <include>Texture_Highlight_Button_FakeFocus_H</include>
                        </control>
                        <control type="image">
                            <left>20</left>
                            <centertop>50%</centertop>
                            <width>40</width>
                            <height>40</height>
                            <bordersize>icon_home_bordersize</bordersize>
                            <texture background="true" colordiffuse="$VAR[ColorSelected]">$VAR[Home_Icon_$PARAM[window]]</texture>
                        </control>
                    </control>'''
        home_new, _, error = replace_once(
            home_new,
            old_focus_combined,
            new_focus_combined,
            "upgraded focused Icon + Text layout",
        )
        if error:
            log_once(error + "; Icon + Text upgrade skipped.", xbmc.LOGWARNING)
            return None

    if ICON_TEXT_COLLAPSE_MARKER not in home_new:
        old_object_expanded = '''                    <control type="group">
                        <left>10</left>
                        <visible>$PARAM[use_icon_text] + !Window.IsVisible($PARAM[window])</visible>
                        <control type="button">
                            <font>font_mini</font>
                            <textcolor>main_fg_30</textcolor>
                            <focusedcolor>main_fg_30</focusedcolor>
                            <label>[UPPERCASE]$VAR[Hub_Label_$PARAM[window]][/UPPERCASE]</label>
                            <textoffsetx>80</textoffsetx>
                            <height>80</height>
                            <width>auto</width>
                            <texturenofocus />
                            <texturefocus />
                        </control>
                        <control type="image">
                            <left>20</left>
                            <centertop>50%</centertop>
                            <width>40</width>
                            <height>40</height>
                            <bordersize>icon_home_bordersize</bordersize>
                            <texture background="true" colordiffuse="main_fg_30">$VAR[Home_Icon_$PARAM[window]]</texture>
                        </control>
                    </control>'''
        new_object_collapsed = '''                    <control type="group">
                        <left>10</left>
                        <width>80</width>
                        <visible>$PARAM[use_icon_text] + !Window.IsVisible($PARAM[window])</visible>
                        <control type="image">
                            <include>Home_Grouplist_Icon_Definition</include>
                            <texture background="true" colordiffuse="main_fg_30">$VAR[Home_Icon_$PARAM[window]]</texture>
                        </control>
                    </control>'''
        if new_object_collapsed not in home_new:
            home_new, _, error = replace_once(
                home_new,
                old_object_expanded,
                new_object_collapsed,
                "collapsed unfocused Icon + Text layout",
            )
            if error:
                log_once(error + "; Icon + Text collapse upgrade skipped.", xbmc.LOGWARNING)
                return None

        old_focus_wide = '''                    <control type="group">
                        <left>10</left>
                        <visible>$PARAM[use_icon_text]</visible>
                        <control type="button">
                            <font>font_mini</font>
                            <textcolor>$VAR[ColorSelected]</textcolor>
                            <focusedcolor>$VAR[ColorSelected]</focusedcolor>
                            <label>[UPPERCASE]$VAR[Hub_Label_$PARAM[window]][/UPPERCASE]</label>
                            <textoffsetx>80</textoffsetx>
                            <height>80</height>
                            <width>auto</width>
                            <include>Texture_Highlight_Button_FakeFocus_H</include>
                        </control>
                        <control type="image">
                            <left>20</left>
                            <centertop>50%</centertop>
                            <width>40</width>
                            <height>40</height>
                            <bordersize>icon_home_bordersize</bordersize>
                            <texture background="true" colordiffuse="$VAR[ColorSelected]">$VAR[Home_Icon_$PARAM[window]]</texture>
                        </control>
                    </control>'''
        old_focus_overlap = '''                    <control type="group">
                        <left>10</left>
                        <visible>$PARAM[use_icon_text]</visible>
                        <control type="group">
                            <width>80</width>
                            <control type="image">
                                <include>Texture_Menu_Highlight_H</include>
                            </control>
                        </control>
                        <control type="button">
                            <left>50</left>
                            <font>font_mini</font>
                            <textcolor>$VAR[ColorSelected]</textcolor>
                            <focusedcolor>$VAR[ColorSelected]</focusedcolor>
                            <label>[UPPERCASE]$VAR[Hub_Label_$PARAM[window]][/UPPERCASE]</label>
                            <textoffsetx>20</textoffsetx>
                            <height>80</height>
                            <width>auto</width>
                            <include>Texture_Highlight_Button_FakeFocus_H</include>
                        </control>
                        <control type="image">
                            <left>20</left>
                            <centertop>50%</centertop>
                            <width>40</width>
                            <height>40</height>
                            <bordersize>icon_home_bordersize</bordersize>
                            <texture background="true" colordiffuse="$VAR[ColorSelected]">$VAR[Home_Icon_$PARAM[window]]</texture>
                        </control>
                    </control>'''
        new_focus_single = '''                    <control type="group">
                        <left>10</left>
                        <visible>$PARAM[use_icon_text]</visible>
                        <control type="button">
                            <font>font_mini</font>
                            <textcolor>00ffffff</textcolor>
                            <focusedcolor>00ffffff</focusedcolor>
                            <label>[UPPERCASE]$VAR[Hub_Label_$PARAM[window]][/UPPERCASE]</label>
                            <textoffsetx>48.5</textoffsetx>
                            <height>80</height>
                            <width>auto</width>
                            <include>Texture_Highlight_Button_FakeFocus_H</include>
                        </control>
                        <control type="image">
                            <left>20</left>
                            <centertop>50%</centertop>
                            <width>40</width>
                            <height>40</height>
                            <bordersize>icon_home_bordersize</bordersize>
                            <texture background="true" colordiffuse="$VAR[ColorSelected]">$VAR[Home_Icon_$PARAM[window]]</texture>
                        </control>
                        <control type="label">
                            <left>70</left>
                            <font>font_mini</font>
                            <textcolor>$VAR[ColorSelected]</textcolor>
                            <label>[UPPERCASE]$VAR[Hub_Label_$PARAM[window]][/UPPERCASE]</label>
                        </control>
                    </control>'''
        focus_old = old_focus_wide if old_focus_wide in home_new else old_focus_overlap
        home_new, _, error = replace_once(
            home_new,
            focus_old,
            new_focus_single,
            "single-pill focused Icon + Text layout",
        )
        if error:
            log_once(error + "; Icon + Text compact highlight upgrade skipped.", xbmc.LOGWARNING)
            return None

        spacer_call_old = '''        <include content="Home_Spacer">
            <param name="name">$VAR[Hub_Label_$PARAM[window]]</param>'''
        spacer_call_new = '''        <include content="Home_Spacer">
            <param name="window">$PARAM[window]</param>
            <param name="name">$VAR[Hub_Label_$PARAM[window]]</param>'''
        if spacer_call_new not in home_new:
            home_new, _, error = replace_once(
                home_new,
                spacer_call_old,
                spacer_call_new,
                "Icon + Text spacer window parameter",
            )
            if error:
                log_once(error + "; Icon + Text spacer upgrade skipped.", xbmc.LOGWARNING)
                return None

        spacer_expanded_old = '''            <control type="button">
                <left>-460</left>
                <font>font_mini</font>
                <textcolor>00ffffff</textcolor>
                <focusedcolor>00ffffff</focusedcolor>
                <label>[UPPERCASE]$PARAM[name][/UPPERCASE]</label>
                <height>80</height>
                <width>auto</width>
                <centertop>50%</centertop>
                <texturenofocus />
                <texturefocus />
                <visible>$PARAM[visible] + $PARAM[use_icon_text]</visible>
            </control>'''
        spacer_overlap_old = '''            <control type="button">
                <left>-470</left>
                <font>font_mini</font>
                <textcolor>00ffffff</textcolor>
                <focusedcolor>00ffffff</focusedcolor>
                <label>[UPPERCASE]$PARAM[name][/UPPERCASE]</label>
                <height>80</height>
                <width>auto</width>
                <centertop>50%</centertop>
                <texturenofocus />
                <texturefocus />
                <visible>$PARAM[visible] + $PARAM[use_icon_text] + Window.IsVisible($PARAM[window])</visible>
            </control>
            <control type="button">
                <left>-560</left>
                <width>100</width>
                <height>80</height>
                <centertop>50%</centertop>
                <texturenofocus />
                <texturefocus />
                <visible>$PARAM[visible] + $PARAM[use_icon_text] + !Window.IsVisible($PARAM[window])</visible>
            </control>'''
        spacer_collapsed_new = spacer_overlap_old.replace(
            '                <left>-470</left>',
            '                <left>-520</left>',
        ).replace(
            '                <width>100</width>',
            '                <width>80</width>',
        )
        spacer_old = (
            spacer_expanded_old
            if spacer_expanded_old in home_new
            else spacer_overlap_old
        )
        home_new, _, error = replace_once(
            home_new,
            spacer_old,
            spacer_collapsed_new,
            "dynamic focused Icon + Text spacer",
        )
        if error:
            log_once(error + "; Icon + Text dynamic spacer upgrade skipped.", xbmc.LOGWARNING)
            return None

        gap_old = '        <include content="Object_ItemGap" condition="Skin.HasSetting(HomeSwitcher.EnableIcons) | Skin.HasSetting(HomeSwitcher.EnableIconText)">'
        gap_new = '        <include content="Object_ItemGap" condition="Skin.HasSetting(HomeSwitcher.EnableIcons) + !Skin.HasSetting(HomeSwitcher.EnableIconText)">'
        home_new, _, error = replace_once(
            home_new,
            gap_old,
            gap_new,
            "collapsed Icon + Text item gap",
        )
        if error:
            log_once(error + "; Icon + Text item-gap upgrade skipped.", xbmc.LOGWARNING)
            return None

    if ICON_TEXT_SPACING_MARKER not in home_new:
        home_spacer_start = home_new.find('<include name="Home_Spacer">')
        if home_spacer_start < 0:
            log_once("Home_Spacer anchor missing; Icon + Text spacing upgrade skipped.", xbmc.LOGWARNING)
            return None
        prefix = home_new[:home_spacer_start]
        spacer = home_new[home_spacer_start:]
        spacer, _, error = replace_once(
            spacer,
            '                <left>-470</left>',
            '                <left>-520</left>',
            "focused Icon + Text reserved width",
        )
        if error:
            log_once(error + "; Icon + Text spacing upgrade skipped.", xbmc.LOGWARNING)
            return None
        home_new = prefix + spacer

    if ICON_TEXT_PADDING_MARKER not in home_new:
        home_new, _, error = replace_once(
            home_new,
            '                            <textoffsetx>45</textoffsetx>',
            '                            <textoffsetx>48.5</textoffsetx>',
            "Icon + Text pill right padding",
        )
        if error:
            home_new, _, error = replace_once(
                home_new,
                '                            <textoffsetx>46.5</textoffsetx>',
                '                            <textoffsetx>48.5</textoffsetx>',
                "Icon + Text pill additional right padding",
            )
        if error:
            home_new, _, error = replace_once(
                home_new,
                '                            <textoffsetx>47.5</textoffsetx>',
                '                            <textoffsetx>48.5</textoffsetx>',
                "Icon + Text pill final right padding",
            )
        if error:
            log_once(error + "; Icon + Text padding upgrade skipped.", xbmc.LOGWARNING)
            return None

    changed = False
    for path, old, new in (
        (home_path, home, home_new),
        (labels_path, labels, labels_new),
        (settings_path, settings, settings_new),
    ):
        if new != old:
            write_text(path, new)
            changed = True

    if changed:
        log_once("Reapplied local Top-menu Icon + Text presentation patch.")
    return changed


def remove_obsolete_kodi_version_patch(skin_root):
    """Remove the retired Kodi-version footer changes from service 1.3.6."""
    labels_path = os.path.join(skin_root, "1080i", "Includes_Labels.xml")
    furniture_path = os.path.join(skin_root, "1080i", "Includes_Furniture.xml")
    paths = (labels_path, furniture_path)
    if not all(os.path.isfile(path) for path in paths):
        log("Kodi-version cleanup: expected AF3 files are missing; skipped.", xbmc.LOGWARNING)
        return False

    labels = read_text(labels_path)
    furniture = read_text(furniture_path)
    labels_new = labels
    furniture_new = furniture

    original_labels_footer = (
        "$INFO[System.BuildVersion,Kodi ,]"
        "$INFO[System.AddonVersion(skin.arctic.fuse.3), • AF3 v,]"
    )
    patched_footer = (
        "$INFO[System.BuildVersionShort,Kodi ,]"
        "$INFO[System.BuildVersionCode, (,)]"
        "$INFO[System.AddonVersion(skin.arctic.fuse.3), • AF3 v,]"
    )
    labels_count = labels_new.count(patched_footer)
    if labels_count:
        if labels_count == 2:
            labels_new = labels_new.replace(patched_footer, original_labels_footer)
        else:
            log(
                "Kodi-version cleanup: expected 2 patched label anchors, found {}; preserved.".format(
                    labels_count
                ),
                xbmc.LOGWARNING,
            )

    original_furniture_footer = (
        "$INFO[System.AddonVersion(skin.arctic.fuse.3),arctic.fuse v,]"
    )
    furniture_count = furniture_new.count(patched_footer)
    if furniture_count:
        if furniture_count == 1:
            furniture_new = furniture_new.replace(
                patched_footer, original_furniture_footer, 1
            )
        else:
            log(
                "Kodi-version cleanup: expected 1 patched furniture anchor, found {}; preserved.".format(
                    furniture_count
                ),
                xbmc.LOGWARNING,
            )

    changed = False
    if labels_new != labels:
        write_text(labels_path, labels_new)
        changed = True
    if furniture_new != furniture:
        write_text(furniture_path, furniture_new)
        changed = True
    if changed:
        log("Removed retired Kodi version footer patch.")
    return changed


def remove_obsolete_home_focus_patch(skin_root):
    """Remove the retired focus workaround previously installed by this service."""
    home_path = os.path.join(skin_root, "1080i", "Home.xml")
    shortcuts_dir = os.path.join(skin_root, "shortcuts")
    focus_path = os.path.join(shortcuts_dir, OBSOLETE_HOME_FOCUS_FILE)

    if not os.path.isfile(home_path):
        log("Home-focus cleanup: Home.xml is missing; skipped.", xbmc.LOGWARNING)
        return False

    home = read_text(home_path)
    old_focus = (
        '<onload condition="Skin.HasSetting(Home.FirstRun) + '
        'String.IsEmpty(Window(1198).Property(FirstStart))">'
        '$VAR[Action_FirstStart_HomeFocus]</onload>'
    )
    new_focus = (
        '<onload condition="Skin.HasSetting(Home.FirstRun) + '
        'String.IsEmpty(Window(1198).Property(FirstStart))">'
        + OBSOLETE_HOME_FOCUS_CALL + '</onload>'
    )

    home_new, _, error = replace_once(
        home, new_focus, old_focus, "obsolete Home initial-focus workaround"
    )
    if error:
        log(error + "; Home-focus cleanup skipped.", xbmc.LOGWARNING)
        return False

    changed = False
    if home_new != home:
        write_text(home_path, home_new)
        changed = True

    if os.path.isfile(focus_path):
        with open(focus_path, "rb") as handle:
            focus_hash = hashlib.sha256(handle.read()).hexdigest()
        if focus_hash == OBSOLETE_HOME_FOCUS_SHA256:
            os.remove(focus_path)
            changed = True
        else:
            log(
                "Home-focus helper differs from the retired service file; preserved.",
                xbmc.LOGWARNING,
            )

    if changed:
        log("Removed obsolete Home initial-focus workaround.")
    return changed


def installed_skin_version(skin_root):
    """Return the installed AF3 version from its addon.xml, or an empty string."""
    try:
        root = ElementTree.parse(os.path.join(skin_root, "addon.xml")).getroot()
    except (IOError, OSError, ElementTree.ParseError):
        return ""
    return root.get("version", "")


def state_file():
    folder = xbmcvfs.translatePath("special://profile/addon_data/{}/".format(ADDON_ID))
    return folder, os.path.join(folder, STATE_FILE)


def read_applied_state():
    """Return the recorded AF3 version and patch revision, or an empty dict."""
    _, path = state_file()
    try:
        with open(path, "r", encoding="utf-8") as handle:
            state = json.load(handle)
            return state if isinstance(state, dict) else {}
    except (IOError, OSError, ValueError, AttributeError):
        return {}


def read_applied_version():
    """Return the AF3 version the patches were last applied to, or None."""
    return read_applied_state().get("applied_version")


def patch_revision_is_current(version):
    state = read_applied_state()
    return (
        state.get("applied_version") == version
        and state.get("patch_revision") == PATCH_REVISION
    )


def write_applied_version(version):
    folder, path = state_file()
    try:
        if not os.path.isdir(folder):
            os.makedirs(folder)
        write_text(
            path,
            json.dumps(
                {
                    "applied_version": version,
                    "patch_revision": PATCH_REVISION,
                }
            ),
        )
    except (IOError, OSError) as exc:
        log("Could not record applied AF3 version: {}".format(exc), xbmc.LOGWARNING)


def skin_is_settled(skin_root, now=None):
    """True once the AF3 manifest and layout files have stopped changing.

    An update writes many files over several seconds. Waiting for them to go
    quiet keeps the patches from reading or writing a half-installed skin.
    """
    now = time.time() if now is None else now
    layout_folder = os.path.join(skin_root, "1080i")
    try:
        paths = [os.path.join(skin_root, "addon.xml")]
        paths.extend(os.path.join(layout_folder, name) for name in os.listdir(layout_folder))
        newest = max(os.path.getmtime(path) for path in paths)
    except OSError:
        return False
    return now - newest >= SETTLE_SECONDS


def patch_skin(force=False):
    skin_root = xbmcvfs.translatePath("special://home/addons/{}/".format(SKIN_ID))
    if not os.path.isdir(skin_root):
        return False

    try:
        migrate_top_up_setting()
    except Exception as exc:
        log("Top-menu setting migration failed: {}".format(exc), xbmc.LOGERROR)

    # Reapply only when AF3 has a version the patches were not yet applied to,
    # and only after its files have settled. Once applied, later checks do nothing.
    version = installed_skin_version(skin_root)
    if not version:
        log("AF3 version could not be read; patches skipped.", xbmc.LOGWARNING)
        return False
    if not force and patch_revision_is_current(version):
        return False
    if not skin_is_settled(skin_root):
        log("AF3 {} is still being written; patches wait for it to settle.".format(version))
        return False

    changed_focus_cleanup = False
    changed_icon_text = False
    changed_kodi_cleanup = False
    failed = False

    try:
        changed_focus_cleanup = remove_obsolete_home_focus_patch(skin_root)
    except Exception as exc:
        failed = True
        log_once("Home-focus cleanup failed: {}".format(exc), xbmc.LOGERROR)

    try:
        changed_icon_text = patch_icon_text(skin_root)
        if changed_icon_text is None:
            changed_icon_text = False
            failed = True
            log_once(
                "AF3 {}: Icon + Text patch is incomplete; version remains pending.".format(
                    version
                ),
                xbmc.LOGWARNING,
            )
    except Exception as exc:
        failed = True
        log_once("Icon + Text patch check failed: {}".format(exc), xbmc.LOGERROR)

    try:
        changed_kodi_cleanup = remove_obsolete_kodi_version_patch(skin_root)
    except Exception as exc:
        failed = True
        log_once("Kodi-version cleanup failed: {}".format(exc), xbmc.LOGERROR)

    # Keep the version pending after I/O failures or missing anchors so the
    # service can retry instead of treating an incomplete patch as successful.
    if not failed:
        _failed_attempts.pop(version, None)
        write_applied_version(version)
    else:
        attempts = _failed_attempts.get(version, 0) + 1
        _failed_attempts[version] = attempts
        if attempts >= FAILURE_LIMIT:
            log_once(
                "AF3 {}: patches still failing after {} attempts; keeping the version pending and retrying.".format(
                    version, attempts
                ),
                xbmc.LOGERROR,
            )

    if not (
        changed_focus_cleanup
        or changed_icon_text
        or changed_kodi_cleanup
    ):
        return False

    global _reload_pending
    _reload_pending = True

    message = "Personal skin updates reapplied"

    xbmcgui.Dialog().notification(
        "Arctic Fuse 3",
        message,
        xbmcgui.NOTIFICATION_INFO,
        4000,
    )
    return True


def reload_if_pending():
    """Reload the skin after a patch, but only while Home is the active window.

    Reloading from another window, such as a Hub with live widgets, has been
    seen to freeze Kodi. A pending reload waits until Home is active.
    """
    global _reload_pending
    if not _reload_pending:
        return False
    if xbmc.getSkinDir() != SKIN_ID:
        _reload_pending = False
        return False
    if not xbmc.getCondVisibility("Window.IsActive(home)"):
        return False
    _reload_pending = False
    xbmc.executebuiltin("ReloadSkin()")
    return True


def arm_reload_watch():
    """Mark the Home window so a skin reload can be detected on the next poll.

    Kodi recreates the skin window and clears its properties during ReloadSkin.
    A missing marker therefore means the user (or another add-on) reloaded the
    skin. The check is harmless if another script happens to clear the marker:
    the patch operation is idempotent.
    """
    window = xbmcgui.Window(10000)
    if window.getProperty(RELOAD_WATCH_PROPERTY) == _reload_watch_token:
        return False
    window.setProperty(RELOAD_WATCH_PROPERTY, _reload_watch_token)
    return True


def run():
    monitor = xbmc.Monitor()
    # Give Kodi/add-on updates a few seconds to settle at startup.
    if monitor.waitForAbort(5):
        return

    patch_skin()
    arm_reload_watch()
    last_patch_check = time.time()

    while not monitor.waitForAbort(RELOAD_POLL_SECONDS):
        reload_if_pending()
        if arm_reload_watch():
            patch_skin(force=True)
            last_patch_check = time.time()
        if time.time() - last_patch_check >= CHECK_SECONDS:
            patch_skin()
            last_patch_check = time.time()


if __name__ == "__main__":
    run()
