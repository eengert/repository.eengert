# Arctic Fuse 3 Patch Service v1.3.7

This Kodi service preserves two Arctic Fuse 3 modifications after skin updates:

1. Configurable Top-menu Up action (Submenu or Options).
2. A third horizontal Top-menu display option, `Icon + Text`, using a regular, slightly smaller uppercase label beside each icon.
## v1.3.7 use upstream Information Summary

The service no longer patches Information > Summary because the Kodi version row was merged upstream in Arctic Fuse 3 PR #370. It also safely restores AF3's original footer, retiring the longer Kodi + AF3 footer from version 1.3.6.

## v1.3.6 Kodi version display

The settings footer now uses Kodi's current short-version and build-code labels before the AF3 version. Information > Summary also includes a dedicated Kodi Version row.

## v1.3.5 remove obsolete focus workaround

The Home startup/reload focus workaround has been retired after identifying the actual cause as the default Spotlight path returning an empty set. Existing installations safely restore AF3's original startup action and remove only the unchanged helper JSON previously created by this service.

## v1.3 Icon + Text style

The Home menu appearance setting now cycles through Text, Icon, and Icon + Text. The additional style affects only the horizontal/Top menu and leaves both existing styles and the vertical menu unchanged.

### v1.3.1 layout correction

The selected Icon + Text item now uses one auto-width highlight pill around both the icon and label. The active item's unfocused base layer is hidden so a duplicate icon cannot appear after the text.

### v1.3.2 compact focused expansion

Unfocused Icon + Text menu items now collapse to icon-only width. The active item expands over one auto-sized pill background, with a 10px icon gap and approximately equal 20px padding at both ends. Combined-mode item gaps and collapsed widths are reduced, and the focused item's reserved width is trimmed so neighboring icons remain equally close on either side.

### v1.3.3 padding adjustment

The active pill is extended by 7px to add a little more breathing room after the label without moving its visible icon or text.

### v1.3.4 extensible Top-menu Up setting

The Top-menu Up action now uses the string setting `HomeSwitcher.OnUp`, matching the upstream review change. An empty value keeps Submenu as the default, while `options` opens Options. Existing installations using the previous boolean setting are migrated automatically without losing an Options selection.

The service checks the AF3 skin periodically and reapplies known-safe patches when an AF3 update overwrites them. If expected anchors change, the affected patch is skipped rather than guessing.
