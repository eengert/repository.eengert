# -*- coding: utf-8 -*-
import os

import xbmc
import xbmcgui
import xbmcvfs

ADDON_ID = "service.af3.topupaction"
SKIN_ID = "skin.arctic.fuse.3"
CHECK_SECONDS = 60
TOP_UP_MARKER = "HomeSwitcher.TopUpOpensOptions"
ICON_TEXT_MARKER = "HomeSwitcher.EnableIconText"
ICON_TEXT_LAYOUT_MARKER = (
    '<visible>$PARAM[use_icon_text] + !Window.IsVisible($PARAM[window])</visible>'
)
HOME_FOCUS_FILE = "skinvariables-homefocus.json"
HOME_FOCUS_CALL = (
    "RunScript(script.skinvariables,run_executebuiltin="
    "special://skin/shortcuts/skinvariables-homefocus.json,use_rules=True)"
)

HOME_FOCUS_JSON = '''{
    "values": {
        "InitialHomeFocus": [
            {
                "rules": ["Skin.HasSetting(HomeSwitcher.DisableFirstWidgetFocus)"],
                "value": "SetFocus(300)"
            },
            {
                "rules": ["!String.IsEmpty(Skin.String(HomeSwitcher.Home.Spotlight.Target))"],
                "value": "SetFocus(310)"
            },
            {
                "rules": [
                    "!String.IsEmpty(Skin.String(HomeSwitcher.Home.Mode))",
                    "Control.IsVisible(601)"
                ],
                "value": "SetFocus(601)"
            },
            {
                "rules": ["Control.IsVisible(501)"],
                "value": "SetFocus(501)"
            },
            {
                "rules": ["Control.IsVisible(502)"],
                "value": "SetFocus(502)"
            },
            {
                "rules": ["Control.IsVisible(503)"],
                "value": "SetFocus(503)"
            },
            {
                "rules": ["Control.IsVisible(504)"],
                "value": "SetFocus(504)"
            },
            {
                "rules": ["Control.IsVisible(505)"],
                "value": "SetFocus(505)"
            },
            "SetFocus(300)"
        ]
    },
    "actions": [
        "sleep=0.5",
        {
            "rules": ["!Skin.HasSetting(HomeSwitcher.Vertical)"],
            "value": [
                "SetFocus(300)",
                "sleep=0.15",
                "Action(Down)"
            ]
        },
        {
            "rules": ["Skin.HasSetting(HomeSwitcher.Vertical)"],
            "value": "{InitialHomeFocus}"
        }
    ]
}
'''


def log(message, level=xbmc.LOGINFO):
    xbmc.log("[{}] {}".format(ADDON_ID, message), level)


def read_text(path):
    with open(path, "r", encoding="utf-8") as handle:
        return handle.read()


def write_text(path, content):
    tmp = path + ".af3patch.tmp"
    with open(tmp, "w", encoding="utf-8", newline="") as handle:
        handle.write(content)
    os.replace(tmp, path)


def replace_once(content, old, new, label):
    count = content.count(old)
    if count == 0:
        if new in content:
            return content, False, None
        return content, False, "Expected anchor not found for {}".format(label)
    if count != 1:
        return content, False, "Expected exactly one anchor for {}, found {}".format(label, count)
    return content.replace(old, new, 1), True, None


def replace_count(content, old, new, label, expected):
    count = content.count(old)
    if count != expected:
        return content, False, "Expected {} anchors for {}, found {}".format(
            expected, label, count
        )
    return content.replace(old, new), True, None


def patch_top_up(skin_root):
    """Apply the current two-file Top-menu Up action patch."""
    home_path = os.path.join(skin_root, "1080i", "Includes_Home.xml")
    settings_path = os.path.join(skin_root, "1080i", "SkinSettings.xml")
    if not os.path.isfile(home_path) or not os.path.isfile(settings_path):
        log("Top-menu patch: expected AF3 files are missing; skipped.", xbmc.LOGWARNING)
        return False

    home = read_text(home_path)
    settings = read_text(settings_path)

    home_new = home
    settings_new = settings

    if 'variable name="Label_Setting_TopMenuUpAction"' not in home_new:
        home_new, _, error = replace_once(
            home_new,
            '    <variable name="Home_Icon_home">\n',
            '    <variable name="Label_Setting_TopMenuUpAction">\n'
            '        <value condition="Skin.HasSetting(HomeSwitcher.TopUpOpensOptions)">$LOCALIZE[33063]</value>\n'
            '        <value>$LOCALIZE[1034]</value>\n'
            '    </variable>\n\n'
            '    <variable name="Home_Icon_home">\n',
            "Top-menu label variable",
        )
        if error:
            log(error + "; Top-menu patch skipped.", xbmc.LOGWARNING)
            return False

    if TOP_UP_MARKER not in home_new[home_new.find('<include name="Home_Horz_Movement">'):]:
        home_new, _, error = replace_once(
            home_new,
            '        <onup>ActivateWindow(1181)</onup>\n        <oninfo>ActivateWindow(1181)</oninfo>',
            '        <onup condition="Skin.HasSetting(HomeSwitcher.TopUpOpensOptions)">ActivateWindow(1170)</onup>\n'
            '        <onup condition="!Skin.HasSetting(HomeSwitcher.TopUpOpensOptions)">ActivateWindow(1181)</onup>\n'
            '        <oninfo>ActivateWindow(1181)</oninfo>',
            "Top-menu Up action",
        )
        if error:
            log(error + "; Top-menu patch skipped.", xbmc.LOGWARNING)
            return False

    if 'description="Top Menu Up Action"' not in settings_new:
        anchor = (
            '                        <include content="SkinSettings_Items_Menus">\n'
            '                            <param name="baseid">0</param>\n'
            '                        </include>\n'
        )
        replacement = anchor + (
            '                        <include content="Settings_Button" description="Top Menu Up Action">\n'
            '                            <param name="dialog">false</param>\n'
            '                            <param name="window">skinsettings</param>\n'
            '                            <param name="baseid">0</param>\n'
            '                            <param name="id">090</param>\n'
            '                            <param name="control">button</param>\n'
            '                            <label>$LOCALIZE[31349]</label>\n'
            '                            <label2>$VAR[Label_Setting_TopMenuUpAction]</label2>\n'
            '                            <onclick>Skin.ToggleSetting(HomeSwitcher.TopUpOpensOptions)</onclick>\n'
            '                            <visible>!Skin.HasSetting(HomeSwitcher.Vertical)</visible>\n'
            '                        </include>\n'
        )
        settings_new, _, error = replace_once(
            settings_new, anchor, replacement, "Top-menu Skin Settings button"
        )
        if error:
            log(error + "; Top-menu patch skipped.", xbmc.LOGWARNING)
            return False

    changed = False
    if home_new != home:
        write_text(home_path, home_new)
        changed = True
    if settings_new != settings:
        write_text(settings_path, settings_new)
        changed = True

    if changed:
        log("Reapplied configurable Top-menu Up action patch.")
    return changed


def patch_icon_text(skin_root):
    """Add a local Icon + Text presentation to the horizontal Top menu."""
    home_path = os.path.join(skin_root, "1080i", "Includes_Home.xml")
    labels_path = os.path.join(skin_root, "1080i", "Includes_Labels.xml")
    settings_path = os.path.join(skin_root, "1080i", "Includes_SkinSettings.xml")
    paths = (home_path, labels_path, settings_path)
    if not all(os.path.isfile(path) for path in paths):
        log("Icon + Text patch: expected AF3 files are missing; skipped.", xbmc.LOGWARNING)
        return False

    home = read_text(home_path)
    labels = read_text(labels_path)
    settings = read_text(settings_path)
    home_new = home
    labels_new = labels
    settings_new = settings

    if ICON_TEXT_MARKER not in labels_new:
        labels_new, _, error = replace_once(
            labels_new,
            '    <variable name="Label_Setting_HomeIcons">\n'
            '        <value condition="Skin.HasSetting(HomeSwitcher.EnableIcons)">$LOCALIZE[536]</value>\n'
            '        <value>$LOCALIZE[31329]</value>\n'
            '    </variable>',
            '    <variable name="Label_Setting_HomeIcons">\n'
            '        <value condition="Skin.HasSetting(HomeSwitcher.EnableIconText)">Icon + Text</value>\n'
            '        <value condition="Skin.HasSetting(HomeSwitcher.EnableIcons)">$LOCALIZE[536]</value>\n'
            '        <value>$LOCALIZE[31329]</value>\n'
            '    </variable>',
            "Icon + Text setting label",
        )
        if error:
            log(error + "; Icon + Text patch skipped.", xbmc.LOGWARNING)
            return False

    if ICON_TEXT_MARKER not in settings_new:
        settings_new, _, error = replace_once(
            settings_new,
            '            <onclick>Skin.ToggleSetting(HomeSwitcher.EnableIcons)</onclick>',
            '            <onclick condition="Skin.HasSetting(HomeSwitcher.EnableIconText)">Skin.Reset(HomeSwitcher.EnableIconText)</onclick>\n'
            '            <onclick condition="Skin.HasSetting(HomeSwitcher.EnableIcons)">Skin.Reset(HomeSwitcher.EnableIcons)</onclick>\n'
            '            <onclick condition="Skin.HasSetting(HomeSwitcher.EnableIcons)">Skin.SetBool(HomeSwitcher.EnableIconText)</onclick>\n'
            '            <onclick condition="![Skin.HasSetting(HomeSwitcher.EnableIcons) | Skin.HasSetting(HomeSwitcher.EnableIconText)]">Skin.SetBool(HomeSwitcher.EnableIcons)</onclick>',
            "three-state Top-menu setting",
        )
        if error:
            log(error + "; Icon + Text patch skipped.", xbmc.LOGWARNING)
            return False

    if ICON_TEXT_MARKER not in home_new:
        replacements = (
            (
                '                    <include content="Object_Left" condition="Skin.HasSetting(HomeSwitcher.EnableIcons)">',
                '                    <include content="Object_Left" condition="Skin.HasSetting(HomeSwitcher.EnableIcons) | Skin.HasSetting(HomeSwitcher.EnableIconText)">',
                "Top-menu horizontal offsets",
                2,
            ),
            (
                '        <param name="use_icons">Skin.HasSetting(HomeSwitcher.EnableIcons)</param>',
                '        <param name="use_icons">Skin.HasSetting(HomeSwitcher.EnableIcons) + !Skin.HasSetting(HomeSwitcher.EnableIconText)</param>\n'
                '        <param name="use_icon_text">Skin.HasSetting(HomeSwitcher.EnableIconText)</param>',
                "Top-menu display parameters",
                3,
            ),
            (
                '                        <visible>![$PARAM[use_icons]]</visible>',
                '                        <visible>![$PARAM[use_icons] | $PARAM[use_icon_text]]</visible>',
                "text-only visibility",
                3,
            ),
            (
                '        <include content="Object_ItemGap" condition="Skin.HasSetting(HomeSwitcher.EnableIcons)">',
                '        <include content="Object_ItemGap" condition="Skin.HasSetting(HomeSwitcher.EnableIcons) | Skin.HasSetting(HomeSwitcher.EnableIconText)">',
                "Top-menu item gap",
                1,
            ),
        )
        for old, new, label, expected in replacements:
            home_new, _, error = replace_count(
                home_new, old, new, label, expected
            )
            if error:
                log(error + "; Icon + Text patch skipped.", xbmc.LOGWARNING)
                return False

        object_icon = '''                    <control type="group">
                        <left>10</left>
                        <width>80</width>
                        <visible>$PARAM[use_icons]</visible>
                        <control type="image">
                            <include>Home_Grouplist_Icon_Definition</include>
                            <texture background="true" colordiffuse="main_fg_30">$VAR[Home_Icon_$PARAM[window]]</texture>
                        </control>
                    </control>'''
        object_combined = object_icon + '''
                    <control type="group">
                        <left>10</left>
                        <visible>$PARAM[use_icon_text] + !Window.IsVisible($PARAM[window])</visible>
                        <control type="button">
                            <font>font_mini</font>
                            <textcolor>main_fg_30</textcolor>
                            <focusedcolor>main_fg_30</focusedcolor>
                            <label>[UPPERCASE]$INFO[Skin.String(HomeSwitcher.$PARAM[window].Name)][/UPPERCASE]</label>
                            <textoffsetx>80</textoffsetx>
                            <height>80</height>
                            <width>auto</width>
                            <texturenofocus />
                            <texturefocus />
                        </control>
                        <control type="image">
                            <left>20</left>
                            <centertop>50%</centertop>
                            <width>40</width>
                            <height>40</height>
                            <bordersize>icon_home_bordersize</bordersize>
                            <texture background="true" colordiffuse="main_fg_30">$VAR[Home_Icon_$PARAM[window]]</texture>
                        </control>
                    </control>'''
        home_new, _, error = replace_once(
            home_new, object_icon, object_combined, "unfocused Icon + Text layout"
        )
        if error:
            log(error + "; Icon + Text patch skipped.", xbmc.LOGWARNING)
            return False

        focus_icon = '''                    <control type="group">
                        <left>10</left>
                        <width>80</width>
                        <visible>$PARAM[use_icons]</visible>
                        <control type="image">
                            <include>Texture_Menu_Highlight_H</include>
                        </control>
                        <control type="image">
                            <include>Home_Grouplist_Icon_Definition</include>
                            <texture background="true" colordiffuse="$VAR[ColorSelected]">$VAR[Home_Icon_$PARAM[window]]</texture>
                        </control>
                    </control>'''
        focus_combined = focus_icon + '''
                    <control type="group">
                        <left>10</left>
                        <visible>$PARAM[use_icon_text]</visible>
                        <control type="button">
                            <font>font_mini</font>
                            <textcolor>$VAR[ColorSelected]</textcolor>
                            <focusedcolor>$VAR[ColorSelected]</focusedcolor>
                            <label>[UPPERCASE]$INFO[Skin.String(HomeSwitcher.$PARAM[window].Name)][/UPPERCASE]</label>
                            <textoffsetx>80</textoffsetx>
                            <height>80</height>
                            <width>auto</width>
                            <include>Texture_Highlight_Button_FakeFocus_H</include>
                        </control>
                        <control type="image">
                            <left>20</left>
                            <centertop>50%</centertop>
                            <width>40</width>
                            <height>40</height>
                            <bordersize>icon_home_bordersize</bordersize>
                            <texture background="true" colordiffuse="$VAR[ColorSelected]">$VAR[Home_Icon_$PARAM[window]]</texture>
                        </control>
                    </control>'''
        home_new, _, error = replace_once(
            home_new, focus_icon, focus_combined, "focused Icon + Text layout"
        )
        if error:
            log(error + "; Icon + Text patch skipped.", xbmc.LOGWARNING)
            return False

        spacer_old = '''                <visible>$PARAM[visible]</visible>
            </control>
        </definition>
    </include>


    <include name="Home_Grouplist_Icon_Definition">'''
        spacer_new = '''                <visible>$PARAM[visible] + ![$PARAM[use_icon_text]]</visible>
            </control>
            <control type="button">
                <left>-460</left>
                <font>font_mini</font>
                <textcolor>00ffffff</textcolor>
                <focusedcolor>00ffffff</focusedcolor>
                <label>[UPPERCASE]$PARAM[name][/UPPERCASE]</label>
                <height>80</height>
                <width>auto</width>
                <centertop>50%</centertop>
                <texturenofocus />
                <texturefocus />
                <visible>$PARAM[visible] + $PARAM[use_icon_text]</visible>
            </control>
        </definition>
    </include>


    <include name="Home_Grouplist_Icon_Definition">'''
        home_new, _, error = replace_once(
            home_new, spacer_old, spacer_new, "Icon + Text dynamic spacer"
        )
        if error:
            log(error + "; Icon + Text patch skipped.", xbmc.LOGWARNING)
            return False

    elif ICON_TEXT_LAYOUT_MARKER not in home_new:
        old_object_combined = '''                    <control type="group">
                        <left>10</left>
                        <visible>$PARAM[use_icon_text]</visible>
                        <control type="image">
                            <include>Home_Grouplist_Icon_Definition</include>
                            <texture background="true" colordiffuse="main_fg_30">$VAR[Home_Icon_$PARAM[window]]</texture>
                        </control>
                        <control type="label">
                            <left>80</left>
                            <font>font_mini</font>
                            <textcolor>main_fg_30</textcolor>
                            <label>[UPPERCASE]$INFO[Skin.String(HomeSwitcher.$PARAM[window].Name)][/UPPERCASE]</label>
                        </control>
                    </control>'''
        new_object_combined = '''                    <control type="group">
                        <left>10</left>
                        <visible>$PARAM[use_icon_text] + !Window.IsVisible($PARAM[window])</visible>
                        <control type="button">
                            <font>font_mini</font>
                            <textcolor>main_fg_30</textcolor>
                            <focusedcolor>main_fg_30</focusedcolor>
                            <label>[UPPERCASE]$INFO[Skin.String(HomeSwitcher.$PARAM[window].Name)][/UPPERCASE]</label>
                            <textoffsetx>80</textoffsetx>
                            <height>80</height>
                            <width>auto</width>
                            <texturenofocus />
                            <texturefocus />
                        </control>
                        <control type="image">
                            <left>20</left>
                            <centertop>50%</centertop>
                            <width>40</width>
                            <height>40</height>
                            <bordersize>icon_home_bordersize</bordersize>
                            <texture background="true" colordiffuse="main_fg_30">$VAR[Home_Icon_$PARAM[window]]</texture>
                        </control>
                    </control>'''
        home_new, _, error = replace_once(
            home_new,
            old_object_combined,
            new_object_combined,
            "upgraded unfocused Icon + Text layout",
        )
        if error:
            log(error + "; Icon + Text upgrade skipped.", xbmc.LOGWARNING)
            return False

        old_focus_combined = '''                    <control type="group">
                        <left>10</left>
                        <visible>$PARAM[use_icon_text]</visible>
                        <control type="group">
                            <width>80</width>
                            <control type="image">
                                <include>Texture_Menu_Highlight_H</include>
                            </control>
                            <control type="image">
                                <include>Home_Grouplist_Icon_Definition</include>
                                <texture background="true" colordiffuse="$VAR[ColorSelected]">$VAR[Home_Icon_$PARAM[window]]</texture>
                            </control>
                        </control>
                        <control type="label">
                            <left>80</left>
                            <font>font_mini</font>
                            <textcolor>$VAR[ColorSelected]</textcolor>
                            <label>[UPPERCASE]$INFO[Skin.String(HomeSwitcher.$PARAM[window].Name)][/UPPERCASE]</label>
                        </control>
                    </control>'''
        new_focus_combined = '''                    <control type="group">
                        <left>10</left>
                        <visible>$PARAM[use_icon_text]</visible>
                        <control type="button">
                            <font>font_mini</font>
                            <textcolor>$VAR[ColorSelected]</textcolor>
                            <focusedcolor>$VAR[ColorSelected]</focusedcolor>
                            <label>[UPPERCASE]$INFO[Skin.String(HomeSwitcher.$PARAM[window].Name)][/UPPERCASE]</label>
                            <textoffsetx>80</textoffsetx>
                            <height>80</height>
                            <width>auto</width>
                            <include>Texture_Highlight_Button_FakeFocus_H</include>
                        </control>
                        <control type="image">
                            <left>20</left>
                            <centertop>50%</centertop>
                            <width>40</width>
                            <height>40</height>
                            <bordersize>icon_home_bordersize</bordersize>
                            <texture background="true" colordiffuse="$VAR[ColorSelected]">$VAR[Home_Icon_$PARAM[window]]</texture>
                        </control>
                    </control>'''
        home_new, _, error = replace_once(
            home_new,
            old_focus_combined,
            new_focus_combined,
            "upgraded focused Icon + Text layout",
        )
        if error:
            log(error + "; Icon + Text upgrade skipped.", xbmc.LOGWARNING)
            return False

    changed = False
    for path, old, new in (
        (home_path, home, home_new),
        (labels_path, labels, labels_new),
        (settings_path, settings, settings_new),
    ):
        if new != old:
            write_text(path, new)
            changed = True

    if changed:
        log("Reapplied local Top-menu Icon + Text presentation patch.")
    return changed


def patch_home_focus(skin_root):
    """Reproduce the Top-menu-to-widget focus transition used by a real Down action."""
    home_path = os.path.join(skin_root, "1080i", "Home.xml")
    shortcuts_dir = os.path.join(skin_root, "shortcuts")
    focus_path = os.path.join(shortcuts_dir, HOME_FOCUS_FILE)

    if not os.path.isfile(home_path):
        log("Home-focus patch: Home.xml is missing; skipped.", xbmc.LOGWARNING)
        return False

    home = read_text(home_path)
    old_focus = (
        '<onload condition="Skin.HasSetting(Home.FirstRun) + '
        'String.IsEmpty(Window(1198).Property(FirstStart))">'
        '$VAR[Action_FirstStart_HomeFocus]</onload>'
    )
    new_focus = (
        '<onload condition="Skin.HasSetting(Home.FirstRun) + '
        'String.IsEmpty(Window(1198).Property(FirstStart))">'
        + HOME_FOCUS_CALL + '</onload>'
    )

    home_new = home
    if HOME_FOCUS_CALL not in home_new:
        home_new, _, error = replace_once(
            home_new, old_focus, new_focus, "Home initial focus transition"
        )
        if error:
            log(error + "; Home-focus patch skipped.", xbmc.LOGWARNING)
            return False

    # Home.xml anchor is verified before creating/replacing the helper JSON.
    changed = False
    if home_new != home:
        write_text(home_path, home_new)
        changed = True

    if not os.path.isdir(shortcuts_dir):
        os.makedirs(shortcuts_dir)
    current_json = read_text(focus_path) if os.path.isfile(focus_path) else None
    if current_json != HOME_FOCUS_JSON:
        write_text(focus_path, HOME_FOCUS_JSON)
        changed = True

    if changed:
        log("Reapplied Home initial-focus transition patch.")
    return changed


def patch_skin():
    skin_root = xbmcvfs.translatePath("special://home/addons/{}/".format(SKIN_ID))
    if not os.path.isdir(skin_root):
        return False

    changed_top = False
    changed_focus = False
    changed_icon_text = False

    # Keep the patches independent: a future AF3 change that breaks one patch
    # should not prevent the other known-safe patch from being applied.
    try:
        changed_top = patch_top_up(skin_root)
    except Exception as exc:
        log("Top-menu patch check failed: {}".format(exc), xbmc.LOGERROR)

    try:
        changed_focus = patch_home_focus(skin_root)
    except Exception as exc:
        log("Home-focus patch check failed: {}".format(exc), xbmc.LOGERROR)

    try:
        changed_icon_text = patch_icon_text(skin_root)
    except Exception as exc:
        log("Icon + Text patch check failed: {}".format(exc), xbmc.LOGERROR)

    if not (changed_top or changed_focus or changed_icon_text):
        return False

    message = "Personal skin updates reapplied"

    xbmcgui.Dialog().notification(
        "Arctic Fuse 3",
        message,
        xbmcgui.NOTIFICATION_INFO,
        4000,
    )

    if xbmc.getSkinDir() == SKIN_ID:
        xbmc.executebuiltin("ReloadSkin()")
    return True


def run():
    monitor = xbmc.Monitor()
    # Give Kodi/add-on updates a few seconds to settle at startup.
    if monitor.waitForAbort(5):
        return

    patch_skin()

    while not monitor.waitForAbort(CHECK_SECONDS):
        patch_skin()


if __name__ == "__main__":
    run()
