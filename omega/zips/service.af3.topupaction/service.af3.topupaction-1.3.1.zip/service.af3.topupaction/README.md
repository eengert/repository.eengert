# Arctic Fuse 3 Patch Service v1.3.1

This Kodi service preserves three local Arctic Fuse 3 modifications after skin updates:

1. Configurable Top-menu Up action (Submenu or Options).
2. Home startup/reload focus-transition workaround for platforms where AF3 can initially render with the widgets pushed down and the Top menu missing.
3. A third horizontal Top-menu display option, `Icon + Text`, using a regular, slightly smaller uppercase label beside each icon.

## v1.3 Icon + Text style

The Home menu appearance setting now cycles through Text, Icon, and Icon + Text. The additional style affects only the horizontal/Top menu and leaves both existing styles and the vertical menu unchanged.

### v1.3.1 layout correction

The selected Icon + Text item now uses one auto-width highlight pill around both the icon and label. The active item's unfocused base layer is hidden so a duplicate icon cannot appear after the text.

## v1.2 focus workaround

The previous v1.1 test only delayed the initial SetFocus call. That did not reproduce the behavior that fixes the layout when the user presses Down.

v1.2 instead reproduces that navigation path for the horizontal/Top menu:

- wait 0.5 seconds after Home startup initialization
- explicitly focus the Top menu control (300)
- wait 0.15 seconds
- issue Kodi `Action(Down)`

That causes AF3's existing `Home_Horz_Movement` / `Hub_Action_Down` logic and downstream `onfocus` handlers to run just as they do when Down is pressed on the remote. Vertical-menu configurations continue to use AF3's existing initial-focus selection logic.

The service checks the AF3 skin periodically and reapplies known-safe patches when an AF3 update overwrites them. If expected anchors change, the affected patch is skipped rather than guessing.
