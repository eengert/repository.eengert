# -*- coding: utf-8 -*-
import hashlib
import os
import re
import xml.etree.ElementTree as ElementTree

import xbmc
import xbmcvfs

ADDON_ID = "service.redlight.stylepatch"
REDLIGHT_ID = "plugin.video.redlight"
CHECK_SECONDS = 60
STARTUP_DELAY_SECONDS = 5
PLAYBACK_XML = os.path.join("resources", "skins", "Default", "1080i", "sources_playback.xml")
MEDIA_URL = "special://home/addons/{}/resources/media/".format(ADDON_ID)

# The loading screen progress indicator is the block between these two comments in
# sources_playback.xml. Its stock content is identical in Red Light 2.6.8 and
# 2.7.8; any other content is treated as a structure change and left alone.
PROGRESS_START = "            <!-- Progress -->\n"
PROGRESS_END = "            <!-- Scraper -->\n"
PATCHED_PROGRESS_START = "            <!-- Progress: "
# Regions this service can replace in place: the stock bar, and the bars that
# earlier installs of this add-on already wrote into Red Light (1.0.0 to 1.1.0).
STOCK_PROGRESS_SHA256 = "a4727998e297b7cc3a0cefc89f4ec2b10fcde5179f937236181b3caf518900a4"
PATCHED_1_0_0_PROGRESS_SHA256 = "7ec3eed65daf2c79764ec6c30bcd76674cb3dd42323b3b6ed84c1b85e0779c02"
PATCHED_1_0_1_PROGRESS_SHA256 = "8533314aabf3e47a85686d7dca527217734df2ee5df67bf6538c7a09f76c20f5"
PATCHED_1_0_2_PROGRESS_SHA256 = "b4baf321f69b975c511b125e7d1567e26eacbf52477c592826ceca4fe557e9c9"
PATCHED_1_0_3_PROGRESS_SHA256 = "f63ec6a218b062807206d97366f9bf4c067eb0997b5f03274128e41f740e69a7"
PATCHED_1_0_4_PROGRESS_SHA256 = "6daea86efb30b87d6143175cff9a2f871f3c26f78065a8c1cd26978c0946aa82"
PATCHED_1_0_5_PROGRESS_SHA256 = "6af06bcb95450a4d2e18a5b3c93a3266aeccdada4048ea5277a844eed19f4215"
PATCHED_1_0_6_PROGRESS_SHA256 = "18c5d48d10386dbee671bf59541845957b2c02dfb44a2de0d36bb1eca6146915"
PATCHED_1_1_0_PROGRESS_SHA256 = "a4ba85f7c77a9329c2331110f726b17d9e742112cf3d07c5c68dac9c54a22e11"
KNOWN_PROGRESS_SHA256 = (
    STOCK_PROGRESS_SHA256,
    PATCHED_1_0_0_PROGRESS_SHA256,
    PATCHED_1_0_1_PROGRESS_SHA256,
    PATCHED_1_0_2_PROGRESS_SHA256,
    PATCHED_1_0_3_PROGRESS_SHA256,
    PATCHED_1_0_4_PROGRESS_SHA256,
    PATCHED_1_0_5_PROGRESS_SHA256,
    PATCHED_1_0_6_PROGRESS_SHA256,
    PATCHED_1_1_0_PROGRESS_SHA256,
)
# The resolve screen's description: a textbox with no id whose only text is the plot
# (for episodes, the episode line and plot share it). Its label is unique in the file.
PLOT_LABEL = "<label>$INFO[Window.Property(text)]</label>"
# Red Light's own small busy spinner, which shares the loading screen with the indicator.
BUSY_SPINNER_MARKER = "redlight_common/spinner.png"

# Textboxes that carry provider names (2001 while scraping) and source or
# filename details (2002 while resolving). The controls stay in place because
# the Python still calls setLabel/setText on them; only their visibility changes.
DETAIL_TEXTBOX_IDS = (2001, 2002)

# The loading indicator is a circular spinner made of four native Kodi images: a faint
# track, a thin stationary inner ring, the rotating cyan arc, and a glowing centre circle
# that pulses. Kodi runs every animation itself, so the service keeps no timer, thread or
# Python animation loop.
SPINNER_SIZE = 52           # diameter at 1080p, in pixels
SPINNER_LEFT = 934          # centred on x=960 (960 - 26)
SPINNER_TOP = 541           # centred on y=567, where the old bar sat (567 - 26)
SPINNER_ROTATION_MS = 1350  # one full turn of the arc, linear
SPINNER_PULSE_MS = 1200     # one half of the centre pulse; a full in-and-out cycle is twice this
SPINNER_PULSE_ZOOM = (80, 120)  # centre circle size, percent of its 12 px
SPINNER_PULSE_FADE = (55, 100)  # centre circle brightness, percent
SPINNER_TRACK = MEDIA_URL + "spinner_track.png"
SPINNER_INNER = MEDIA_URL + "spinner_inner.png"
SPINNER_ARC = MEDIA_URL + "spinner_arc.png"
SPINNER_CORE = MEDIA_URL + "spinner_core.png"
SPINNER_TRACK_RGB = "592A4B66"  # faint muted blue track: #2A4B66 at 35% alpha


def _spinner_image(texture, colour=None, animations=()):
    texture_tag = '<texture colordiffuse="{}">{}</texture>'.format(colour, texture) if colour else "<texture>{}</texture>".format(texture)
    lines = [
        '                <control type="image">',
        '                    <left>{}</left>'.format(SPINNER_LEFT),
        '                    <top>{}</top>'.format(SPINNER_TOP),
        '                    <width>{}</width>'.format(SPINNER_SIZE),
        '                    <height>{}</height>'.format(SPINNER_SIZE),
        '                    ' + texture_tag,
    ]
    lines += ['                    ' + animation for animation in animations]
    lines.append('                </control>')
    return lines


def build_spinner():
    rotate = (
        '<animation effect="rotate" start="0" end="360" center="auto" time="{}" tween="linear" '
        'loop="true" reversible="false" condition="true">Conditional</animation>'
    ).format(SPINNER_ROTATION_MS)
    zoom_pulse = (
        '<animation effect="zoom" start="{}" end="{}" center="auto" time="{}" tween="sine" easing="inout" '
        'condition="true" pulse="true">Conditional</animation>'
    ).format(SPINNER_PULSE_ZOOM[0], SPINNER_PULSE_ZOOM[1], SPINNER_PULSE_MS)
    fade_pulse = (
        '<animation effect="fade" start="{}" end="{}" time="{}" tween="sine" easing="inout" '
        'condition="true" pulse="true">Conditional</animation>'
    ).format(SPINNER_PULSE_FADE[0], SPINNER_PULSE_FADE[1], SPINNER_PULSE_MS)
    lines = [
        '            <!-- Progress: circular loading spinner (Red Light Style Patch) -->',
        '            <control type="group">',
        '                <visible>String.IsEqual(Window.Property(window_mode),scraper) | String.IsEqual(Window.Property(window_mode),resolver)</visible>',
    ]
    lines += _spinner_image(SPINNER_TRACK, colour=SPINNER_TRACK_RGB)
    lines += _spinner_image(SPINNER_INNER)
    lines += _spinner_image(SPINNER_ARC, animations=[rotate])
    lines += _spinner_image(SPINNER_CORE, animations=[zoom_pulse, fade_pulse])
    lines.append('            </control>')
    return "".join(line + "\n" for line in lines)


PROGRESS_SPINNER = build_spinner()

VISIBLE_LINE = re.compile(r"[ \t]*<visible>.*</visible>\n$")
_reported = set()


def log(message, level=xbmc.LOGINFO):
    xbmc.log("[{}] {}".format(ADDON_ID, message), level)


def report_once(message):
    """Log a skipped patch once per distinct reason instead of on every check."""
    if message in _reported:
        return
    _reported.add(message)
    log("{}; loading-screen patch skipped.".format(message), xbmc.LOGWARNING)


def read_text(path):
    """Return the file as LF-only text plus the newline style it was written with."""
    with open(path, "rb") as handle:
        raw = handle.read().decode("utf-8")
    newline = "\r\n" if "\r\n" in raw else "\n"
    return raw.replace("\r\n", "\n"), newline


def write_text(path, content, newline):
    """Write through a temp file and os.replace so Kodi never reads a half-written XML."""
    tmp = path + ".stylepatch.tmp"
    try:
        with open(tmp, "wb") as handle:
            handle.write(content.replace("\n", newline).encode("utf-8"))
        os.replace(tmp, path)
    except OSError:
        if os.path.exists(tmp):
            os.remove(tmp)
        raise


def replace_progress_indicator(content):
    """Swap the stock indicator, or one from an earlier patch, for the spinner. Returns (content, error)."""
    stock_starts = content.count(PROGRESS_START)
    patched_starts = content.count(PATCHED_PROGRESS_START)
    ends = content.count(PROGRESS_END)
    if stock_starts + patched_starts != 1 or ends != 1:
        return content, "Progress anchors found {} start and {} end markers".format(stock_starts + patched_starts, ends)
    start = content.index(PROGRESS_START if stock_starts else PATCHED_PROGRESS_START)
    end = content.index(PROGRESS_END)
    if end < start:
        return content, "Progress anchors are out of order"
    region = content[start:end]
    if region == PROGRESS_SPINNER:
        return content, None
    if hashlib.sha256(region.encode("utf-8")).hexdigest() not in KNOWN_PROGRESS_SHA256:
        return content, "Progress indicator structure differs from the known Red Light layout"
    return content[:start] + PROGRESS_SPINNER + content[end:], None


def _control_matches(content, head):
    """Every control whose opening line is exactly `head`, with its body and closing line."""
    pattern = re.compile(
        r'^(?P<head>[ \t]*' + re.escape(head) + r'\n)'
        r'(?P<body>(?:(?![ \t]*</control>\n)[^\n]*\n)*)'
        r'(?P<tail>[ \t]*</control>\n)',
        re.M,
    )
    return list(pattern.finditer(content))


def _hide_control_match(content, matches, description):
    """Set one matched control to visible=false, keeping its other properties."""
    if len(matches) != 1:
        return content, "{} anchor found {} times".format(description, len(matches))
    match = matches[0]
    lines = match.group("body").splitlines(True)
    if not lines or "<control" in match.group("body"):
        return content, "{} has an unexpected layout".format(description)
    indent = lines[0][:len(lines[0]) - len(lines[0].lstrip(" \t"))]
    kept = "".join(line for line in lines if not VISIBLE_LINE.match(line))
    hidden = match.group("head") + indent + "<visible>false</visible>\n" + kept + match.group("tail")
    if hidden == match.group(0):
        return content, None
    return content[:match.start()] + hidden + content[match.end():], None


def hide_textbox(content, control_id):
    head = '<control type="textbox" id="{}">'.format(control_id)
    return _hide_control_match(content, _control_matches(content, head), "Textbox {}".format(control_id))


def hide_plot_textbox(content):
    matches = [m for m in _control_matches(content, '<control type="textbox">') if PLOT_LABEL in m.group("body")]
    return _hide_control_match(content, matches, "Description textbox")


def hide_busy_spinner(content):
    """Hide Red Light's own busy spinner, which sits beside the indicator on the loading screen."""
    matches = [m for m in _control_matches(content, '<control type="image">') if BUSY_SPINNER_MARKER in m.group("body")]
    return _hide_control_match(content, matches, "Busy spinner")


def patch_playback_xml(content):
    """Return (patched, error). On any error the input is returned unchanged."""
    patched, error = replace_progress_indicator(content)
    for control_id in DETAIL_TEXTBOX_IDS:
        if error:
            break
        patched, error = hide_textbox(patched, control_id)
    if not error:
        patched, error = hide_plot_textbox(patched)
    if not error:
        patched, error = hide_busy_spinner(patched)
    if error:
        return content, error
    for required in ('id="2001"', 'id="2002"', PLOT_LABEL, BUSY_SPINNER_MARKER, "redlight.scrape.results_total"):
        if required not in patched:
            return content, "Expected {} is missing after patching".format(required)
    try:
        ElementTree.fromstring(patched.encode("utf-8"))
    except ElementTree.ParseError as exc:
        return content, "Patched XML is not well formed ({})".format(exc)
    return patched, None


def apply_playback_patch(redlight_root):
    """Re-apply the patch if needed. Returns True only when the file was written."""
    path = os.path.join(redlight_root, PLAYBACK_XML)
    if not os.path.isfile(path):
        report_once("sources_playback.xml not found in {}".format(redlight_root))
        return False
    content, newline = read_text(path)
    patched, error = patch_playback_xml(content)
    if error:
        report_once(error)
        return False
    if patched == content:
        return False
    write_text(path, patched, newline)
    log("Reapplied the Red Light loading spinner and hid source details.")
    return True


def patch_red_light():
    redlight_root = xbmcvfs.translatePath("special://home/addons/{}/".format(REDLIGHT_ID))
    if not os.path.isdir(redlight_root):
        return False
    try:
        return apply_playback_patch(redlight_root)
    except Exception as exc:
        report_once("Loading-screen patch check failed: {}".format(exc))
        return False


def run():
    monitor = xbmc.Monitor()
    # Give Kodi and add-on updates a few seconds to settle at startup.
    if monitor.waitForAbort(STARTUP_DELAY_SECONDS):
        return

    patch_red_light()

    while not monitor.waitForAbort(CHECK_SECONDS):
        patch_red_light()


if __name__ == "__main__":
    run()
