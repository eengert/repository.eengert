# -*- coding: utf-8 -*-
import hashlib
import os
import re
import xml.etree.ElementTree as ElementTree

import xbmc
import xbmcvfs

ADDON_ID = "service.redlight.stylepatch"
REDLIGHT_ID = "plugin.video.redlight"
CHECK_SECONDS = 60
STARTUP_DELAY_SECONDS = 5
PLAYBACK_XML = os.path.join("resources", "skins", "Default", "1080i", "sources_playback.xml")
MEDIA_URL = "special://home/addons/{}/resources/media/".format(ADDON_ID)

# The loading screen progress bar is the block between these two comments in
# sources_playback.xml. Its stock content is identical in Red Light 2.6.8 and
# 2.7.8; any other content is treated as a structure change and left alone.
PROGRESS_START = "            <!-- Progress -->\n"
PROGRESS_END = "            <!-- Scraper -->\n"
PATCHED_PROGRESS_START = "            <!-- Progress: thin rounded cyan-blue bar"
# Regions this service can replace in place: the stock bar, and the bars that
# earlier installs of this add-on already wrote into Red Light (1.0.0 to 1.0.4).
STOCK_PROGRESS_SHA256 = "a4727998e297b7cc3a0cefc89f4ec2b10fcde5179f937236181b3caf518900a4"
PATCHED_1_0_0_PROGRESS_SHA256 = "7ec3eed65daf2c79764ec6c30bcd76674cb3dd42323b3b6ed84c1b85e0779c02"
PATCHED_1_0_1_PROGRESS_SHA256 = "8533314aabf3e47a85686d7dca527217734df2ee5df67bf6538c7a09f76c20f5"
PATCHED_1_0_2_PROGRESS_SHA256 = "b4baf321f69b975c511b125e7d1567e26eacbf52477c592826ceca4fe557e9c9"
PATCHED_1_0_3_PROGRESS_SHA256 = "f63ec6a218b062807206d97366f9bf4c067eb0997b5f03274128e41f740e69a7"
PATCHED_1_0_4_PROGRESS_SHA256 = "6daea86efb30b87d6143175cff9a2f871f3c26f78065a8c1cd26978c0946aa82"
KNOWN_PROGRESS_SHA256 = (
    STOCK_PROGRESS_SHA256,
    PATCHED_1_0_0_PROGRESS_SHA256,
    PATCHED_1_0_1_PROGRESS_SHA256,
    PATCHED_1_0_2_PROGRESS_SHA256,
    PATCHED_1_0_3_PROGRESS_SHA256,
    PATCHED_1_0_4_PROGRESS_SHA256,
)

# Textboxes that carry provider names (2001 while scraping) and source or
# filename details (2002 while resolving). The controls stay in place because
# the Python still calls setLabel/setText on them; only their visibility changes.
DETAIL_TEXTBOX_IDS = (2001, 2002)

# One bar for the whole load. Both phases report 0-100 through the same property, so
# window_mode decides which part of the bar a value means. The bar is tuned to what Red
# Light's logs show on a 10 s results timeout, for a load of about 9.5 s:
#   - The scrape finishes 1.2-2.6 s in, so the scrape percent is only 12-26 by then.
#     The scrape half fills by SCRAPE_FULL_AT, and the bar holds at BAR_SPLIT after that.
#   - The resolve shows BAR_SPLIT while Red Light opens the stream, about 1.8 s.
#   - The resolve timer starts once the stream opens and playback usually starts about
#     5-6 s later, near timer 30. The bar is near full by then. The slow tail runs to 100.
BAR_SPLIT = 40
SCRAPE_FULL_AT = 12         # scrape percent at which the scrape half is full (1.2 s)
RESOLVE_TYPICAL_START = 30  # resolve timer value where playback usually starts
RESOLVE_AT_START = 97       # bar value at that point; the last 3% is a slow tail to 100
SCRAPE_PERCENTS = range(1, 101)
RESOLVE_PERCENTS = range(0, 101)
BAR_WIDTH = 420
BAR_HEIGHT = 8
BAR_PILL = MEDIA_URL + "bar_pill.png"
BAR_TRACK_RGB = "33FFFFFF"
BAR_FILL_RGB = "FF19B8F2"


def scrape_bar_value(percent):
    return BAR_SPLIT * min(percent, SCRAPE_FULL_AT) / float(SCRAPE_FULL_AT)


def resolve_bar_value(percent):
    if percent <= RESOLVE_TYPICAL_START:
        return BAR_SPLIT + (RESOLVE_AT_START - BAR_SPLIT) * percent / float(RESOLVE_TYPICAL_START)
    tail = 100 - RESOLVE_TYPICAL_START
    return RESOLVE_AT_START + (100 - RESOLVE_AT_START) * (percent - RESOLVE_TYPICAL_START) / float(tail)


def _fill_group(mode, percents, bar_value):
    # The fill is built from steps, not a progress control: Kodi's progress <info> only
    # reads built-in infolabels, so a Window property leaves it stuck at zero. Each step
    # is one rounded pill, shown only at its own percent. Stacked pills would compound
    # their anti-aliased edges until the corners looked square.
    lines = [
        '                <control type="group">',
        '                    <visible>String.IsEqual(Window.Property(window_mode),{})</visible>'.format(mode),
    ]
    for percent in percents:
        width = max(BAR_HEIGHT, int(round(BAR_WIDTH * bar_value(percent) / 100.0)))
        # The top step also takes anything above 100, so an overshoot never empties the bar.
        test = "Integer.IsGreaterOrEqual" if percent == 100 else "Integer.IsEqual"
        lines += [
            '                    <control type="image">',
            '                        <width>{}</width>'.format(width),
            '                        <height>{}</height>'.format(BAR_HEIGHT),
            '                        <texture border="{}" colordiffuse="{}">{}</texture>'.format(BAR_HEIGHT // 2, BAR_FILL_RGB, BAR_PILL),
            '                        <visible>{}(Window(10000).Property(redlight.scrape.percent),{})</visible>'.format(test, percent),
            '                    </control>',
        ]
    lines.append('                </control>')
    return lines


def build_progress_bar():
    lines = [
        '            <!-- Progress: thin rounded cyan-blue bar (Red Light Style Patch) -->',
        '            <control type="group">',
        '                <visible>String.IsEqual(Window.Property(window_mode),scraper) | String.IsEqual(Window.Property(window_mode),resolver)</visible>',
        '                <top>563</top>',
        '                <left>750</left>',
        '                <width>{}</width>'.format(BAR_WIDTH),
        '                <height>{}</height>'.format(BAR_HEIGHT),
        '                <control type="image">',
        '                    <width>{}</width>'.format(BAR_WIDTH),
        '                    <height>{}</height>'.format(BAR_HEIGHT),
        '                    <texture border="{}" colordiffuse="{}">{}</texture>'.format(BAR_HEIGHT // 2, BAR_TRACK_RGB, BAR_PILL),
        '                </control>',
    ]
    lines += _fill_group("scraper", SCRAPE_PERCENTS, scrape_bar_value)
    lines += _fill_group("resolver", RESOLVE_PERCENTS, resolve_bar_value)
    lines.append('            </control>')
    return "".join(line + "\n" for line in lines)


PROGRESS_BAR = build_progress_bar()

VISIBLE_LINE = re.compile(r"[ \t]*<visible>.*</visible>\n$")
_reported = set()


def log(message, level=xbmc.LOGINFO):
    xbmc.log("[{}] {}".format(ADDON_ID, message), level)


def report_once(message):
    """Log a skipped patch once per distinct reason instead of on every check."""
    if message in _reported:
        return
    _reported.add(message)
    log("{}; loading-screen patch skipped.".format(message), xbmc.LOGWARNING)


def read_text(path):
    """Return the file as LF-only text plus the newline style it was written with."""
    with open(path, "rb") as handle:
        raw = handle.read().decode("utf-8")
    newline = "\r\n" if "\r\n" in raw else "\n"
    return raw.replace("\r\n", "\n"), newline


def write_text(path, content, newline):
    """Write through a temp file and os.replace so Kodi never reads a half-written XML."""
    tmp = path + ".stylepatch.tmp"
    try:
        with open(tmp, "wb") as handle:
            handle.write(content.replace("\n", newline).encode("utf-8"))
        os.replace(tmp, path)
    except OSError:
        if os.path.exists(tmp):
            os.remove(tmp)
        raise


def replace_progress_bar(content):
    """Swap the stock bar, or a bar from an earlier patch, for the current bar. Returns (content, error)."""
    stock_starts = content.count(PROGRESS_START)
    patched_starts = content.count(PATCHED_PROGRESS_START)
    ends = content.count(PROGRESS_END)
    if stock_starts + patched_starts != 1 or ends != 1:
        return content, "Progress anchors found {} start and {} end markers".format(stock_starts + patched_starts, ends)
    start = content.index(PROGRESS_START if stock_starts else PATCHED_PROGRESS_START)
    end = content.index(PROGRESS_END)
    if end < start:
        return content, "Progress anchors are out of order"
    region = content[start:end]
    if region == PROGRESS_BAR:
        return content, None
    if hashlib.sha256(region.encode("utf-8")).hexdigest() not in KNOWN_PROGRESS_SHA256:
        return content, "Progress bar structure differs from the known Red Light layout"
    return content[:start] + PROGRESS_BAR + content[end:], None


def hide_textbox(content, control_id):
    """Set a textbox to visible=false, keeping the control and its other properties."""
    pattern = re.compile(
        r'^(?P<head>[ \t]*<control type="textbox" id="{}">\n)'
        r'(?P<body>(?:(?![ \t]*</control>\n)[^\n]*\n)*)'
        r'(?P<tail>[ \t]*</control>\n)'.format(control_id),
        re.M,
    )
    matches = list(pattern.finditer(content))
    if len(matches) != 1:
        return content, "Textbox {} anchor found {} times".format(control_id, len(matches))
    match = matches[0]
    lines = match.group("body").splitlines(True)
    if not lines or "<control" in match.group("body"):
        return content, "Textbox {} has an unexpected layout".format(control_id)
    indent = lines[0][:len(lines[0]) - len(lines[0].lstrip(" \t"))]
    kept = "".join(line for line in lines if not VISIBLE_LINE.match(line))
    hidden = match.group("head") + indent + "<visible>false</visible>\n" + kept + match.group("tail")
    if hidden == match.group(0):
        return content, None
    return content[:match.start()] + hidden + content[match.end():], None


def patch_playback_xml(content):
    """Return (patched, error). On any error the input is returned unchanged."""
    patched, error = replace_progress_bar(content)
    for control_id in DETAIL_TEXTBOX_IDS:
        if error:
            break
        patched, error = hide_textbox(patched, control_id)
    if error:
        return content, error
    for required in ('id="2001"', 'id="2002"', "redlight.scrape.percent", "redlight.scrape.results_total"):
        if required not in patched:
            return content, "Expected {} is missing after patching".format(required)
    try:
        ElementTree.fromstring(patched.encode("utf-8"))
    except ElementTree.ParseError as exc:
        return content, "Patched XML is not well formed ({})".format(exc)
    return patched, None


def apply_playback_patch(redlight_root):
    """Re-apply the patch if needed. Returns True only when the file was written."""
    path = os.path.join(redlight_root, PLAYBACK_XML)
    if not os.path.isfile(path):
        report_once("sources_playback.xml not found in {}".format(redlight_root))
        return False
    content, newline = read_text(path)
    patched, error = patch_playback_xml(content)
    if error:
        report_once(error)
        return False
    if patched == content:
        return False
    write_text(path, patched, newline)
    log("Reapplied the Red Light thin progress bar and hid source details.")
    return True


def patch_red_light():
    redlight_root = xbmcvfs.translatePath("special://home/addons/{}/".format(REDLIGHT_ID))
    if not os.path.isdir(redlight_root):
        return False
    try:
        return apply_playback_patch(redlight_root)
    except Exception as exc:
        report_once("Loading-screen patch check failed: {}".format(exc))
        return False


def run():
    monitor = xbmc.Monitor()
    # Give Kodi and add-on updates a few seconds to settle at startup.
    if monitor.waitForAbort(STARTUP_DELAY_SECONDS):
        return

    patch_red_light()

    while not monitor.waitForAbort(CHECK_SECONDS):
        patch_red_light()


if __name__ == "__main__":
    run()
