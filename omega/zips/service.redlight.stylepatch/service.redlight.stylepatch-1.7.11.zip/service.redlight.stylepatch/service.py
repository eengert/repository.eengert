# -*- coding: utf-8 -*-
import hashlib
import os
import re
import xml.etree.ElementTree as ElementTree

import xbmc
import xbmcvfs

ADDON_ID = "service.redlight.stylepatch"
REDLIGHT_ID = "plugin.video.redlight"
CHECK_SECONDS = 60
STARTUP_DELAY_SECONDS = 5
PLAYBACK_XML = os.path.join("resources", "skins", "Default", "1080i", "sources_playback.xml")
MEDIA_URL = "special://home/addons/{}/resources/media/".format(ADDON_ID)

# The loading screen progress indicator is the block between these two comments in
# sources_playback.xml. Its stock content is identical in Red Light 2.6.8 and
# 2.7.8; any other content is treated as a structure change and left alone.
PROGRESS_START = "            <!-- Progress -->\n"
PROGRESS_END = "            <!-- Scraper -->\n"
PATCHED_PROGRESS_START = "            <!-- Progress: "
# Regions this service can replace in place: the stock bar, and the bars that
# earlier installs of this add-on already wrote into Red Light (1.0.0 to 1.4.0).
STOCK_PROGRESS_SHA256 = "a4727998e297b7cc3a0cefc89f4ec2b10fcde5179f937236181b3caf518900a4"
PATCHED_1_0_0_PROGRESS_SHA256 = "7ec3eed65daf2c79764ec6c30bcd76674cb3dd42323b3b6ed84c1b85e0779c02"
PATCHED_1_0_1_PROGRESS_SHA256 = "8533314aabf3e47a85686d7dca527217734df2ee5df67bf6538c7a09f76c20f5"
PATCHED_1_0_2_PROGRESS_SHA256 = "b4baf321f69b975c511b125e7d1567e26eacbf52477c592826ceca4fe557e9c9"
PATCHED_1_0_3_PROGRESS_SHA256 = "f63ec6a218b062807206d97366f9bf4c067eb0997b5f03274128e41f740e69a7"
PATCHED_1_0_4_PROGRESS_SHA256 = "6daea86efb30b87d6143175cff9a2f871f3c26f78065a8c1cd26978c0946aa82"
PATCHED_1_0_5_PROGRESS_SHA256 = "6af06bcb95450a4d2e18a5b3c93a3266aeccdada4048ea5277a844eed19f4215"
PATCHED_1_0_6_PROGRESS_SHA256 = "18c5d48d10386dbee671bf59541845957b2c02dfb44a2de0d36bb1eca6146915"
PATCHED_1_1_0_PROGRESS_SHA256 = "a4ba85f7c77a9329c2331110f726b17d9e742112cf3d07c5c68dac9c54a22e11"
PATCHED_1_2_0_PROGRESS_SHA256 = "a8cbb48bd45d7e47e88abc0719f57651c2883eaee7afbd06a71722746e5d9d8c"
PATCHED_1_3_0_PROGRESS_SHA256 = "5d07932e7040973943dc17963a468c8542f016b8fcdb05ec556f7159b428bdc6"
PATCHED_1_4_0_PROGRESS_SHA256 = "f610a228d7a6148d725e8d7773df8cdf5c4e50ea826a993e29c5f67d0ee2ec34"
# 1.6.13 to 1.7.0 wrote the spinner with its arc turning counter-clockwise.
PATCHED_1_6_13_PROGRESS_SHA256 = "f43ded690ba1e319d222d846e23d09f16ca59c7896752d63239835687d37b8fb"
# 1.5.0 wrote the same spinner as 1.4.0.
KNOWN_PROGRESS_SHA256 = (
    STOCK_PROGRESS_SHA256,
    PATCHED_1_0_0_PROGRESS_SHA256,
    PATCHED_1_0_1_PROGRESS_SHA256,
    PATCHED_1_0_2_PROGRESS_SHA256,
    PATCHED_1_0_3_PROGRESS_SHA256,
    PATCHED_1_0_4_PROGRESS_SHA256,
    PATCHED_1_0_5_PROGRESS_SHA256,
    PATCHED_1_0_6_PROGRESS_SHA256,
    PATCHED_1_1_0_PROGRESS_SHA256,
    PATCHED_1_2_0_PROGRESS_SHA256,
    PATCHED_1_3_0_PROGRESS_SHA256,
    PATCHED_1_4_0_PROGRESS_SHA256,
    PATCHED_1_6_13_PROGRESS_SHA256,
)
# The resolve screen's description: a textbox with no id whose only text is the plot
# (for episodes, the episode line and plot share it). Its label is unique in the file.
PLOT_LABEL = "<label>$INFO[Window.Property(text)]</label>"
# Red Light's own small busy spinner, which shares the loading screen with the indicator.
BUSY_SPINNER_MARKER = "redlight_common/spinner.png"
# Red Light's logo in the upper-left corner of the loading screen.
LOGO_MARKER = "redlight.addon_icon_mini"

# Textboxes that carry provider names (2001 while scraping) and source or
# filename details (2002 while resolving). The controls stay in place because
# the Python still calls setLabel/setText on them; only their visibility changes.
DETAIL_TEXTBOX_IDS = (2001, 2002)

# The loading indicator is a circular spinner made of four native Kodi images: a faint
# track, a thin stationary inner ring, the rotating cyan arc, and a glowing centre circle
# that pulses. Kodi runs every animation itself, so the service keeps no timer, thread or
# Python animation loop.
SPINNER_SIZE = 52           # diameter at 1080p, in pixels
SPINNER_LEFT = 934          # centred on x=960 (960 - 26)
SPINNER_TOP = 565           # centred on y=591, with room above and below for the title and counts
SPINNER_ROTATION_MS = 1350  # one full turn of the arc, linear
SPINNER_PULSE_MS = 1200     # one half of the centre pulse; a full in-and-out cycle is twice this
SPINNER_PULSE_ZOOM = (80, 120)  # centre circle size, percent of its 12 px
SPINNER_PULSE_FADE = (55, 100)  # centre circle brightness, percent
SPINNER_TRACK = MEDIA_URL + "spinner_track.png"
SPINNER_INNER = MEDIA_URL + "spinner_inner.png"
SPINNER_ARC = MEDIA_URL + "spinner_arc.png"
SPINNER_CORE = MEDIA_URL + "spinner_core.png"
SPINNER_TRACK_RGB = "592A4B66"  # faint muted blue track: #2A4B66 at 35% alpha


def _spinner_image(texture, colour=None, animations=()):
    texture_tag = '<texture colordiffuse="{}">{}</texture>'.format(colour, texture) if colour else "<texture>{}</texture>".format(texture)
    lines = [
        '                <control type="image">',
        '                    <left>{}</left>'.format(SPINNER_LEFT),
        '                    <top>{}</top>'.format(SPINNER_TOP),
        '                    <width>{}</width>'.format(SPINNER_SIZE),
        '                    <height>{}</height>'.format(SPINNER_SIZE),
        # The skin is laid out for 16:9 and stretched on other shapes, so a square box can become
        # a rectangle. "keep" fits the square texture inside the box, so the spinner stays round.
        '                    <aspectratio align="center" aligny="center">keep</aspectratio>',
        '                    ' + texture_tag,
    ]
    lines += ['                    ' + animation for animation in animations]
    lines.append('                </control>')
    return lines


def build_spinner():
    # Kodi turns the arc from 360 down to 0, which is clockwise on screen.
    rotate = (
        '<animation effect="rotate" start="360" end="0" center="auto" time="{}" tween="linear" '
        'loop="true" reversible="false" condition="true">Conditional</animation>'
    ).format(SPINNER_ROTATION_MS)
    zoom_pulse = (
        '<animation effect="zoom" start="{}" end="{}" center="auto" time="{}" tween="sine" easing="inout" '
        'condition="true" pulse="true">Conditional</animation>'
    ).format(SPINNER_PULSE_ZOOM[0], SPINNER_PULSE_ZOOM[1], SPINNER_PULSE_MS)
    fade_pulse = (
        '<animation effect="fade" start="{}" end="{}" time="{}" tween="sine" easing="inout" '
        'condition="true" pulse="true">Conditional</animation>'
    ).format(SPINNER_PULSE_FADE[0], SPINNER_PULSE_FADE[1], SPINNER_PULSE_MS)
    lines = [
        '            <!-- Progress: circular loading spinner (Red Light Style Patch) -->',
        '            <control type="group">',
        '                <visible>String.IsEqual(Window.Property(window_mode),scraper) | String.IsEqual(Window.Property(window_mode),resolver)</visible>',
    ]
    lines += _spinner_image(SPINNER_TRACK, colour=SPINNER_TRACK_RGB)
    lines += _spinner_image(SPINNER_INNER)
    lines += _spinner_image(SPINNER_ARC, animations=[rotate])
    lines += _spinner_image(SPINNER_CORE, animations=[zoom_pulse, fade_pulse])
    lines.append('            </control>')
    return "".join(line + "\n" for line in lines)


PROGRESS_SPINNER = build_spinner()

VISIBLE_LINE = re.compile(r"[ \t]*<visible>.*</visible>\n$")
_reported = set()


def log(message, level=xbmc.LOGINFO):
    xbmc.log("[{}] {}".format(ADDON_ID, message), level)


def report_once(message, patch="loading-screen"):
    """Log a skipped patch once per distinct reason instead of on every check."""
    if message in _reported:
        return
    _reported.add(message)
    log("{}; {} patch skipped.".format(message, patch), xbmc.LOGWARNING)


def read_text(path):
    """Return the file as LF-only text plus the newline style it was written with."""
    with open(path, "rb") as handle:
        raw = handle.read().decode("utf-8")
    newline = "\r\n" if "\r\n" in raw else "\n"
    return raw.replace("\r\n", "\n"), newline


def write_text(path, content, newline):
    """Write through a temp file and os.replace so Kodi never reads a half-written XML."""
    tmp = path + ".stylepatch.tmp"
    try:
        with open(tmp, "wb") as handle:
            handle.write(content.replace("\n", newline).encode("utf-8"))
        os.replace(tmp, path)
    except OSError:
        if os.path.exists(tmp):
            os.remove(tmp)
        raise


def replace_progress_indicator(content):
    """Swap the stock indicator, or one from an earlier patch, for the spinner. Returns (content, error)."""
    stock_starts = content.count(PROGRESS_START)
    patched_starts = content.count(PATCHED_PROGRESS_START)
    ends = content.count(PROGRESS_END)
    if stock_starts + patched_starts != 1 or ends != 1:
        return content, "Progress anchors found {} start and {} end markers".format(stock_starts + patched_starts, ends)
    start = content.index(PROGRESS_START if stock_starts else PATCHED_PROGRESS_START)
    end = content.index(PROGRESS_END)
    if end < start:
        return content, "Progress anchors are out of order"
    region = content[start:end]
    if region == PROGRESS_SPINNER:
        return content, None
    if hashlib.sha256(region.encode("utf-8")).hexdigest() not in KNOWN_PROGRESS_SHA256:
        return content, "Progress indicator structure differs from the known Red Light layout"
    return content[:start] + PROGRESS_SPINNER + content[end:], None


def _control_matches(content, head):
    """Every control whose opening line is exactly `head`, with its body and closing line."""
    pattern = re.compile(
        r'^(?P<head>[ \t]*' + re.escape(head) + r'\n)'
        r'(?P<body>(?:(?![ \t]*</control>\n)[^\n]*\n)*)'
        r'(?P<tail>[ \t]*</control>\n)',
        re.M,
    )
    return list(pattern.finditer(content))


def _hide_control_match(content, matches, description):
    """Set one matched control to visible=false, keeping its other properties."""
    if len(matches) != 1:
        return content, "{} anchor found {} times".format(description, len(matches))
    match = matches[0]
    lines = match.group("body").splitlines(True)
    if not lines or "<control" in match.group("body"):
        return content, "{} has an unexpected layout".format(description)
    indent = lines[0][:len(lines[0]) - len(lines[0].lstrip(" \t"))]
    kept = "".join(line for line in lines if not VISIBLE_LINE.match(line))
    hidden = match.group("head") + indent + "<visible>false</visible>\n" + kept + match.group("tail")
    if hidden == match.group(0):
        return content, None
    return content[:match.start()] + hidden + content[match.end():], None


def hide_textbox(content, control_id):
    head = '<control type="textbox" id="{}">'.format(control_id)
    return _hide_control_match(content, _control_matches(content, head), "Textbox {}".format(control_id))


def restore_plot_textbox(content):
    """Make the description box visible again, so Red Light's own setting decides what it shows.

    Versions up to 1.2.0 hid it. Only the visibility line this add-on wrote is removed."""
    matches = [m for m in _control_matches(content, '<control type="textbox">') if PLOT_LABEL in m.group("body")]
    if len(matches) != 1:
        return content, "Description textbox anchor found {} times".format(len(matches))
    match = matches[0]
    lines = match.group("body").splitlines(True)
    kept = [line for line in lines if line.strip() != "<visible>false</visible>"]
    if len(kept) == len(lines):
        return content, None
    restored = match.group("head") + "".join(kept) + match.group("tail")
    return content[:match.start()] + restored + content[match.end():], None


# The resolve screen's title and synopsis box moves into the space the source counts use, because
# the two screens never show together. The box is top-aligned from the middle of the counts (y 695),
# centred on the counts' horizontal centre (x 950).
DESCRIPTION_MOVES = (
    ("<left>550</left>", "<left>540</left>"),
    ("<top>600</top>", "<top>682</top>"),
    ("<height>310</height>", "<height>300</height>"),
    ("<aligny>bottom</aligny>", "<aligny>top</aligny>"),
)


def move_description(content):
    matches = [m for m in _control_matches(content, '<control type="textbox">') if PLOT_LABEL in m.group("body")]
    if len(matches) != 1:
        return content, "Description textbox anchor found {} times".format(len(matches))
    match = matches[0]
    body = match.group("body")
    for old, new in DESCRIPTION_MOVES:
        if body.count(old) == 1:
            body = body.replace(old, new, 1)
        elif body.count(old) == 0 and body.count(new) == 1:
            continue
        else:
            return content, "Description textbox position is not in a known state"
    moved = match.group("head") + body + match.group("tail")
    return content[:match.start()] + moved + content[match.end():], None


# Positions on the scrape screen. Each entry lists the lines the element may have (the stock
# line, then the lines earlier versions wrote) and the line it should end on. Each line must
# appear once, and a file already at the target is left alone.
LAYOUT_MOVES = (
    (("<top>490</top>", "<top>514</top>"), "<top>550</top>"),  # source counts group
    (("<top>400</top>", "<top>412</top>"), "<top>412</top>"),  # title label
    (("<top>480</top>", "<top>492</top>"), "<top>492</top>"),  # genre label
)


def move_layout(content):
    moved = content
    for earlier, target in LAYOUT_MOVES:
        found = [line for line in earlier if moved.count(line) == 1]
        if len(found) == 1 and (found[0] == target or moved.count(target) == 0):
            moved = moved.replace(found[0], target, 1)
        elif not found and moved.count(target) == 1:
            continue
        else:
            return content, "Layout anchors for {} are not in a known state".format(target)
    return moved, None


# The source count numbers sit 10 px closer to their headers. Each number is a label that shows a
# redlight.scrape.results_* property, and there is one per quality column.
COUNT_NUMBER_MARKER = "redlight.scrape.results_"
COUNT_NUMBER_STOCK_TOP = "<top>100</top>"
COUNT_NUMBER_TOP = "<top>90</top>"


def move_count_numbers(content):
    matches = [m for m in _control_matches(content, '<control type="label">') if COUNT_NUMBER_MARKER in m.group("body")]
    if len(matches) != 5:
        return content, "Count number labels found {} times".format(len(matches))
    moved = content
    # Work from the end of the file, so the offsets of the matches before each edit stay valid.
    for match in reversed(matches):
        body = match.group("body")
        if body.count(COUNT_NUMBER_STOCK_TOP) == 1:
            body = body.replace(COUNT_NUMBER_STOCK_TOP, COUNT_NUMBER_TOP, 1)
        elif body.count(COUNT_NUMBER_TOP) != 1:
            return content, "Count number position is not in a known state"
        moved = moved[:match.start()] + match.group("head") + body + match.group("tail") + moved[match.end():]
    return moved, None


def hide_busy_spinner(content):
    """Hide Red Light's own busy spinner, which sits beside the indicator on the loading screen."""
    matches = [m for m in _control_matches(content, '<control type="image">') if BUSY_SPINNER_MARKER in m.group("body")]
    return _hide_control_match(content, matches, "Busy spinner")


def hide_logo(content):
    """Hide Red Light's logo in the upper-left corner of the loading screen."""
    matches = [m for m in _control_matches(content, '<control type="image">') if LOGO_MARKER in m.group("body")]
    return _hide_control_match(content, matches, "Logo")


def patch_playback_xml(content):
    """Return (patched, error). On any error the input is returned unchanged."""
    patched, error = replace_progress_indicator(content)
    for control_id in DETAIL_TEXTBOX_IDS:
        if error:
            break
        patched, error = hide_textbox(patched, control_id)
    if not error:
        patched, error = restore_plot_textbox(patched)
    if not error:
        patched, error = move_description(patched)
    if not error:
        patched, error = hide_busy_spinner(patched)
    if not error:
        patched, error = hide_logo(patched)
    if not error:
        patched, error = move_layout(patched)
    if not error:
        patched, error = move_count_numbers(patched)
    if error:
        return content, error
    for required in ('id="2001"', 'id="2002"', PLOT_LABEL, BUSY_SPINNER_MARKER, LOGO_MARKER, "redlight.scrape.results_total",
                     "<top>550</top>", "<top>412</top>", "<top>492</top>", "<top>682</top>"):
        if required not in patched:
            return content, "Expected {} is missing after patching".format(required)
    try:
        ElementTree.fromstring(patched.encode("utf-8"))
    except ElementTree.ParseError as exc:
        return content, "Patched XML is not well formed ({})".format(exc)
    return patched, None


def apply_playback_patch(redlight_root):
    """Re-apply the patch if needed. Returns True only when the file was written."""
    path = os.path.join(redlight_root, PLAYBACK_XML)
    if not os.path.isfile(path):
        report_once("sources_playback.xml not found in {}".format(redlight_root))
        return False
    content, newline = read_text(path)
    patched, error = patch_playback_xml(content)
    if error:
        report_once(error)
        return False
    if patched == content:
        return False
    write_text(path, patched, newline)
    log("Reapplied the Red Light loading spinner and hid source details.")
    return True


# The Autoplay Next Episode popup is Red Light's playback_notifications.xml. The same file also
# holds the Still Watching, Skip Intro and stinger popups, so every change is limited to the
# next_episode mode: its controls move into a compact box in the lower-right corner, and the
# other popups keep their stock layout. The file is matched by hash, so any other Red Light
# layout is left alone.
NOTIFICATIONS_XML = os.path.join("resources", "skins", "Default", "1080i", "playback_notifications.xml")
# Hashes of the LF-only text, as read_text returns it. Red Light 2.6.8, 2.7.8 and 2.8.9 ship this file unchanged.
STOCK_NOTIFICATIONS_SHA256 = "39d030bf8837a41cf32a6452e78d9c15306823276afc4dcc597cef665a78ca08"
PATCHED_NOTIFICATIONS_SHA256 = "a72da2526fee767c2778eb32450c82653964bc87515c174ee836a1587e5aad69"
# Earlier builds, each upgraded in place: 1.6.0 (229 px box), 1.6.1 (70% opaque panel),
# 1.6.2 (30% opaque panel), 1.6.3 (420 x 128 px box), 1.6.4 (420 x 154 px box), 1.6.5 (525 px box),
# 1.6.6 (148 px buttons), 1.6.7 (no scroll), 1.6.8 (aqua ring), 1.6.9 (grey ring) and 1.6.10
# (468 x 164 px box), 1.6.11 (470 x 165 px box) and 1.6.12 (85% background), 1.6.14 (175 px box),
# 1.7.2 (470 x 165 px box with 16 px corners), 1.7.5 (550 x 80 px box), 1.7.6 (550 x 88 px box)
# and the 562 px wide box.
PREVIOUS_PATCHED_NOTIFICATIONS_SHA256 = (
    "171b85413405391cd5e8d74840a41b4d547d6d8d35541d1091b1d4a5fd200e91",
    "4f18f74b315b8fa13e680801703532770994fc12fc3c1b1859089f03e6fbc814",
    "2419b8fb2d5087cc693afbbb5cd64313c1d5f687e2001c81bc0220fd4ab93eba",
    "a8deff26c2e72cc7581984ab951b4bf49fa8d9a78c64468d24e5a81e7ad0e61f",
    "e02b030a77834888253432a448b49e5d7f88d01a4d21dd9a78b552f3078e368a",
    "e28a031db4c3a1fa2dcfb0b0d9d3c03c5b78ad06bfbe45e316c8b3f5876b90d0",
    "7204296856c75f06c929cdf42afe2834bc97f0d04a8fd56b5bc6dfd5ac4b12b3",
    "c213608a274e7b464fa9f34acbc91d5ef06aca2679cbb5dc29dc6fb837dc05d6",
    "dd88b17aa053bef2e9f4f6fe4afcf8598dd50e7c98b1112f8136270a52e80ff4",
    "ee36a6052d093bc226c32fe8410f4ddcc8c5663bc5f962a955d4964f863498fc",
    "64e7b1b04efc5db9a4858979236e1cb4b5ea694f3bdda1478606730b495d97f4",
    "54d69c36a2e2cb86479995e6bb7bfeaa90ff18bd2e79bab27aba64c667df6fdf",
    "8d5ce93746c7bf7e7f15ed6ac7daa5fa659f64481b1d2fd0a5750178ff720e94",
    "469fd7a7457c0a8a109bb7389f5619df2d50be5b792edfc8230a5b08cd9848bb",
    "9686a4eedfb4e99f86e63a25d4293029110a3c4d036cce5e5e25b78b896da062",
    "a08cd9b4d2e16d5e1164d8d001e38ce30aa61d3c95fb533caa6829949f5835f7",
    "87cc005c87c436b75d220fc8b8517e8f1b7a2d0d0ff7fcc00de08181cffe28a8",
    "403eaba9e158b319ba65e1315f14da3a6dade810edbc654f5f69115d43f7389f",
    "41f790cfa3db8a61514f81fec4d542c90ac7e3f5301ca3093ca2d602114d2b78",
    "2225439495e3bd0e80e6931d8ac32405edddda81b4e85bd29576bfb0066d893f",
    "b4a17ab2d335699d6378df113aab54012cffd68b0749ca4a63b4c1e9064e1c1c",
    "d77ee7d9507417abdb8b54c2a2785cc59e01f7d801d763c2c73c9a768792b70f",
    "2ea5a313a9dcd96869292fb4f46ace73bc6fb8b4da7b98da9ec738e79c419744",
)
NEXT_EPISODE_ONLY = "String.IsEqual(Window.Property(mode),next_episode)"
NOT_NEXT_EPISODE = "!String.IsEqual(Window.Property(mode),next_episode)"
# Stock markers. Each must appear once; the text between a pair is the next episode heading or body.
BOX_START = "        <!-- Next episode: compact box in the lower-right corner (Red Light Style Patch) -->\n"
NEXT_HEADING_START = "            <!-- HEADING - NEXT EPISODE -->\n"
STILL_HEADING_START = "            <!-- HEADING - STILL WATCHING -->\n"
NEXT_BODY_START = "            <!-- BODY - NEXT EPISODE -->\n"
STILL_BODY_START = "            <!-- BODY - STILL WATCHING -->\n"
# The window's dim backdrop for the upper-left popup, and the group that holds the thumbnail,
# logo and the other popups' text. Both are hidden in next_episode mode.
STOCK_OVERLAY_GROUP = (
    "            <texture>redlight_common/dim-top.png</texture>\n"
    "        </control>\n"
    '        <control type="group">\n'
    "            <left>20</left>\n"
    "            <top>20</top>\n"
    "            <height>160</height>\n"
)
PATCHED_OVERLAY_GROUP = (
    "            <texture>redlight_common/dim-top.png</texture>\n"
    "            <visible>{not_next}</visible>\n"
    "        </control>\n"
    "{box}"
    '        <control type="group">\n'
    "            <visible>{not_next}</visible>\n"
    "            <left>20</left>\n"
    "            <top>20</top>\n"
    "            <height>160</height>\n"
)
# The compact box, in 1080p coordinates: 542 x 148 px, 16 px from the right edge and 12 px from the bottom,
# with 20 px rounded corners, a 1.5 px grey ring at 50% opacity and a soft drop shadow 24 px out
# on each side. The thumbnail sits in the left column, 32 px in and 160 x 90 px, with 12 px rounded
# corners, and Red Light's season premiere or finale banner over its top when it sets one. The right
# column starts 236 px in and holds the countdown, with the buttons (124 x 44 px, 10 px apart) below it.
# The episode title and number are not shown. The Close button is omitted: Back and Escape still dismiss
# the popup the same way.
NEXT_EPISODE_BOX = """        <!-- Next episode: compact box in the lower-right corner (Red Light Style Patch) -->
        <control type="group">
            <visible>{next_only}</visible>
            <right>16</right>
            <bottom>12</bottom>
            <width>542</width>
            <height>148</height>
            <!-- Drop shadow: the panel blurred, 24 px out on each side, centred -->
            <control type="image">
                <left>-24</left>
                <top>-24</top>
                <width>590</width>
                <height>196</height>
                <texture>{media}shadow.png</texture>
            </control>
            <!-- Rounded panel: charcoal at 85% opacity, with a 1.5 px ring in a grey at 50% opacity -->
            <control type="image">
                <width>542</width>
                <height>148</height>
                <texture colordiffuse="D91E2124">{media}panel_body.png</texture>
            </control>
            <control type="image">
                <width>542</width>
                <height>148</height>
                <texture colordiffuse="804A5058">{media}panel_ring.png</texture>
            </control>
            <!-- Thumbnail in the left column, 160 x 90 px, with 20 px rounded corners from a mask -->
            <control type="image">
                <left>32</left>
                <top>29</top>
                <width>160</width>
                <height>90</height>
                <aspectratio>scale</aspectratio>
                <texture diffuse="{media}thumb_mask.png">$INFO[Window.Property(thumb)]</texture>
            </control>
            <!-- Season premiere or finale banner over the thumbnail, shown only when Red Light sets a status -->
            <control type="image">
                <left>32</left>
                <top>29</top>
                <width>160</width>
                <height>90</height>
                <visible>!String.IsEmpty(Window.Property(episode_status.highlight))</visible>
                <texture colordiffuse="Window.Property(episode_status.highlight)">{media}banner_strip.png</texture>
            </control>
            <control type="label">
                <left>32</left>
                <top>34</top>
                <width>160</width>
                <height>20</height>
                <font>font10</font> <!-- REDLIGHT_21 -->
                <textcolor>FFFFFFFF</textcolor>
                <align>center</align>
                <aligny>center</aligny>
                <label>[B]$INFO[Window.Property(episode_status.label)][/B]</label>
                <visible>!String.IsEmpty(Window.Property(episode_status.label))</visible>
            </control>
            <!-- Countdown in the right column, above the buttons, left-aligned with the Play button -->
            <control type="label">
                <top>29</top>
                <left>236</left>
                <width>284</width>
                <height>25</height>
                <font>font12</font> <!-- REDLIGHT_24 -->
                <textcolor>FFE6E6E6</textcolor>
                <align>left</align>
                <aligny>center</aligny>
                <label>[B]Next Episode in $INFO[Window.Property(nextep_remaining)][/B]</label>
                <visible>String.IsEmpty(Window.Property(pause_timer))</visible>
            </control>
            <control type="label">
                <top>29</top>
                <left>236</left>
                <width>284</width>
                <height>25</height>
                <font>font12</font> <!-- REDLIGHT_24 -->
                <textcolor>FFE6E6E6</textcolor>
                <align>left</align>
                <aligny>center</aligny>
                <label>[B]Waiting for Input $INFO[Window.Property(pause_timer)][/B]</label>
                <visible>!String.IsEmpty(Window.Property(pause_timer))</visible>
            </control>
            <!-- Buttons: the focused button is a solid pill with dark text; the other is outlined. Both ends are true semicircles. -->
            <control type="button" id="11">
                <description>Play</description>
                <top>75</top>
                <left>236</left>
                <width>124</width>
                <height>44</height>
                <onleft>12</onleft>
                <onright>12</onright>
                <label></label>
                <font>font10</font> <!-- REDLIGHT_21 -->
                <textcolor>FFE6E6E6</textcolor>
                <focusedcolor>FF1E2124</focusedcolor>
                <texturefocus colordiffuse="FFFFFFFF">{media}pill_fill.png</texturefocus>
                <texturenofocus colordiffuse="FF6E737A">{media}pill_outline.png</texturenofocus>
                <align>center</align>
                <aligny>center</aligny>
                <textoffsetx>0</textoffsetx>
                <textwidth>124</textwidth>
            </control>
            <control type="button" id="12">
                <description>Cancel</description>
                <top>75</top>
                <left>370</left>
                <width>124</width>
                <height>44</height>
                <onleft>11</onleft>
                <onright>11</onright>
                <label></label>
                <font>font10</font> <!-- REDLIGHT_21 -->
                <textcolor>FFE6E6E6</textcolor>
                <focusedcolor>FF1E2124</focusedcolor>
                <texturefocus colordiffuse="FFFFFFFF">{media}pill_fill.png</texturefocus>
                <texturenofocus colordiffuse="FF6E737A">{media}pill_outline.png</texturenofocus>
                <align>center</align>
                <aligny>center</aligny>
                <textoffsetx>0</textoffsetx>
                <textwidth>124</textwidth>
            </control>
            <control type="label">
                <left>236</left>
                <top>74</top>
                <width>124</width>
                <height>44</height>
                <font>font10</font> <!-- REDLIGHT_21 -->
                <textcolor>FF1E2124</textcolor>
                <align>center</align>
                <aligny>center</aligny>
                <label>Play</label>
                <visible>Control.HasFocus(11)</visible>
            </control>
            <control type="label">
                <left>236</left>
                <top>74</top>
                <width>124</width>
                <height>44</height>
                <font>font10</font> <!-- REDLIGHT_21 -->
                <textcolor>FFE6E6E6</textcolor>
                <align>center</align>
                <aligny>center</aligny>
                <label>Play</label>
                <visible>!Control.HasFocus(11)</visible>
            </control>
            <control type="label">
                <left>370</left>
                <top>74</top>
                <width>124</width>
                <height>44</height>
                <font>font10</font> <!-- REDLIGHT_21 -->
                <textcolor>FF1E2124</textcolor>
                <align>center</align>
                <aligny>center</aligny>
                <label>Cancel</label>
                <visible>Control.HasFocus(12)</visible>
            </control>
            <control type="label">
                <left>370</left>
                <top>74</top>
                <width>124</width>
                <height>44</height>
                <font>font10</font> <!-- REDLIGHT_21 -->
                <textcolor>FFE6E6E6</textcolor>
                <align>center</align>
                <aligny>center</aligny>
                <label>Cancel</label>
                <visible>!Control.HasFocus(12)</visible>
            </control>
        </control>
"""


def build_next_episode_box():
    return NEXT_EPISODE_BOX.format(next_only=NEXT_EPISODE_ONLY, media=MEDIA_URL)


def _cut_between(content, start, end):
    """Remove the text from one stock marker up to the next. None when the markers do not fit."""
    if content.count(start) != 1 or content.count(end) != 1 or content.index(end) < content.index(start):
        return None
    return content[:content.index(start)] + content[content.index(end):]


def _upgrade_box(content):
    """Swap the box from an earlier patch for the current one. The file is already a known earlier patch."""
    tail = '        <control type="group">\n            <visible>{}</visible>\n'.format(NOT_NEXT_EPISODE)
    if content.count(BOX_START) != 1 or content.count(tail) != 1 or content.index(tail) < content.index(BOX_START):
        return content, "Autoplay popup anchors are not in a known state"
    upgraded = content[:content.index(BOX_START)] + build_next_episode_box() + content[content.index(tail):]
    if hashlib.sha256(upgraded.encode("utf-8")).hexdigest() != PATCHED_NOTIFICATIONS_SHA256:
        return content, "Autoplay popup upgrade did not produce the current layout"
    return upgraded, None


def patch_notifications_xml(content):
    """Return (patched, error). On any error the input is returned unchanged."""
    digest = hashlib.sha256(content.encode("utf-8")).hexdigest()
    if digest == PATCHED_NOTIFICATIONS_SHA256:
        return content, None
    if digest in PREVIOUS_PATCHED_NOTIFICATIONS_SHA256:
        return _upgrade_box(content)
    if digest != STOCK_NOTIFICATIONS_SHA256:
        return content, "Autoplay popup layout differs from the known Red Light layout"
    patched = _cut_between(content, NEXT_HEADING_START, STILL_HEADING_START)
    if patched is not None:
        patched = _cut_between(patched, NEXT_BODY_START, STILL_BODY_START)
    if patched is None or patched.count(STOCK_OVERLAY_GROUP) != 1:
        return content, "Autoplay popup anchors are not in a known state"
    overlay = PATCHED_OVERLAY_GROUP.format(not_next=NOT_NEXT_EPISODE, box=build_next_episode_box())
    patched = patched.replace(STOCK_OVERLAY_GROUP, overlay, 1)
    if "<description>Close</description>" in patched or "<description>Yes</description>" not in patched:
        return content, "Autoplay popup buttons are not in the expected state after patching"
    try:
        ElementTree.fromstring(patched.encode("utf-8"))
    except ElementTree.ParseError as exc:
        return content, "Patched popup XML is not well formed ({})".format(exc)
    return patched, None


def apply_notifications_patch(redlight_root):
    """Re-apply the autoplay popup layout if needed. Returns True only when the file was written."""
    path = os.path.join(redlight_root, NOTIFICATIONS_XML)
    if not os.path.isfile(path):
        report_once("playback_notifications.xml not found in {}".format(redlight_root), "autoplay popup")
        return False
    content, newline = read_text(path)
    patched, error = patch_notifications_xml(content)
    if error:
        report_once(error, "autoplay popup")
        return False
    if patched == content:
        return False
    write_text(path, patched, newline)
    log("Moved the Autoplay Next Episode popup to the lower-right corner.")
    return True


def patch_red_light():
    redlight_root = xbmcvfs.translatePath("special://home/addons/{}/".format(REDLIGHT_ID))
    if not os.path.isdir(redlight_root):
        log("Check: Red Light not found at {}; nothing to do.".format(redlight_root))
        return False
    # Each patch has its own guard, so a layout change in one file leaves the other one applied.
    written = False
    results = []
    for name, apply in (("loading screen", apply_playback_patch), ("autoplay popup", apply_notifications_patch)):
        status = "no change"
        try:
            if apply(redlight_root):
                status = "reapplied"
                written = True
        except Exception as exc:
            status = "failed"
            report_once("{} patch check failed: {}".format(name.capitalize(), exc), name)
        results.append("{} {}".format(name, status))
    log("Check: {}.".format(", ".join(results)))
    return written


def run():
    monitor = xbmc.Monitor()
    log("Service started; the first check runs in {} seconds.".format(STARTUP_DELAY_SECONDS))
    # Give Kodi and add-on updates a few seconds to settle at startup.
    if monitor.waitForAbort(STARTUP_DELAY_SECONDS):
        return

    patch_red_light()

    while not monitor.waitForAbort(CHECK_SECONDS):
        patch_red_light()


if __name__ == "__main__":
    run()
