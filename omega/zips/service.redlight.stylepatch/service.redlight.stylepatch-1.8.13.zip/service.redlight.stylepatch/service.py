# -*- coding: utf-8 -*-
import hashlib
import os
import re
import xml.etree.ElementTree as ElementTree

import xbmc
import xbmcgui
import xbmcvfs

ADDON_ID = "service.redlight.stylepatch"
REDLIGHT_ID = "plugin.video.redlight"
CHECK_SECONDS = 60
STARTUP_DELAY_SECONDS = 5
PLAYBACK_XML = os.path.join("resources", "skins", "Default", "1080i", "sources_playback.xml")
MEDIA_URL = "special://home/addons/{}/resources/media/".format(ADDON_ID)

# The loading screen progress indicator is the block between these two comments in
# sources_playback.xml. Its stock content is identical in Red Light 2.6.8 and
# 2.7.8; any other content is treated as a structure change and left alone.
PROGRESS_START = "            <!-- Progress -->\n"
PROGRESS_END = "            <!-- Scraper -->\n"
PATCHED_PROGRESS_START = "            <!-- Progress: "
# Regions this service can replace in place: the stock bar, and the bars that
# earlier installs of this add-on already wrote into Red Light (1.0.0 to 1.4.0).
STOCK_PROGRESS_SHA256 = "a4727998e297b7cc3a0cefc89f4ec2b10fcde5179f937236181b3caf518900a4"
PATCHED_1_0_0_PROGRESS_SHA256 = "7ec3eed65daf2c79764ec6c30bcd76674cb3dd42323b3b6ed84c1b85e0779c02"
PATCHED_1_0_1_PROGRESS_SHA256 = "8533314aabf3e47a85686d7dca527217734df2ee5df67bf6538c7a09f76c20f5"
PATCHED_1_0_2_PROGRESS_SHA256 = "b4baf321f69b975c511b125e7d1567e26eacbf52477c592826ceca4fe557e9c9"
PATCHED_1_0_3_PROGRESS_SHA256 = "f63ec6a218b062807206d97366f9bf4c067eb0997b5f03274128e41f740e69a7"
PATCHED_1_0_4_PROGRESS_SHA256 = "6daea86efb30b87d6143175cff9a2f871f3c26f78065a8c1cd26978c0946aa82"
PATCHED_1_0_5_PROGRESS_SHA256 = "6af06bcb95450a4d2e18a5b3c93a3266aeccdada4048ea5277a844eed19f4215"
PATCHED_1_0_6_PROGRESS_SHA256 = "18c5d48d10386dbee671bf59541845957b2c02dfb44a2de0d36bb1eca6146915"
PATCHED_1_1_0_PROGRESS_SHA256 = "a4ba85f7c77a9329c2331110f726b17d9e742112cf3d07c5c68dac9c54a22e11"
PATCHED_1_2_0_PROGRESS_SHA256 = "a8cbb48bd45d7e47e88abc0719f57651c2883eaee7afbd06a71722746e5d9d8c"
PATCHED_1_3_0_PROGRESS_SHA256 = "5d07932e7040973943dc17963a468c8542f016b8fcdb05ec556f7159b428bdc6"
PATCHED_1_4_0_PROGRESS_SHA256 = "f610a228d7a6148d725e8d7773df8cdf5c4e50ea826a993e29c5f67d0ee2ec34"
# 1.6.13 to 1.7.0 wrote the spinner with its arc turning counter-clockwise.
PATCHED_1_6_13_PROGRESS_SHA256 = "f43ded690ba1e319d222d846e23d09f16ca59c7896752d63239835687d37b8fb"
# 1.5.0 wrote the same spinner as 1.4.0.
KNOWN_PROGRESS_SHA256 = (
    STOCK_PROGRESS_SHA256,
    PATCHED_1_0_0_PROGRESS_SHA256,
    PATCHED_1_0_1_PROGRESS_SHA256,
    PATCHED_1_0_2_PROGRESS_SHA256,
    PATCHED_1_0_3_PROGRESS_SHA256,
    PATCHED_1_0_4_PROGRESS_SHA256,
    PATCHED_1_0_5_PROGRESS_SHA256,
    PATCHED_1_0_6_PROGRESS_SHA256,
    PATCHED_1_1_0_PROGRESS_SHA256,
    PATCHED_1_2_0_PROGRESS_SHA256,
    PATCHED_1_3_0_PROGRESS_SHA256,
    PATCHED_1_4_0_PROGRESS_SHA256,
    PATCHED_1_6_13_PROGRESS_SHA256,
)
# The resolve screen's description: a textbox with no id whose only text is the plot
# (for episodes, the episode line and plot share it). Its label is unique in the file.
PLOT_LABEL = "<label>$INFO[Window.Property(text)]</label>"
# Red Light's own small busy spinner, which shares the loading screen with the indicator.
BUSY_SPINNER_MARKER = "redlight_common/spinner.png"
# Red Light's logo in the upper-left corner of the loading screen.
LOGO_MARKER = "redlight.addon_icon_mini"

# Textboxes that carry provider names (2001 while scraping) and source or
# filename details (2002 while resolving). The controls stay in place because
# the Python still calls setLabel/setText on them; only their visibility changes.
DETAIL_TEXTBOX_IDS = (2001, 2002)

# The loading indicator is a circular spinner made of four native Kodi images: a faint
# track, a thin stationary inner ring, the rotating cyan arc, and a glowing centre circle
# that pulses. Kodi runs every animation itself, so the service keeps no timer, thread or
# Python animation loop.
SPINNER_SIZE = 52           # diameter at 1080p, in pixels
SPINNER_LEFT = 934          # centred on x=960 (960 - 26)
SPINNER_TOP = 565           # centred on y=591, with room above and below for the title and counts
SPINNER_ROTATION_MS = 1350  # one full turn of the arc, linear
SPINNER_PULSE_MS = 1200     # one half of the centre pulse; a full in-and-out cycle is twice this
SPINNER_PULSE_ZOOM = (80, 120)  # centre circle size, percent of its 12 px
SPINNER_PULSE_FADE = (55, 100)  # centre circle brightness, percent
SPINNER_TRACK = MEDIA_URL + "spinner_track.png"
SPINNER_INNER = MEDIA_URL + "spinner_inner.png"
SPINNER_ARC = MEDIA_URL + "spinner_arc.png"
SPINNER_CORE = MEDIA_URL + "spinner_core.png"
SPINNER_TRACK_RGB = "592A4B66"  # faint muted blue track: #2A4B66 at 35% alpha


def _spinner_image(texture, colour=None, animations=()):
    texture_tag = '<texture colordiffuse="{}">{}</texture>'.format(colour, texture) if colour else "<texture>{}</texture>".format(texture)
    lines = [
        '                <control type="image">',
        '                    <left>{}</left>'.format(SPINNER_LEFT),
        '                    <top>{}</top>'.format(SPINNER_TOP),
        '                    <width>{}</width>'.format(SPINNER_SIZE),
        '                    <height>{}</height>'.format(SPINNER_SIZE),
        # The skin is laid out for 16:9 and stretched on other shapes, so a square box can become
        # a rectangle. "keep" fits the square texture inside the box, so the spinner stays round.
        '                    <aspectratio align="center" aligny="center">keep</aspectratio>',
        '                    ' + texture_tag,
    ]
    lines += ['                    ' + animation for animation in animations]
    lines.append('                </control>')
    return lines


def build_spinner():
    # Kodi turns the arc from 360 down to 0, which is clockwise on screen.
    rotate = (
        '<animation effect="rotate" start="360" end="0" center="auto" time="{}" tween="linear" '
        'loop="true" reversible="false" condition="true">Conditional</animation>'
    ).format(SPINNER_ROTATION_MS)
    zoom_pulse = (
        '<animation effect="zoom" start="{}" end="{}" center="auto" time="{}" tween="sine" easing="inout" '
        'condition="true" pulse="true">Conditional</animation>'
    ).format(SPINNER_PULSE_ZOOM[0], SPINNER_PULSE_ZOOM[1], SPINNER_PULSE_MS)
    fade_pulse = (
        '<animation effect="fade" start="{}" end="{}" time="{}" tween="sine" easing="inout" '
        'condition="true" pulse="true">Conditional</animation>'
    ).format(SPINNER_PULSE_FADE[0], SPINNER_PULSE_FADE[1], SPINNER_PULSE_MS)
    lines = [
        '            <!-- Progress: circular loading spinner (Red Light Style Patch) -->',
        '            <control type="group">',
        '                <visible>String.IsEqual(Window.Property(window_mode),scraper) | String.IsEqual(Window.Property(window_mode),resolver)</visible>',
    ]
    lines += _spinner_image(SPINNER_TRACK, colour=SPINNER_TRACK_RGB)
    lines += _spinner_image(SPINNER_INNER)
    lines += _spinner_image(SPINNER_ARC, animations=[rotate])
    lines += _spinner_image(SPINNER_CORE, animations=[zoom_pulse, fade_pulse])
    lines.append('            </control>')
    return "".join(line + "\n" for line in lines)


PROGRESS_SPINNER = build_spinner()

VISIBLE_LINE = re.compile(r"[ \t]*<visible>.*</visible>\n$")
_reported = set()


def log(message, level=xbmc.LOGINFO):
    xbmc.log("[{}] {}".format(ADDON_ID, message), level)


def report_once(message, patch="loading-screen"):
    """Log a skipped patch once per distinct reason instead of on every check."""
    if message in _reported:
        return
    _reported.add(message)
    log("{}; {} patch skipped.".format(message, patch), xbmc.LOGWARNING)


def read_text(path):
    """Return the file as LF-only text plus the newline style it was written with."""
    with open(path, "rb") as handle:
        raw = handle.read().decode("utf-8")
    newline = "\r\n" if "\r\n" in raw else "\n"
    return raw.replace("\r\n", "\n"), newline


def write_text(path, content, newline):
    """Write through a temp file and os.replace so Kodi never reads a half-written XML."""
    tmp = path + ".stylepatch.tmp"
    try:
        with open(tmp, "wb") as handle:
            handle.write(content.replace("\n", newline).encode("utf-8"))
        os.replace(tmp, path)
    except OSError:
        if os.path.exists(tmp):
            os.remove(tmp)
        raise


def replace_progress_indicator(content):
    """Swap the stock indicator, or one from an earlier patch, for the spinner. Returns (content, error)."""
    stock_starts = content.count(PROGRESS_START)
    patched_starts = content.count(PATCHED_PROGRESS_START)
    ends = content.count(PROGRESS_END)
    if stock_starts + patched_starts != 1 or ends != 1:
        return content, "Progress anchors found {} start and {} end markers".format(stock_starts + patched_starts, ends)
    start = content.index(PROGRESS_START if stock_starts else PATCHED_PROGRESS_START)
    end = content.index(PROGRESS_END)
    if end < start:
        return content, "Progress anchors are out of order"
    region = content[start:end]
    if region == PROGRESS_SPINNER:
        return content, None
    if hashlib.sha256(region.encode("utf-8")).hexdigest() not in KNOWN_PROGRESS_SHA256:
        return content, "Progress indicator structure differs from the known Red Light layout"
    return content[:start] + PROGRESS_SPINNER + content[end:], None


def _control_matches(content, head):
    """Every control whose opening line is exactly `head`, with its body and closing line."""
    pattern = re.compile(
        r'^(?P<head>[ \t]*' + re.escape(head) + r'\n)'
        r'(?P<body>(?:(?![ \t]*</control>\n)[^\n]*\n)*)'
        r'(?P<tail>[ \t]*</control>\n)',
        re.M,
    )
    return list(pattern.finditer(content))


def _hide_control_match(content, matches, description, visible="false"):
    """Set one matched control's visible tag to `visible` (false unless a condition is given), keeping its other properties."""
    if len(matches) != 1:
        return content, "{} anchor found {} times".format(description, len(matches))
    match = matches[0]
    lines = match.group("body").splitlines(True)
    if not lines or "<control" in match.group("body"):
        return content, "{} has an unexpected layout".format(description)
    indent = lines[0][:len(lines[0]) - len(lines[0].lstrip(" \t"))]
    kept = "".join(line for line in lines if not VISIBLE_LINE.match(line))
    hidden = match.group("head") + indent + "<visible>" + visible + "</visible>\n" + kept + match.group("tail")
    if hidden == match.group(0):
        return content, None
    return content[:match.start()] + hidden + content[match.end():], None


def hide_textbox(content, control_id):
    head = '<control type="textbox" id="{}">'.format(control_id)
    return _hide_control_match(content, _control_matches(content, head), "Textbox {}".format(control_id))


def restore_plot_textbox(content):
    """Make the description box visible again, so Red Light's own setting decides what it shows.

    Versions up to 1.2.0 hid it. Only the visibility line this add-on wrote is removed."""
    matches = [m for m in _control_matches(content, '<control type="textbox">') if PLOT_LABEL in m.group("body")]
    if len(matches) != 1:
        return content, "Description textbox anchor found {} times".format(len(matches))
    match = matches[0]
    lines = match.group("body").splitlines(True)
    kept = [line for line in lines if line.strip() != "<visible>false</visible>"]
    if len(kept) == len(lines):
        return content, None
    restored = match.group("head") + "".join(kept) + match.group("tail")
    return content[:match.start()] + restored + content[match.end():], None


# The resolve screen's title and synopsis box moves into the space the source counts use, because
# the two screens never show together. The box is top-aligned from the middle of the counts (y 695),
# centred on the counts' horizontal centre (x 950).
DESCRIPTION_MOVES = (
    ("<left>550</left>", "<left>540</left>"),
    ("<top>600</top>", "<top>682</top>"),
    ("<height>310</height>", "<height>300</height>"),
    ("<aligny>bottom</aligny>", "<aligny>top</aligny>"),
)


def move_description(content):
    matches = [m for m in _control_matches(content, '<control type="textbox">') if PLOT_LABEL in m.group("body")]
    if len(matches) != 1:
        return content, "Description textbox anchor found {} times".format(len(matches))
    match = matches[0]
    body = match.group("body")
    for old, new in DESCRIPTION_MOVES:
        if body.count(old) == 1:
            body = body.replace(old, new, 1)
        elif body.count(old) == 0 and body.count(new) == 1:
            continue
        else:
            return content, "Description textbox position is not in a known state"
    moved = match.group("head") + body + match.group("tail")
    return content[:match.start()] + moved + content[match.end():], None


# Positions on the scrape screen. Each entry lists the lines the element may have (the stock
# line, then the lines earlier versions wrote) and the line it should end on. Each line must
# appear once, and a file already at the target is left alone.
LAYOUT_MOVES = (
    (("<top>490</top>", "<top>514</top>"), "<top>550</top>"),  # source counts group
    (("<top>400</top>", "<top>412</top>"), "<top>412</top>"),  # title label
    (("<top>480</top>", "<top>492</top>"), "<top>492</top>"),  # genre label
)


def move_layout(content):
    moved = content
    for earlier, target in LAYOUT_MOVES:
        found = [line for line in earlier if moved.count(line) == 1]
        if len(found) == 1 and (found[0] == target or moved.count(target) == 0):
            moved = moved.replace(found[0], target, 1)
        elif not found and moved.count(target) == 1:
            continue
        else:
            return content, "Layout anchors for {} are not in a known state".format(target)
    return moved, None


# The source count numbers sit 10 px closer to their headers. Each number is a label that shows a
# redlight.scrape.results_* property, and there is one per quality column.
COUNT_NUMBER_MARKER = "redlight.scrape.results_"
COUNT_NUMBER_STOCK_TOP = "<top>100</top>"
COUNT_NUMBER_TOP = "<top>90</top>"


def move_count_numbers(content):
    matches = [m for m in _control_matches(content, '<control type="label">') if COUNT_NUMBER_MARKER in m.group("body")]
    if len(matches) != 5:
        return content, "Count number labels found {} times".format(len(matches))
    moved = content
    # Work from the end of the file, so the offsets of the matches before each edit stay valid.
    for match in reversed(matches):
        body = match.group("body")
        if body.count(COUNT_NUMBER_STOCK_TOP) == 1:
            body = body.replace(COUNT_NUMBER_STOCK_TOP, COUNT_NUMBER_TOP, 1)
        elif body.count(COUNT_NUMBER_TOP) != 1:
            return content, "Count number position is not in a known state"
        moved = moved[:match.start()] + match.group("head") + body + match.group("tail") + moved[match.end():]
    return moved, None


def hide_busy_spinner(content):
    """Hide Red Light's own busy spinner, which sits beside the indicator on the loading screen."""
    matches = [m for m in _control_matches(content, '<control type="image">') if BUSY_SPINNER_MARKER in m.group("body")]
    return _hide_control_match(content, matches, "Busy spinner")


def hide_logo(content):
    """Hide Red Light's logo in the upper-left corner of the loading screen."""
    matches = [m for m in _control_matches(content, '<control type="image">') if LOGO_MARKER in m.group("body")]
    return _hide_control_match(content, matches, "Logo")


EPISODE_LINE_MARKER = "Window.Property(episode_line)"
# The Next Episode window's episode line carries the episode's title. It shows only when the title is not hidden.
EPISODE_LINE_VISIBLE = "!String.IsEqual(Window(10000).Property(redlight.skin.hide_episode_title),true)"


def hide_episode_line(content):
    """Give Red Light's episode line the skin's condition, so the title is hidden while hide_episode_title is true."""
    matches = [m for m in _control_matches(content, '<control type="label">') if EPISODE_LINE_MARKER in m.group("body")]
    return _hide_control_match(content, matches, "Episode line", EPISODE_LINE_VISIBLE)


def patch_playback_xml(content):
    """Return (patched, error). On any error the input is returned unchanged."""
    patched, error = replace_progress_indicator(content)
    for control_id in DETAIL_TEXTBOX_IDS:
        if error:
            break
        patched, error = hide_textbox(patched, control_id)
    if not error:
        patched, error = restore_plot_textbox(patched)
    if not error:
        patched, error = move_description(patched)
    if not error:
        patched, error = hide_busy_spinner(patched)
    if not error:
        patched, error = hide_logo(patched)
    if not error:
        patched, error = move_layout(patched)
    if not error:
        patched, error = move_count_numbers(patched)
    if error:
        return content, error
    for required in ('id="2001"', 'id="2002"', PLOT_LABEL, BUSY_SPINNER_MARKER, LOGO_MARKER, "redlight.scrape.results_total",
                     "<top>550</top>", "<top>412</top>", "<top>492</top>", "<top>682</top>"):
        if required not in patched:
            return content, "Expected {} is missing after patching".format(required)
    try:
        ElementTree.fromstring(patched.encode("utf-8"))
    except ElementTree.ParseError as exc:
        return content, "Patched XML is not well formed ({})".format(exc)
    return patched, None


def apply_playback_patch(redlight_root):
    """Re-apply the patch if needed. Returns True only when the file was written."""
    path = os.path.join(redlight_root, PLAYBACK_XML)
    if not os.path.isfile(path):
        report_once("sources_playback.xml not found in {}".format(redlight_root))
        return False
    content, newline = read_text(path)
    patched, error = patch_playback_xml(content)
    if error:
        report_once(error)
        return False
    if patched == content:
        return False
    write_text(path, patched, newline)
    log("Reapplied the Red Light loading spinner and hid source details.")
    return True


# The Autoplay Next Episode popup is Red Light's playback_notifications.xml. The same file also
# holds the Still Watching, stinger, Skip Intro and autoscrape prompts. The next_episode card
# replaces the upper-left popup, and so do the Skip Intro and autoscrape prompts, which use the
# same card with Yes and No. Still Watching and the stinger keep their stock layouts. The file is
# matched by hash, so any other Red Light layout is left alone.
NOTIFICATIONS_XML = os.path.join("resources", "skins", "Default", "1080i", "playback_notifications.xml")
# Hashes of the LF-only text, as read_text returns it. Red Light 2.6.8, 2.7.8, 2.8.9 and 3.0.2 ship this file unchanged.
STOCK_NOTIFICATIONS_SHA256 = "39d030bf8837a41cf32a6452e78d9c15306823276afc4dcc597cef665a78ca08"
PATCHED_NOTIFICATIONS_SHA256 = "6c72ea69259a7c9e296f959e7263560896ae4bb235ef87a8f5981dc7367a4300"
# Earlier builds, each upgraded in place: 1.6.0 (229 px box), 1.6.1 (70% opaque panel),
# 1.6.2 (30% opaque panel), 1.6.3 (420 x 128 px box), 1.6.4 (420 x 154 px box), 1.6.5 (525 px box),
# 1.6.6 (148 px buttons), 1.6.7 (no scroll), 1.6.8 (aqua ring), 1.6.9 (grey ring) and 1.6.10
# (468 x 164 px box), 1.6.11 (470 x 165 px box) and 1.6.12 (85% background), 1.6.14 (175 px box),
# 1.7.2 (470 x 165 px box with 16 px corners), 1.7.5 (550 x 80 px box), 1.7.6 (550 x 88 px box),
# the 562 px wide box, and 1.7.18 (blue-grey card with no Close button and no episode name).
PREVIOUS_PATCHED_NOTIFICATIONS_SHA256 = (
    "171b85413405391cd5e8d74840a41b4d547d6d8d35541d1091b1d4a5fd200e91",
    "4f18f74b315b8fa13e680801703532770994fc12fc3c1b1859089f03e6fbc814",
    "2419b8fb2d5087cc693afbbb5cd64313c1d5f687e2001c81bc0220fd4ab93eba",
    "a8deff26c2e72cc7581984ab951b4bf49fa8d9a78c64468d24e5a81e7ad0e61f",
    "e02b030a77834888253432a448b49e5d7f88d01a4d21dd9a78b552f3078e368a",
    "e28a031db4c3a1fa2dcfb0b0d9d3c03c5b78ad06bfbe45e316c8b3f5876b90d0",
    "7204296856c75f06c929cdf42afe2834bc97f0d04a8fd56b5bc6dfd5ac4b12b3",
    "c213608a274e7b464fa9f34acbc91d5ef06aca2679cbb5dc29dc6fb837dc05d6",
    "dd88b17aa053bef2e9f4f6fe4afcf8598dd50e7c98b1112f8136270a52e80ff4",
    "ee36a6052d093bc226c32fe8410f4ddcc8c5663bc5f962a955d4964f863498fc",
    "64e7b1b04efc5db9a4858979236e1cb4b5ea694f3bdda1478606730b495d97f4",
    "54d69c36a2e2cb86479995e6bb7bfeaa90ff18bd2e79bab27aba64c667df6fdf",
    "8d5ce93746c7bf7e7f15ed6ac7daa5fa659f64481b1d2fd0a5750178ff720e94",
    "469fd7a7457c0a8a109bb7389f5619df2d50be5b792edfc8230a5b08cd9848bb",
    "9686a4eedfb4e99f86e63a25d4293029110a3c4d036cce5e5e25b78b896da062",
    "a08cd9b4d2e16d5e1164d8d001e38ce30aa61d3c95fb533caa6829949f5835f7",
    "87cc005c87c436b75d220fc8b8517e8f1b7a2d0d0ff7fcc00de08181cffe28a8",
    "403eaba9e158b319ba65e1315f14da3a6dade810edbc654f5f69115d43f7389f",
    "41f790cfa3db8a61514f81fec4d542c90ac7e3f5301ca3093ca2d602114d2b78",
    "2225439495e3bd0e80e6931d8ac32405edddda81b4e85bd29576bfb0066d893f",
    "b4a17ab2d335699d6378df113aab54012cffd68b0749ca4a63b4c1e9064e1c1c",
    "d77ee7d9507417abdb8b54c2a2785cc59e01f7d801d763c2c73c9a768792b70f",
    "2ea5a313a9dcd96869292fb4f46ace73bc6fb8b4da7b98da9ec738e79c419744",
    "a72da2526fee767c2778eb32450c82653964bc87515c174ee836a1587e5aad69",
    "7074cda3e186e7e505b2de00de22a695e4bc4ebc84f745e81ac8d1b815193544",
    "50acd27d2724005c13ac2b546925d70f3eb7d4abb10bd39151d9544aab4cfbd5",
    "09e3a006a8cc111cff92e067fe76b06a7ac5eae124905456f9cd2595f0044c48",
    "17c0593e33fe746533907ef1fd9ea209666c0dec743608339bbea9762f1f8e32",
    "a7353fea2b06abd8fd0de02259d34c5ba2c412f057a8e6ca5e950a3b2a0cacbd",
    "034faaf5313e97a7c22466c0457cd906a5ded8b21ffa56be8b776f4cc4ca2e3a",
)
NEXT_EPISODE_ONLY = "String.IsEqual(Window.Property(mode),next_episode)"
PROMPT_ONLY = "String.IsEqual(Window.Property(mode),skip_intro) | String.IsEqual(Window.Property(mode),autoscrape_confirm)"
# Earlier builds hid the upper-left popup for next_episode only. From 1.7.19 it is hidden for the prompts too.
NOT_NEXT_EPISODE = "!String.IsEqual(Window.Property(mode),next_episode)"
NOT_CARD = (
    "!String.IsEqual(Window.Property(mode),next_episode)"
    " + !String.IsEqual(Window.Property(mode),skip_intro)"
    " + !String.IsEqual(Window.Property(mode),autoscrape_confirm)"
)
# Stock markers. Each must appear once; the text between a pair is one popup's heading or body.
# Still Watching and the stinger keep their stock layouts, so their markers only bound the cuts.
BOX_START = "        <!-- Next episode: compact box in the lower-right corner (Red Light Style Patch) -->\n"
NEXT_HEADING_START = "            <!-- HEADING - NEXT EPISODE -->\n"
STILL_HEADING_START = "            <!-- HEADING - STILL WATCHING -->\n"
AUTO_HEADING_START = "            <!-- HEADING - AUTOSCRAPE CONFIRM -->\n"
SKIP_HEADING_START = "            <!-- HEADING - SKIP INTRO -->\n"
STINGER_HEADING_START = "            <!-- HEADING - STINGER -->\n"
NEXT_BODY_START = "            <!-- BODY - NEXT EPISODE -->\n"
STILL_BODY_START = "            <!-- BODY - STILL WATCHING -->\n"
AUTO_BODY_START = "            <!-- BODY - AUTOSCRAPE CONFIRM -->\n"
SKIP_BODY_START = "            <!-- BODY - SKIP INTRO -->\n"
STINGER_BODY_START = "            <!-- BODY - STINGER -->\n"
# The window's dim backdrop for the upper-left popup, and the group that holds the thumbnail,
# logo and the other popups' text. Both are hidden for the cards: next_episode, skip_intro and
# autoscrape_confirm.
STOCK_OVERLAY_GROUP = (
    "            <texture>redlight_common/dim-top.png</texture>\n"
    "        </control>\n"
    '        <control type="group">\n'
    "            <left>20</left>\n"
    "            <top>20</top>\n"
    "            <height>160</height>\n"
)
PATCHED_OVERLAY_GROUP = (
    "            <texture>redlight_common/dim-top.png</texture>\n"
    "            <visible>{not_card}</visible>\n"
    "        </control>\n"
    "{box}"
    '        <control type="group">\n'
    "            <visible>{not_card}</visible>\n"
    "            <left>20</left>\n"
    "            <top>20</top>\n"
    "            <height>160</height>\n"
)
# The compact card, in 1080p coordinates: 774 x 268 px, 9 px from the right edge and 9 px from the bottom,
# with 32 px rounded corners, a 2 px white edge at 18% and a soft drop shadow 36 px out on each side. The
# thumbnail is 288 x 162 px at 25 px in, with 17 px corners and Red Light's season banner over its top when it
# sets one. The heading reads NEXT EPISODE IN with the countdown, then the season and episode line, the episode
# name and the show title. Close, Play and Cancel pills sit below, in that order. Close and Cancel are 140 px wide
# and Play is 200 px. Each is 54 px tall. The Play label is centred as one group with its icon. Its text boxes are
# wider than the text so it is never cut off. The rating and progress bar are left out. Back and Escape still
# dismiss the popup the same way.
NEXT_EPISODE_BOX = """        <!-- Next episode: compact box in the lower-right corner (Red Light Style Patch) -->
        <control type="group">
            <visible>{next_only}</visible>
            <right>9</right>
            <bottom>9</bottom>
            <width>774</width>
            <height>268</height>
            <!-- Drop shadow: the card blurred, 36 px out on each side, centred -->
            <control type="image">
                <left>-36</left>
                <top>-36</top>
                <width>846</width>
                <height>340</height>
                <texture>{media}shadow.png</texture>
            </control>
            <!-- Rounded card: dark grey at 92% opacity, with a 2 px white edge at 18% -->
            <control type="image">
                <width>774</width>
                <height>268</height>
                <texture colordiffuse="EB222222">{media}panel_body.png</texture>
            </control>
            <control type="image">
                <width>774</width>
                <height>268</height>
                <texture colordiffuse="2EFFFFFF">{media}panel_ring.png</texture>
            </control>
            <!-- Thumbnail in the left column, 288 x 162 px, with 17 px rounded corners from a mask -->
            <control type="image">
                <left>25</left>
                <top>25</top>
                <width>288</width>
                <height>162</height>
                <texture colordiffuse="FF22303C">{media}thumb_mask.png</texture>
            </control>
            <control type="image">
                <left>25</left>
                <top>25</top>
                <width>288</width>
                <height>162</height>
                <aspectratio>scale</aspectratio>
                <texture diffuse="{media}thumb_mask.png">$INFO[Window.Property(thumb)]</texture>
            </control>
            <!-- Season premiere or finale banner over the thumbnail, shown only when Red Light sets a status -->
            <control type="image">
                <left>25</left>
                <top>25</top>
                <width>288</width>
                <height>162</height>
                <visible>!String.IsEmpty(Window.Property(episode_status.highlight))</visible>
                <texture colordiffuse="Window.Property(episode_status.highlight)">{media}banner_strip.png</texture>
            </control>
            <control type="label">
                <left>25</left>
                <top>34</top>
                <width>288</width>
                <height>36</height>
                <font>font12</font>
                <textcolor>FFFFFFFF</textcolor>
                <align>center</align>
                <aligny>center</aligny>
                <label>[B]$INFO[Window.Property(episode_status.label)][/B]</label>
                <visible>!String.IsEmpty(Window.Property(episode_status.label))</visible>
            </control>
            <!-- Text column, 338 px in, with the heading, the season and episode line and the title -->
            <control type="group">
                <left>338</left>
                <top>27</top>
                <width>410</width>
                <control type="label">
                    <top>0</top>
                    <width>410</width>
                    <height>32</height>
                    <font>font12</font>
                    <textcolor>FFBDC8D1</textcolor>
                    <label>[UPPERCASE]Next episode in [/UPPERCASE][COLOR FFFFFFFF]$INFO[Window.Property(nextep_remaining)][/COLOR]</label>
                    <visible>String.IsEmpty(Window.Property(pause_timer))</visible>
                </control>
                <control type="label">
                    <top>0</top>
                    <width>410</width>
                    <height>32</height>
                    <font>font12</font>
                    <textcolor>FFBDC8D1</textcolor>
                    <label>[UPPERCASE]Waiting for input[/UPPERCASE]  [COLOR FFFFFFFF]$INFO[Window.Property(pause_timer)][/COLOR]</label>
                    <visible>!String.IsEmpty(Window.Property(pause_timer))</visible>
                </control>
                <control type="label">
                    <top>38</top>
                    <width>410</width>
                    <height>36</height>
                    <font>font12</font>
                    <textcolor>FFDCE2E7</textcolor>
                    <label>[B]$INFO[Window.Property(episode_number)][/B]</label>
                </control>
                <control type="label">
                    <top>76</top>
                    <width>410</width>
                    <height>36</height>
                    <font>font12</font>
                    <textcolor>FFDCE2E7</textcolor>
                    <label>[B]$INFO[Window.Property(episode_name)][/B]</label>
                </control>
                <control type="textbox">
                    <top>112</top>
                    <width>410</width>
                    <height>40</height>
                    <font>font_midi_bold</font>
                    <textcolor>FFFFFFFF</textcolor>
                    <label>$INFO[Window.Property(show_title)]</label>
                </control>
            </control>
            <!-- Buttons: the focused one is a white pill with dark text, the other a faint white pill.
                 Play is in the middle, with Close before it and Cancel after it, 10 px and 13 px apart. -->
            <control type="button" id="11">
                <description>Play</description>
                <top>194</top>
                <left>396</left>
                <width>200</width>
                <height>54</height>
                <onleft>10</onleft>
                <onright>12</onright>
                <label></label>
                <font>font12</font>
                <textcolor>FFFFFFFF</textcolor>
                <focusedcolor>FF0B1119</focusedcolor>
                <texturefocus colordiffuse="FFFFFFFF">{media}pill_play.png</texturefocus>
                <texturenofocus colordiffuse="24FFFFFF">{media}pill_play.png</texturenofocus>
                <align>center</align>
                <aligny>center</aligny>
                <textoffsetx>0</textoffsetx>
                <textwidth>200</textwidth>
            </control>
            <control type="button" id="12">
                <description>Cancel</description>
                <top>194</top>
                <left>609</left>
                <width>140</width>
                <height>54</height>
                <onleft>11</onleft>
                <onright>10</onright>
                <label></label>
                <font>font12</font>
                <textcolor>FFFFFFFF</textcolor>
                <focusedcolor>FF0B1119</focusedcolor>
                <texturefocus colordiffuse="FFFFFFFF">{media}pill_cancel.png</texturefocus>
                <texturenofocus colordiffuse="24FFFFFF">{media}pill_cancel.png</texturenofocus>
                <align>center</align>
                <aligny>center</aligny>
                <textoffsetx>0</textoffsetx>
                <textwidth>140</textwidth>
            </control>
            <control type="button" id="10">
                <description>Close</description>
                <top>194</top>
                <left>246</left>
                <width>140</width>
                <height>54</height>
                <onleft>12</onleft>
                <onright>11</onright>
                <label></label>
                <font>font12</font>
                <textcolor>FFFFFFFF</textcolor>
                <focusedcolor>FF0B1119</focusedcolor>
                <texturefocus colordiffuse="FFFFFFFF">{media}pill_cancel.png</texturefocus>
                <texturenofocus colordiffuse="24FFFFFF">{media}pill_cancel.png</texturenofocus>
                <align>center</align>
                <aligny>center</aligny>
                <textoffsetx>0</textoffsetx>
                <textwidth>140</textwidth>
            </control>
            <control type="label">
                <left>459</left>
                <top>193</top>
                <width>140</width>
                <height>54</height>
                <font>font12</font>
                <textcolor>FF0B1119</textcolor>
                <align>left</align>
                <aligny>center</aligny>
                <label>[B]Play Now[/B]</label>
                <visible>Control.HasFocus(11)</visible>
            </control>
            <control type="label">
                <left>424</left>
                <top>193</top>
                <width>30</width>
                <height>54</height>
                <font>font12</font>
                <textcolor>FF0B1119</textcolor>
                <align>left</align>
                <aligny>center</aligny>
                <label>[B]▶[/B]</label>
                <visible>Control.HasFocus(11)</visible>
            </control>
            <control type="label">
                <left>459</left>
                <top>193</top>
                <width>140</width>
                <height>54</height>
                <font>font12</font>
                <textcolor>FFFFFFFF</textcolor>
                <align>left</align>
                <aligny>center</aligny>
                <label>[B]Play Now[/B]</label>
                <visible>!Control.HasFocus(11)</visible>
            </control>
            <control type="label">
                <left>424</left>
                <top>193</top>
                <width>30</width>
                <height>54</height>
                <font>font12</font>
                <textcolor>FFFFFFFF</textcolor>
                <align>left</align>
                <aligny>center</aligny>
                <label>[B]▶[/B]</label>
                <visible>!Control.HasFocus(11)</visible>
            </control>
            <control type="label">
                <left>609</left>
                <top>193</top>
                <width>140</width>
                <height>54</height>
                <font>font12</font>
                <textcolor>FF0B1119</textcolor>
                <align>center</align>
                <aligny>center</aligny>
                <label>[B]Cancel[/B]</label>
                <visible>Control.HasFocus(12)</visible>
            </control>
            <control type="label">
                <left>609</left>
                <top>193</top>
                <width>140</width>
                <height>54</height>
                <font>font12</font>
                <textcolor>FFFFFFFF</textcolor>
                <align>center</align>
                <aligny>center</aligny>
                <label>[B]Cancel[/B]</label>
                <visible>!Control.HasFocus(12)</visible>
            </control>
            <control type="label">
                <left>246</left>
                <top>193</top>
                <width>140</width>
                <height>54</height>
                <font>font12</font>
                <textcolor>FF0B1119</textcolor>
                <align>center</align>
                <aligny>center</aligny>
                <label>[B]Close[/B]</label>
                <visible>Control.HasFocus(10)</visible>
            </control>
            <control type="label">
                <left>246</left>
                <top>193</top>
                <width>140</width>
                <height>54</height>
                <font>font12</font>
                <textcolor>FFFFFFFF</textcolor>
                <align>center</align>
                <aligny>center</aligny>
                <label>[B]Close[/B]</label>
                <visible>!Control.HasFocus(10)</visible>
            </control>
        </control>
"""


# The Skip Intro and autoscrape prompts use the same card. Red Light sets the episode number, the episode
# name and the show title for both, and the prompt heading (with its countdown) in still_watching_heading and
# pause_timer. The card has Yes and No, with Yes as the Play pill and No as the Cancel pill, so each pill keeps
# the texture's own width. Their text is centred on the pills, and the card's position and size match the
# next_episode card. The stock Skip Intro and autoscrape layouts are removed from the file.
PROMPT_CARD = """        <!-- Skip intro and autoscrape prompts: the same card, with Yes and No (Red Light Style Patch) -->
        <control type="group">
            <visible>{prompt_only}</visible>
            <right>9</right>
            <bottom>9</bottom>
            <width>774</width>
            <height>268</height>
            <!-- Drop shadow: the card blurred, 36 px out on each side, centred -->
            <control type="image">
                <left>-36</left>
                <top>-36</top>
                <width>846</width>
                <height>340</height>
                <texture>{media}shadow.png</texture>
            </control>
            <!-- Rounded card: dark grey at 92% opacity, with a 2 px white edge at 18% -->
            <control type="image">
                <width>774</width>
                <height>268</height>
                <texture colordiffuse="EB222222">{media}panel_body.png</texture>
            </control>
            <control type="image">
                <width>774</width>
                <height>268</height>
                <texture colordiffuse="2EFFFFFF">{media}panel_ring.png</texture>
            </control>
            <!-- Thumbnail in the left column, 288 x 162 px, with 17 px rounded corners from a mask -->
            <control type="image">
                <left>25</left>
                <top>25</top>
                <width>288</width>
                <height>162</height>
                <texture colordiffuse="FF22303C">{media}thumb_mask.png</texture>
            </control>
            <control type="image">
                <left>25</left>
                <top>25</top>
                <width>288</width>
                <height>162</height>
                <aspectratio>scale</aspectratio>
                <texture diffuse="{media}thumb_mask.png">$INFO[Window.Property(thumb)]</texture>
            </control>
            <!-- Text column, 338 px in, with the prompt heading and countdown, the season and episode line, the episode name and the title -->
            <control type="group">
                <left>338</left>
                <top>27</top>
                <width>410</width>
                <control type="label">
                    <top>0</top>
                    <width>410</width>
                    <height>32</height>
                    <font>font12</font>
                    <textcolor>FFBDC8D1</textcolor>
                    <label>[UPPERCASE]$INFO[Window.Property(still_watching_heading)][/UPPERCASE]  [COLOR FFFFFFFF]$INFO[Window.Property(pause_timer)][/COLOR]</label>
                </control>
                <control type="label">
                    <top>38</top>
                    <width>410</width>
                    <height>36</height>
                    <font>font12</font>
                    <textcolor>FFDCE2E7</textcolor>
                    <label>[B]$INFO[Window.Property(episode_number)][/B]</label>
                </control>
                <control type="label">
                    <top>76</top>
                    <width>410</width>
                    <height>36</height>
                    <font>font12</font>
                    <textcolor>FFDCE2E7</textcolor>
                    <label>[B]$INFO[Window.Property(episode_name)][/B]</label>
                </control>
                <control type="textbox">
                    <top>112</top>
                    <width>410</width>
                    <height>40</height>
                    <font>font_midi_bold</font>
                    <textcolor>FFFFFFFF</textcolor>
                    <label>$INFO[Window.Property(show_title)]</label>
                </control>
            </control>
            <!-- Buttons: Yes is the Play pill and No the Cancel pill, 13 px apart, both 54 px tall. -->
            <control type="button" id="10">
                <description>Yes</description>
                <top>194</top>
                <left>396</left>
                <width>200</width>
                <height>54</height>
                <onleft>11</onleft>
                <onright>11</onright>
                <label></label>
                <font>font12</font>
                <textcolor>FFFFFFFF</textcolor>
                <focusedcolor>FF0B1119</focusedcolor>
                <texturefocus colordiffuse="FFFFFFFF">{media}pill_play.png</texturefocus>
                <texturenofocus colordiffuse="24FFFFFF">{media}pill_play.png</texturenofocus>
                <align>center</align>
                <aligny>center</aligny>
                <textoffsetx>0</textoffsetx>
                <textwidth>200</textwidth>
            </control>
            <control type="button" id="11">
                <description>No</description>
                <top>194</top>
                <left>609</left>
                <width>140</width>
                <height>54</height>
                <onleft>10</onleft>
                <onright>10</onright>
                <label></label>
                <font>font12</font>
                <textcolor>FFFFFFFF</textcolor>
                <focusedcolor>FF0B1119</focusedcolor>
                <texturefocus colordiffuse="FFFFFFFF">{media}pill_cancel.png</texturefocus>
                <texturenofocus colordiffuse="24FFFFFF">{media}pill_cancel.png</texturenofocus>
                <align>center</align>
                <aligny>center</aligny>
                <textoffsetx>0</textoffsetx>
                <textwidth>140</textwidth>
            </control>
            <control type="label">
                <left>396</left>
                <top>193</top>
                <width>200</width>
                <height>54</height>
                <font>font12</font>
                <textcolor>FF0B1119</textcolor>
                <align>center</align>
                <aligny>center</aligny>
                <label>[B]Yes[/B]</label>
                <visible>Control.HasFocus(10)</visible>
            </control>
            <control type="label">
                <left>396</left>
                <top>193</top>
                <width>200</width>
                <height>54</height>
                <font>font12</font>
                <textcolor>FFFFFFFF</textcolor>
                <align>center</align>
                <aligny>center</aligny>
                <label>[B]Yes[/B]</label>
                <visible>!Control.HasFocus(10)</visible>
            </control>
            <control type="label">
                <left>609</left>
                <top>193</top>
                <width>140</width>
                <height>54</height>
                <font>font12</font>
                <textcolor>FF0B1119</textcolor>
                <align>center</align>
                <aligny>center</aligny>
                <label>[B]No[/B]</label>
                <visible>Control.HasFocus(11)</visible>
            </control>
            <control type="label">
                <left>609</left>
                <top>193</top>
                <width>140</width>
                <height>54</height>
                <font>font12</font>
                <textcolor>FFFFFFFF</textcolor>
                <align>center</align>
                <aligny>center</aligny>
                <label>[B]No[/B]</label>
                <visible>!Control.HasFocus(11)</visible>
            </control>
        </control>
"""


def build_next_episode_box():
    return NEXT_EPISODE_BOX.format(next_only=NEXT_EPISODE_ONLY, media=MEDIA_URL)


def build_prompt_box():
    return PROMPT_CARD.format(prompt_only=PROMPT_ONLY, media=MEDIA_URL)


def build_popup_boxes():
    """The two cards, in the order they sit in the file: next_episode, then the prompts."""
    return build_next_episode_box() + build_prompt_box()


def _cut_between(content, start, end):
    """Remove the text from one stock marker up to the next. None when the markers do not fit."""
    if content.count(start) != 1 or content.count(end) != 1 or content.index(end) < content.index(start):
        return None
    return content[:content.index(start)] + content[content.index(end):]


def _cut_all(content, cuts):
    """Apply each cut in turn. None when any pair of markers does not fit."""
    for start, end in cuts:
        content = _cut_between(content, start, end)
        if content is None:
            return None
    return content


# Stock sections the cards replace. Still Watching and the stinger are not cut, so their sections stay stock.
PROMPT_CUTS = (
    (AUTO_HEADING_START, SKIP_HEADING_START),
    (SKIP_HEADING_START, STINGER_HEADING_START),
    (AUTO_BODY_START, SKIP_BODY_START),
    (SKIP_BODY_START, STINGER_BODY_START),
)
STOCK_CUTS = ((NEXT_HEADING_START, STILL_HEADING_START), (NEXT_BODY_START, STILL_BODY_START)) + PROMPT_CUTS
NOT_NEXT_LINE = "            <visible>{}</visible>\n".format(NOT_NEXT_EPISODE)
NOT_CARD_LINE = "            <visible>{}</visible>\n".format(NOT_CARD)


def _upgrade_popup(content):
    """Bring a popup from an earlier patch up to the current one. The file is already a known earlier patch.

    Its boxes are replaced, the upper-left popup is hidden for the prompts as well as next_episode, and the stock
    Skip Intro and autoscrape sections are removed. The result must match the current layout exactly."""
    tail = '        <control type="group">\n            <visible>{}</visible>\n'.format(NOT_NEXT_EPISODE)
    if content.count(BOX_START) != 1 or content.count(tail) != 1 or content.index(tail) < content.index(BOX_START):
        return content, "Autoplay popup anchors are not in a known state"
    upgraded = content[:content.index(BOX_START)] + build_popup_boxes() + content[content.index(tail):]
    upgraded = _cut_all(upgraded, PROMPT_CUTS)
    if upgraded is None or upgraded.count(NOT_NEXT_LINE) != 2:
        return content, "Autoplay popup anchors are not in a known state"
    upgraded = upgraded.replace(NOT_NEXT_LINE, NOT_CARD_LINE)
    if hashlib.sha256(upgraded.encode("utf-8")).hexdigest() != PATCHED_NOTIFICATIONS_SHA256:
        return content, "Autoplay popup upgrade did not produce the current layout"
    return upgraded, None


def patch_notifications_xml(content):
    """Return (patched, error). On any error the input is returned unchanged."""
    digest = hashlib.sha256(content.encode("utf-8")).hexdigest()
    if digest == PATCHED_NOTIFICATIONS_SHA256:
        return content, None
    if digest in PREVIOUS_PATCHED_NOTIFICATIONS_SHA256:
        return _upgrade_popup(content)
    if digest != STOCK_NOTIFICATIONS_SHA256:
        return content, "Autoplay popup layout differs from the known Red Light layout"
    patched = _cut_all(content, STOCK_CUTS)
    if patched is None or patched.count(STOCK_OVERLAY_GROUP) != 1:
        return content, "Autoplay popup anchors are not in a known state"
    overlay = PATCHED_OVERLAY_GROUP.format(not_card=NOT_CARD, box=build_popup_boxes())
    patched = patched.replace(STOCK_OVERLAY_GROUP, overlay, 1)
    if patched.count("<description>Close</description>") != 1 or "<description>Yes</description>" not in patched:
        return content, "Autoplay popup buttons are not in the expected state after patching"
    if hashlib.sha256(patched.encode("utf-8")).hexdigest() != PATCHED_NOTIFICATIONS_SHA256:
        return content, "Autoplay popup did not produce the current layout"
    try:
        ElementTree.fromstring(patched.encode("utf-8"))
    except ElementTree.ParseError as exc:
        return content, "Patched popup XML is not well formed ({})".format(exc)
    return patched, None


def apply_notifications_patch(redlight_root):
    """Re-apply the autoplay popup layout if needed. Returns True only when the file was written."""
    path = os.path.join(redlight_root, NOTIFICATIONS_XML)
    if not os.path.isfile(path):
        report_once("playback_notifications.xml not found in {}".format(redlight_root), "autoplay popup")
        return False
    content, newline = read_text(path)
    patched, error = patch_notifications_xml(content)
    if error:
        report_once(error, "autoplay popup")
        return False
    if patched == content:
        return False
    write_text(path, patched, newline)
    log("Moved the Autoplay Next Episode popup and the Skip Intro and autoscrape prompts to the lower-right corner.")
    return True


# Red Light 3.0 gets the whole Arctic Glass look. The Autoplay popup and the source select are copied in
# whole from resources/windows, each only over a layout this add-on knows. Logo hiding, the source row tags
# and the Still Watching card are patched into the other windows and Python files, each with exact anchors.
# The skin's option switches are set as Window properties, to the Arctic Glass defaults. Older Red Light
# versions keep the loading screen and popup patches above.
SKIN_WINDOWS_DIR = os.path.join("resources", "skins", "Default", "1080i")
SHIPPED_WINDOWS_DIR = os.path.join(os.path.dirname(os.path.abspath(__file__)), "resources", "windows")
SHIPPED_PILL_MODULE = os.path.join(os.path.dirname(os.path.abspath(__file__)), "resources", "redlight", "source_pills.py")
SHIPPED_POPUP = "playback_notifications.xml"
SHIPPED_RESULTS = "sources_results.xml"
STOCK_RESULTS_SHA256 = "a2c69fc488be24d408110451898e3664e3780d078c0e6757315d5b696f374b9c"
# Red Light 3.0.2 stock windows the glass styles replace whole, and the loading screen as the anchored patch leaves it.
STOCK_30_SHA256 = {
    "sources_playback.xml": "a9b90911551ab6c08a8d3d3fbe9c1772c948184882c03110e57d7daa51b688f8",
    "color.xml": "79c844ac6c7ee401f5966fd34b26389a96e9a84fd11e02bd1370c964d277ee64",
    "confirm.xml": "4ec4a1e8a18f088fe877f8b2b95e9177274effeb78d1f60fe83c67a58d8b850d",
    "discover.xml": "6e52b922ec28748406b56441a3b45670716ec7f53ef9a7179773a2a7d6133b05",
    "downloads_manager.xml": "abc2be5c82f040d4df66d0df47743d160f6bf70897ed946d727c5976a51e887b",
    "extras.xml": "65a87e5d4c70f97e13cf9e5ed0d3c6b48a9e3c49486aadc5cb7c7cddddb7378d",
    "ok.xml": "35a608821232d526373e4efde6c49b19935460db577922ad699c7e030cc3c547",
    "people.xml": "23e5bb2f8066e124636ba0348e14060d73cf33d0fbff60b64f6f6899b301e5ba",
    "progress.xml": "ca96f48bfbc8cca2c03319473f3b4e7409449657b478dcf0832d75bed1d3b091",
    "select.xml": "8f26aac4dd8417b13fcfc30ba1d1fd8fecea7d5b2cdb747409fa2f44bd559166",
    "sources_info.xml": "50ab48ab631ba23e953bbad818f596fe187e7a4ddf0ec486abfac7c1d7282f6f",
    "textviewer.xml": "9d249c2be593c8be4028250f4a7274c2e82de1888a00aad1b28c407c59928ad6",
    "textviewer_media.xml": "bdd16f4c3366c7fa9b99b402b0f4380e909e470e538b1814a5f53b964b879c63",
}
# The 3.0.2.1 test build changed one header font in these two windows. The copy replaces it with the stock font.
VARIANT_30_SHA256 = {
    "extras.xml": ("42fa4954397b08513e8739cc0aa2d53b673852939844b703c007cc4bcbbfea61",),
    "people.xml": ("86e94f2d78ed4fd15ab28e963e36b25f98efee647a489f62d89ce69ae1081261",),
}
# The loading screen the anchored patch produces from the 3.0.2 stock file, which earlier versions wrote.
ANCHORED_PLAYBACK_30_SHA256 = "5fc87af6e7fe3af6d81bb3bfeefa11be5b545eeae28d46fbee616c5920a087cc"
LOGO_WINDOWS = ("imageviewer.xml", "nextep_handoff.xml", "thumbviewer.xml")
HOME_WINDOW_ID = 10000
# Every window copied from resources/windows starts with this comment, so a later revision can recognise
# this add-on's file and replace it. make_windows.py writes it.
STYLE_PATCH_WINDOW_MARKER = "<!-- Red Light Style Patch window"
SKIN_PROPERTIES = (
    ("redlight.skin.hide_logo", "true"),
    ("redlight.skin.hide_close", "true"),
    ("redlight.skin.hide_episode_title", "true"),
    ("redlight.skin.hide_loading_sources", "true"),
)
PILL_IMPORT_ANCHOR = "from modules.source_utils import source_filters\n"
PILL_IMPORT = "from modules.source_pills import pill_tags as source_pill_tags, pill_rest as source_pill_rest\n"
PILL_LOOP_ANCHOR = "\t\t\t\titem_list.append((listitem, count))\n"
PILL_LOOP = (
    "\t\t\t\tfor number, tag in enumerate(source_pill_tags(extraInfo), start=1):\n"
    "\t\t\t\t\tlistitem.setProperty('pill_%d' % number, tag)\n"
    "\t\t\t\tlistitem.setProperty('pill_rest', source_pill_rest(extraInfo))\n"
)
# The first pill revision, from the test build: tags only, without pill_rest.
OLD_PILL_IMPORT = "from modules.source_pills import pill_tags as source_pill_tags\n"
OLD_PILL_LOOP = (
    "\t\t\t\tfor number, tag in enumerate(source_pill_tags(extraInfo), start=1):\n"
    "\t\t\t\t\tlistitem.setProperty('pill_%d' % number, tag)\n"
)
PILL_MODULE = os.path.join("resources", "lib", "modules", "source_pills.py")
# Earlier revisions of the pill block this add-on wrote, as (import, loop) pairs. An upgrade replaces the pair
# with the current one. Add the current pair here before changing PILL_IMPORT or PILL_LOOP.
PILL_REVISIONS = ((OLD_PILL_IMPORT, OLD_PILL_LOOP),)
PILL_MODULE_HEADER = '# -*- coding: utf-8 -*-\n"""The audio and video tags of a source row'
SOURCES_PY = os.path.join("resources", "lib", "windows", "sources.py")
PLAYBACK_PY = os.path.join("resources", "lib", "windows", "playback_notifications.py")
STILL_WATCHING_ANCHOR = "\t\tself.setProperty('still_watching_heading', self.heading)\n"
STILL_WATCHING_IDENTITY = (
    "\t\t# The Arctic Glass card shows the episode number, title and name, so Still Watching sets them too.\n"
    "\t\tif not self.compact_confirm and self.meta.get('season') is not None and self.meta.get('episode') is not None:\n"
    "\t\t\t_set_episode_identity(self, self.meta)\n"
)
IDENTITY_MARKER = "if not self.compact_confirm and self.meta.get('season') is not None"
IDENTITY_FUNCTION = "def _set_episode_identity(dialog, meta):"


def _digest(text):
    return hashlib.sha256(text.encode("utf-8")).hexdigest()


def _shipped_text(path):
    with open(path, "rb") as handle:
        return handle.read().decode("utf-8").replace("\r\n", "\n")


def _compile_error(text, name):
    try:
        compile(text, name, "exec")
    except SyntaxError as exc:
        return "{} would not compile ({})".format(name, exc.msg)
    return None


def _well_formed(text):
    try:
        ElementTree.fromstring(text.encode("utf-8"))
    except ElementTree.ParseError:
        return False
    return True


def redlight_version(redlight_root):
    """The version in addon.xml, or None when the file is missing, unreadable or has no version."""
    try:
        return ElementTree.parse(os.path.join(redlight_root, "addon.xml")).getroot().get("version") or None
    except (OSError, ElementTree.ParseError):
        return None


def _window_path(redlight_root, name):
    return os.path.join(redlight_root, SKIN_WINDOWS_DIR, name)


def _is_style_patch_window(text):
    return STYLE_PATCH_WINDOW_MARKER in text


def install_window(redlight_root, name, accepted, label):
    """Copy the shipped window over Red Light's file, when that file is a known layout or an earlier copy of ours.
    Returns True when written."""
    path = _window_path(redlight_root, name)
    if not os.path.isfile(path):
        report_once("{} not found in {}".format(name, redlight_root), label)
        return False
    content, newline = read_text(path)
    shipped = _shipped_text(os.path.join(SHIPPED_WINDOWS_DIR, name))
    if content == shipped:
        return False
    if not _is_style_patch_window(content) and _digest(content) not in tuple(accepted):
        report_once("{} differs from the known Red Light layout".format(name), label)
        return False
    write_text(path, shipped, newline)
    return True


def _patch_stock_window(redlight_root, name, patch, label):
    """Apply `patch` (content -> (patched, error)) to one of Red Light's own windows. Returns True when written."""
    path = _window_path(redlight_root, name)
    if not os.path.isfile(path):
        report_once("{} not found in {}".format(name, redlight_root), label)
        return False
    content, newline = read_text(path)
    patched, error = patch(content)
    if error:
        report_once("{}: {}".format(name, error), label)
        return False
    if patched == content:
        return False
    if not _well_formed(patched):
        report_once("{}: the {} change is not well formed".format(name, label), label)
        return False
    write_text(path, patched, newline)
    return True


def hide_logo_in_window(redlight_root, name):
    return _patch_stock_window(redlight_root, name, hide_logo, "logo")


def apply_episode_title(redlight_root):
    """Hide the episode title in Red Light's Next Episode window, as the skin's own window does. Returns True when written."""
    written = False
    try:
        written = _patch_stock_window(redlight_root, "nextep_handoff.xml", hide_episode_line, "episode title") or written
    except Exception as exc:
        report_once("episode title check failed: {}".format(exc), "episode title")
    return written


def apply_logo_hide(redlight_root):
    """Hide the Red Light logo in each window the skin provides. Returns True when any file was written."""
    written = False
    for name in LOGO_WINDOWS:
        try:
            written = hide_logo_in_window(redlight_root, name) or written
        except Exception as exc:
            report_once("{} logo check failed: {}".format(name, exc), "logo")
    return written


def patch_source_pills(content):
    """Return (patched, error) for sources.py. Gives each source row its pill_1 to pill_7 and pill_rest properties.

    Each half of an earlier revision is upgraded on its own, so a revision that changed only one line still upgrades.
    Any other partial state is left alone."""
    import_count, loop_count = content.count(PILL_IMPORT), content.count(PILL_LOOP)
    if import_count > 1 or loop_count > 1:
        return content, "Source row tags are repeated"
    has_import, has_loop = import_count == 1, loop_count == 1
    if has_import and has_loop:
        return content, None
    upgraded = content
    for old_import, old_loop in PILL_REVISIONS:
        if not has_import and upgraded.count(old_import) == 1:
            upgraded = upgraded.replace(old_import, PILL_IMPORT, 1)
            has_import = True
        if not has_loop and upgraded.count(old_loop) == 1:
            upgraded = upgraded.replace(old_loop, PILL_LOOP, 1)
            has_loop = True
    if has_import and has_loop:
        error = _compile_error(upgraded, "sources.py")
        return (content, error) if error else (upgraded, None)
    if has_import or has_loop:
        return content, "Source row tags are only partly patched"
    if any(old_import in content or old_loop in content for old_import, old_loop in PILL_REVISIONS):
        return content, "Source row tags of an earlier revision are not in a known state"
    if content.count(PILL_IMPORT_ANCHOR) != 1 or content.count(PILL_LOOP_ANCHOR) != 1:
        return content, "Source row anchors are not in a known state"
    patched = content.replace(PILL_IMPORT_ANCHOR, PILL_IMPORT_ANCHOR + PILL_IMPORT, 1)
    patched = patched.replace(PILL_LOOP_ANCHOR, PILL_LOOP + PILL_LOOP_ANCHOR, 1)
    error = _compile_error(patched, "sources.py")
    if error:
        return content, error
    return patched, None


def _is_style_patch_pill_module(text):
    """True for this add-on's module in any revision, so an older copy is replaced and anything else is kept."""
    return text.startswith(PILL_MODULE_HEADER)


def apply_source_pills(redlight_root):
    """Add the source row tags. Returns True when a file was written."""
    sources_path = os.path.join(redlight_root, SOURCES_PY)
    module_path = os.path.join(redlight_root, PILL_MODULE)
    module_text = _shipped_text(SHIPPED_PILL_MODULE)
    content, newline = read_text(sources_path)
    patched, error = patch_source_pills(content)
    if error:
        report_once(error, "source tags")
        return False
    existing = read_text(module_path)[0] if os.path.isfile(module_path) else None
    if existing is not None and existing != module_text and not _is_style_patch_pill_module(existing):
        report_once("{} is not the Style Patch module".format(PILL_MODULE), "source tags")
        return False
    written = False
    if existing != module_text:
        write_text(module_path, module_text, "\n")
        written = True
    if patched != content:
        write_text(sources_path, patched, newline)
        written = True
    return written


def patch_still_watching(content):
    """Return (patched, error) for playback_notifications.py. Still Watching sets the episode number, title and name."""
    if IDENTITY_MARKER in content:
        return content, None
    if IDENTITY_FUNCTION not in content:
        return content, "Autoplay popup code is not in a known state"
    if content.count(STILL_WATCHING_ANCHOR) != 1:
        return content, "Still Watching anchor is not in a known state"
    patched = content.replace(STILL_WATCHING_ANCHOR, STILL_WATCHING_IDENTITY + STILL_WATCHING_ANCHOR, 1)
    error = _compile_error(patched, "playback_notifications.py")
    if error:
        return content, error
    return patched, None


def apply_still_watching(redlight_root):
    path = os.path.join(redlight_root, PLAYBACK_PY)
    content, newline = read_text(path)
    patched, error = patch_still_watching(content)
    if error:
        report_once(error, "Still Watching card")
        return False
    if patched == content:
        return False
    write_text(path, patched, newline)
    return True


def set_skin_properties():
    """Set each Arctic Glass option to its default, where Red Light has not set it. A choice made in Red Light's
    Skin Options is kept, so the defaults only fill in what is missing."""
    window = xbmcgui.Window(HOME_WINDOW_ID)
    for key, value in SKIN_PROPERTIES:
        if not window.getProperty(key):
            window.setProperty(key, value)


def _run_steps(redlight_root, steps):
    # Each step has its own guard, so a layout change in one file leaves the others applied.
    written = False
    results = []
    for name, apply in steps:
        status = "no change"
        try:
            if apply(redlight_root):
                status = "reapplied"
                written = True
        except Exception as exc:
            status = "failed"
            report_once("{} patch check failed: {}".format(name.capitalize(), exc), name)
        results.append("{} {}".format(name, status))
    log("Check: {}.".format(", ".join(results)))
    return written


def _tags_ready(redlight_root):
    """True when sources.py and the pill module are the current ones, which the source select reads."""
    sources = read_text(os.path.join(redlight_root, SOURCES_PY))[0]
    module = os.path.join(redlight_root, PILL_MODULE)
    return (PILL_IMPORT in sources and PILL_LOOP in sources and os.path.isfile(module)
            and read_text(module)[0] == _shipped_text(SHIPPED_PILL_MODULE))


def _identity_ready(redlight_root):
    """True when Still Watching sets the episode fields, which the popup card reads."""
    return IDENTITY_MARKER in read_text(os.path.join(redlight_root, PLAYBACK_PY))[0]


def patch_redlight_3(redlight_root):
    popup_known = (STOCK_NOTIFICATIONS_SHA256, PATCHED_NOTIFICATIONS_SHA256) + tuple(PREVIOUS_PATCHED_NOTIFICATIONS_SHA256)

    def install_popup(root):
        if not _identity_ready(root):
            report_once("the Still Watching episode code is not in place", "autoplay popup")
            return False
        return install_window(root, SHIPPED_POPUP, popup_known, "autoplay popup")

    def install_results(root):
        if not _tags_ready(root):
            report_once("the source row tags are not in place", "source select")
            return False
        return install_window(root, SHIPPED_RESULTS, (STOCK_RESULTS_SHA256,), "source select")

    def install_loading(root):
        return install_window(root, "sources_playback.xml",
                              (STOCK_30_SHA256["sources_playback.xml"], ANCHORED_PLAYBACK_30_SHA256), "loading screen")

    def install_skin_windows(root):
        # One window that cannot be read or written must not stop the others, so each one has its own guard.
        written = False
        for name in sorted(STOCK_30_SHA256):
            if name in ("sources_playback.xml", "playback_notifications.xml", "sources_results.xml"):
                continue
            accepted = (STOCK_30_SHA256[name],) + VARIANT_30_SHA256.get(name, ())
            try:
                written = install_window(root, name, accepted, name[:-4].replace("_", " ")) or written
            except Exception as exc:
                report_once("{} copy failed: {}".format(name, exc), name[:-4].replace("_", " "))
        return written

    set_skin_properties()
    steps = (
        ("loading screen", install_loading),
        ("source tags", apply_source_pills),
        ("Still Watching card", apply_still_watching),
        ("logo", apply_logo_hide),
        ("episode title", apply_episode_title),
        ("autoplay popup", install_popup),
        ("source select", install_results),
        ("skin windows", install_skin_windows),
    )
    return _run_steps(redlight_root, steps)


def patch_red_light():
    redlight_root = xbmcvfs.translatePath("special://home/addons/{}/".format(REDLIGHT_ID))
    if not os.path.isdir(redlight_root):
        log("Check: Red Light not found at {}; nothing to do.".format(redlight_root))
        return False
    version = redlight_version(redlight_root)
    if version is None:
        log("Check: Red Light's version could not be read; nothing to do.")
        return False
    if version.startswith("3.0."):
        return patch_redlight_3(redlight_root)
    if version.startswith("2."):
        steps = (("loading screen", apply_playback_patch), ("autoplay popup", apply_notifications_patch))
        return _run_steps(redlight_root, steps)
    log("Check: Red Light {} is not a version this add-on patches; nothing to do.".format(version))
    return False


def run():
    monitor = xbmc.Monitor()
    log("Service started; the first check runs in {} seconds.".format(STARTUP_DELAY_SECONDS))
    # Give Kodi and add-on updates a few seconds to settle at startup.
    if monitor.waitForAbort(STARTUP_DELAY_SECONDS):
        return

    patch_red_light()

    while not monitor.waitForAbort(CHECK_SECONDS):
        patch_red_light()


if __name__ == "__main__":
    run()
