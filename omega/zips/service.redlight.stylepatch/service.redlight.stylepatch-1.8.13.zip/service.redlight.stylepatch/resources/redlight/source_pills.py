# -*- coding: utf-8 -*-
"""The audio and video tags of a source row, as up to seven pill slots for a skin.

A skin shows a row's tags as pictures. Each row gets pill_1 to pill_7, in the order the row lists its tags. Only the
tags in SOURCE_PILL_TAGS count, so other words never take a slot.
"""
import re

SOURCE_PILL_TAGS = (
    'D/VISION', 'HDR', 'HYBRID', 'HEVC', 'AVC', 'AV1', 'REMUX', 'BLURAY', 'WEB', 'HDTV', 'ATMOS', 'TRUEHD',
    'DD+', 'DD-EX', 'DD', 'DTS-HD MA', 'DTS-HD', 'DTS-X', 'DTS', 'AAC', 'OPUS', 'MP3', '8CH', '7CH', '6CH', '2CH',
    '3D', 'SDR', 'MP4', 'MKV', 'AVI', 'MPEG', 'WMV',
)
PILL_SLOTS = 7


def pill_slug(tag):
    """The name of a tag's picture: D/VISION becomes d_vision, DD+ becomes ddplus."""
    return re.sub(r'[^a-z0-9]+', '_', tag.lower().replace('+', 'plus')).strip('_')


def pill_split(extra_info, limit=PILL_SLOTS):
    """Split a row's extraInfo into its pill pictures and the rest of its text.

    A known tag takes the next free slot, once. A known tag with no slot left, and every other part, stays in the
    rest, in its order and with its bold markup. Repeats of a tag are dropped.
    """
    tags, rest, seen = [], [], set()
    for part in (extra_info or '').split(' | '):
        plain = part.replace('[B]', '').replace('[/B]', '').strip()
        if not plain:
            continue
        if plain in SOURCE_PILL_TAGS:
            if plain in seen:
                continue
            seen.add(plain)
            if len(tags) < limit:
                tags.append(plain)
                continue
        rest.append(part.strip())
    return [pill_slug(tag) for tag in tags], ' | '.join(rest)


def pill_tags(extra_info, limit=PILL_SLOTS):
    """The known tags in a row's extraInfo, in order and without repeats, as picture names."""
    return pill_split(extra_info, limit)[0]


def pill_rest(extra_info, limit=PILL_SLOTS):
    """The rest of a row's extraInfo, with its pill tags taken out. Shown as text beside the pictures."""
    return pill_split(extra_info, limit)[1]
