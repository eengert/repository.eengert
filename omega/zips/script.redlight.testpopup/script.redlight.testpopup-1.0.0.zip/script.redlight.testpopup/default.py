# -*- coding: utf-8 -*-
"""Shows Red Light's Autoplay Next Episode popup with dummy details, to check its style.

The window is Red Light's own playback_notifications.xml, so the layout matches a real episode,
including any changes the style patch has made. Nothing plays. The buttons only close the popup,
and Back or Escape also closes it.
"""
import os
import threading

import xbmc
import xbmcgui
import xbmcvfs

REDLIGHT_ID = "plugin.video.redlight"
POPUP_XML = "playback_notifications.xml"
SKIN = "Default"
RESOLUTION = "1080i"
CLOSING_ACTIONS = (9, 10, 13, 92)  # the actions Red Light's own popups close on
COUNTDOWN_SECONDS = 74  # shows 1:14, as in the design
DUMMY_PROPERTIES = {
    "mode": "next_episode",
    "thumb": "",
    "clearlogo": "",
    "episode_label": "Test Show[B] | [/B]02x03[B] | [/B]Dummy Episode Title",
    "pause_timer": "",
}


def format_clock(seconds):
    minutes, secs = divmod(max(0, int(seconds)), 60)
    return "%d:%02d" % (minutes, secs)


class TestPopup(xbmcgui.WindowXMLDialog):
    def __init__(self, xml_name, addon_path):
        xbmcgui.WindowXMLDialog.__init__(self, xml_name, addon_path, SKIN, RESOLUTION)
        self.closed = False
        for name, value in DUMMY_PROPERTIES.items():
            self.setProperty(name, value)
        self.setProperty("nextep_remaining", format_clock(COUNTDOWN_SECONDS))

    def onInit(self):
        self.setFocusId(12)  # Cancel, the default focus for this popup
        threading.Thread(target=self.count_down, daemon=True).start()

    def count_down(self):
        remaining = COUNTDOWN_SECONDS
        while remaining > 0 and not self.closed:
            xbmc.sleep(1000)
            remaining -= 1
            if self.closed:
                return
            self.setProperty("nextep_remaining", format_clock(remaining))

    def onAction(self, action):
        if action.getId() in CLOSING_ACTIONS:
            self.close_popup()

    def onClick(self, control_id):
        self.close_popup()

    def close_popup(self):
        self.closed = True
        self.close()


def run():
    addon_path = xbmcvfs.translatePath("special://home/addons/{}/".format(REDLIGHT_ID))
    if not os.path.isfile(os.path.join(addon_path, "resources", "skins", SKIN, RESOLUTION, POPUP_XML)):
        xbmcgui.Dialog().notification("Test RedLight Autoplay Popup", "Red Light is not installed", xbmcgui.NOTIFICATION_WARNING)
        return
    window = TestPopup(POPUP_XML, addon_path)
    window.doModal()
    del window


if __name__ == "__main__":
    run()
